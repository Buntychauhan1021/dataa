import './App.css';
import { BrowserRouter as Router, Routes, Route, Outlet } from 'react-router-dom';
import './App.css'; // Add custom styles here
import Sidebar from './components/sidebar/Sidebar';
import Header from './components/header/Header';
import { useState, useLayoutEffect, useEffect } from 'react';
import { useStateContext } from "./context/ContextProvider";
import { jwtDecode } from 'jwt-decode'; // Named import
import { useNavigate } from "react-router-dom";
import Dashboard from "./InvoiceGen/Dashboard/Dashboard";
import UploadExcel from "./InvoiceGen/UploadExcel/UploadExcel";
import Calender from "./InvoiceGen/Calendar/Calendar"
import DownloadInvoice from "./InvoiceGen/ForDownload/ForDownload";
import DownloadedInvoice from "./InvoiceGen/Downloaded/Downloaded";
import InvoiceFormat from "./InvoiceGen/InvoiceFormat/InvoiceFormat";
import DeliveryChalaan from "./InvoiceGen/DeliveryChalaan/DeliveryChalaan";
import DownloadedChalaan from "./InvoiceGen/DownloadedChalaan/DownloadedChalaan";
import DeliveryChalaanFormat from "./InvoiceGen/DeliveryChalaanFormat/DeliveryChalaan";
import VelixaDeliveryChalaan from "./InvoiceGen/VelixaDeliveryChalaan/VelixaDeliveryChalaan"
import StreakZenDeliveryChalaan from "./InvoiceGen/DeliveryChalaanStreakZen/DeliveryChalaanStreakZen"
import ElvynDeliveryChalaanFormat from "./InvoiceGen/ElvynDeliveryChallan/ElvynDeliveryChallan"
import InvoiceDotOneFormat from './InvoiceGen/InvoiceDotOneForamat/InvoiceDotOneFormat';
import InvoiceElyvnFormat from './InvoiceGen/InvoiceElyvnFormat/InvoiceElyvnFormat';
import InvoiceOrykoFormat from './InvoiceGen/InvoiceOrykoFormat/InvoiceOrykoFormat'
import InvoiceVelixaFormat from './InvoiceGen/InvoiceVelixaFormat/InvoiceVelixaFormat'
import InvoiceStreakZenFormat from './InvoiceGen/InvoiceStreakZen/InvoiceStreakZen'
import InvoiceZenvyFormat from './InvoiceGen/InvoiceZenvyFormat/InvoiceZenvyFormat';
import InvoiceRishiFormat from './InvoiceGen/InvoiceRishiKashiraFormat/InvoiceRishiKashiraFormat';
import DotOneDeliveryChallanFormat from './InvoiceGen/dotOneDeliveryChallanFormat/dotOneDeliveryChallanFormat';
import Login from "./InvoiceGen/Login/Login";
import Success from "./InvoiceGen/UploadExcel/Success";
import Modal from './InvoiceGen/CalenderModal/Modal';

function App() {
  const [isOpen, setIsOpen] = useState(false);
  const [showModal,setShowModal ] = useState(false)
  const { isLoginUser, setIsLoginUser } = useStateContext();
  const navigate = useNavigate();
  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };
  useLayoutEffect(() => {
    if (localStorage.getItem('user')) {
      const { exp } = jwtDecode(localStorage.getItem('user')); // Using named import
      const expirationTime = exp * 1000 - 60000; // Adjust expiration time
      if (Date.now() >= expirationTime) {
        localStorage.clear();
        navigate('/invoice'); // Trigger navigation
        return;
      }
      setIsLoginUser(localStorage.getItem('user'));
      if(!localStorage.getItem("isModalShown")){
        setShowModal(true)
      }
    }
  }, [setIsLoginUser, navigate]);


  useEffect(() => {
    if (!isLoginUser) {
      navigate('/invoice');
    }
  }, [isLoginUser, navigate]);
  return (
    <>
      {isLoginUser ? (
          <div className="d-flex">
            <Sidebar isOpen={isOpen} toggleSidebar={toggleSidebar} />
            <div className="content w-100">
              <Header toggleSidebar={toggleSidebar} />
              {showModal && <Modal showModal = {showModal} setShowModal = {setShowModal} />}
              <div className="p-4">
                <Routes>
                  <Route path="/invoice/dashboard" element={<Dashboard />} />
                  <Route path="/invoice/Upload" element={<UploadExcel />} />
                  <Route path="/invoice/Calender" element={<Calender />} />
                  <Route path="/invoice/For-Download" element={<DownloadInvoice />} />
                  <Route path="/invoice/Downloaded" element={<DownloadedInvoice />} />
                  <Route path="/invoice/Download/:orderNo" element={<InvoiceFormat />} />
                  <Route path="/invoice/DeliveryChalaan" element={<DeliveryChalaan />} />
                  <Route path="/invoice/DownloadedChalaan" element={<DownloadedChalaan />} />
                  <Route path="/invoice/DeliveryChalaanFormat/:orderNo" element={<DeliveryChalaanFormat />} />
                  <Route path="/invoice/ElvynDeliveryChalaanFormat" element={<ElvynDeliveryChalaanFormat />} />
                  <Route path="/invoice/VelixaDeliveryChalaan" element={<VelixaDeliveryChalaan />}/>
                  <Route path="/invoice/InvoiceDotOneFormat" element = {<InvoiceDotOneFormat />} />
                  <Route path="/invoice/InvoiceElyvnFormat" element = {<InvoiceElyvnFormat />} />
                  <Route path="/invoice/InvoiceOrykoFormat" element = {<InvoiceOrykoFormat />} />
                   <Route path="/invoice/InvoiceRishiKashiraFormat" element = {<InvoiceRishiFormat />} />
                   <Route path="/invoice/InvoiceVelixaFormat" element = {<InvoiceVelixaFormat />} />
                   <Route path="/invoice/InvoiceStreakZenFormat" element = {<InvoiceStreakZenFormat />} />
                   <Route path="/invoice/InvoiceZenvyFormat" element = {<InvoiceZenvyFormat />} />
                    <Route path="/invoice/StreakZenDeliveryChalaan" element = {<StreakZenDeliveryChalaan />} />
                  <Route path='/invoice/DotOneDeliveryChallanFormat' element = {<DotOneDeliveryChallanFormat />} />
                  <Route path="/invoice/success" element={<Success />} />
                </Routes>
              </div>
            </div>
          </div>
      ) : (
        <Routes>
          <Route path="/" element={<navigate to="/invoice" />} />
          <Route path="/invoice" element={<Login />} />
        </Routes>
      )}
    </>
  );
}

export default App;
