

import React from "react";
import { Link, useLocation,useNavigate } from "react-router-dom";
import "./sidebar.css";
import UploadFileOutlinedIcon from "@mui/icons-material/UploadFileOutlined";
import DownloadingIcon from "@mui/icons-material/Downloading";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import DownloadIcon from "@mui/icons-material/Download";
import TransferWithinAStationOutlinedIcon from "@mui/icons-material/TransferWithinAStationOutlined";
import CheckCircleOutlinedIcon from '@mui/icons-material/CheckCircleOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import { useStateContext } from "../../context/ContextProvider";
import LogoutIcon from "@mui/icons-material/Logout";
import logo from "./logo121.png"
const Sidebar = ({ isOpen, toggleSidebar, onLogout }) => {
  const location = useLocation(); // Get current location
  const { setIsLoginUser } = useStateContext()
  const navigate = useNavigate()
  const handleLogoutClick = () => {
    toggleSidebar(); // Close the sidebar
    localStorage.clear("user");
    setIsLoginUser(undefined);
    navigate("/")
  };
  const menuItems = [
    { name: "Dashboard", link: "/invoice/dashboard", icon: <HomeOutlinedIcon /> },
    { name: "Upload Invoice", link: "/invoice/Upload", icon: <UploadFileOutlinedIcon /> },
    { name: "Calender", link: "/invoice/Calender", icon:  <CalendarMonthOutlinedIcon />  },
    { name: "Download Invoice", link: "/invoice/For-Download", icon: <DownloadingIcon /> },
    { name: "Downloaded Invoice", link: "/invoice/Downloaded", icon: <CheckCircleOutlinedIcon /> },
    { name: "Delivery Challan", link: "/invoice/DeliveryChalaan", icon: <TransferWithinAStationOutlinedIcon /> },
    { name: "Downloaded Challan", link: "/invoice/DownloadedChalaan", icon:  <DownloadIcon />  },
    { name: "Logout", link: "/", icon: <LogoutIcon />, logout: true },
  ];
  return (
    <>
      <div
        className={`sidebar text-white ${isOpen ? "open" : ""}`}
        style={{ top: "0", left: "0", zIndex: "20" }}
      >
        <button
          className="btn text-light d-md-none fs-1"
          onClick={toggleSidebar}
          style={{ position: "absolute", right: "-5px", top: "-10px" }}
        >
          &times;
        </button>
        <img src={logo} alt="" style={{height:"110px",width:"100%",backgroundSize:'cover',backgroundPosition:"center"}} />
        <ul className="nav flex-column pt-3">
          {menuItems.map((item, index) => (
            <div
              key={index}
              className={`row mx-1 sidebar-list ${
                location.pathname === item.link ? "active" : ""
              }`}
            >
              <div className="col-2">{item.icon}</div>
              <div className="col-10">
                <li className="nav-item">
                  <Link
                    className="nav-link text-white"
                    to={item.link}
                    onClick={item.logout ? handleLogoutClick : toggleSidebar}
                  >
                    <strong className="menu-text">{item.name}</strong>
                  </Link>
                </li>
              </div>
            </div>
          ))}
        </ul>
      </div>
      {isOpen && <div className="overlay" onClick={toggleSidebar}></div>}
    </>
  );
};
export default Sidebar;

