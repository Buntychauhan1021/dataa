import React, { useEffect, useState } from "react";
import "./Header.css";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import IndianFlag from "./flag.avif";
import adminImg from "./admin.jpg"
const Header = ({ toggleSidebar }) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  const getCurrentDate = () => {
    const date = new Date();
    const options = {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    return date.toLocaleDateString(undefined, options);
  };
  const getCurrentTime = () => {
    const options = {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    };
    return currentTime.toLocaleTimeString(undefined, options);
  };
  return (
    <nav className="navbar navbar-expand-lg navbar-light" style={{backgroundColor:"#c8d8e859"}}>
      <div className="container-fluid">
        <button
          className="btn border border-secondary d-md-none"
          onClick={toggleSidebar}
        >
          &#9776; {/* Hamburger icon */}
        </button>
        <Stack direction="row" className="ms-3" alignItems="center">
  <img src={adminImg} alt="Admin" style={{ height: "50px", width: "50px",borderRadius:"50%" }} />
  <p className="ms-3" style={{
    fontWeight: "600", 
    fontSize: "16px", 
    color: "#656769", // You can change the color as needed
    textTransform: "uppercase", 
    letterSpacing: "1px", 
    textShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", 
    marginBottom: 0, // Remove any bottom margin from the text
    display: 'flex', // Ensure it uses flexbox to center within its space
    alignItems: 'center', // Vertically align the text
  }}>
    Admin
  </p>
</Stack>


        <div className="date text-center d-flex">
          <h6>{getCurrentDate()}</h6>
          <h6 className="ms-2 ">⏱️{getCurrentTime()}</h6>
        </div>
        <img src={IndianFlag} className="me-5"  style={{height:"100%",width:"5%"}}/>
      </div>
    </nav>
  );
};
export default Header;