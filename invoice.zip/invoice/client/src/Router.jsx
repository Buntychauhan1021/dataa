import React from 'react'

const Router = () => {
  return (
    <div>Router</div>
  )
}

export default Router