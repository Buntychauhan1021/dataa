
const baseUrl = "http://localhost:9241";
// const baseUrl = "https://xpresslogi.com:8081";      
export default baseUrl