import React, { useState } from "react";
import "./UploadExcel.css";
import Loader from "../Loader/Loader";
import axios from "axios";
import { Box, Typography, Button } from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import baseUrl from "../config/baseUrl";
import { useNavigate } from "react-router-dom";
const UploadExcel = () => {
  const auth = localStorage.getItem("user");
  const navigate = useNavigate();
  const [file, setFile] = useState("");
  const [loading, setLoading] = useState(false);
  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);
    if (file) {
      console.log("Selected file:", file.name);
    }
  };
  const handleSubmit = async () => {
    setLoading(true);
    const config = {
      headers: {
        "Content-Type": "multipart/form-data", // Correct header for file uploads
        Accept: "application/json",
        Authorization: `Bearer ${auth}`,
      },
    };
    const formData = new FormData();
    formData.append("docxfileupload", file);
    try {
      const response = await axios.post(
        `${baseUrl}/uploadInvoiceExcel`,
        formData,
        config
      );
      if (response.status == 200) {
        navigate("/invoice/success");
      }
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false); // Hide loader
    }
  };
  return (
    <div className="upload-excel-container">
      {loading ? (
        <Loader />
      ) : (
        <div className="modals mt-3">
          <div className="modal-header">
            <div className="modal-logo">
              <span className="logo-circle">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  xmlnsXlink="http://www.w3.org/1999/xlink"
                  width="200"
                  height="200"
                  viewBox="0 0 512 419.116"
                >
                  <defs>
                    <clipPath id="clip-folder-new">
                      <rect width="512" height="419.116" />
                    </clipPath>
                  </defs>
                  <g id="folder-new" clipPath="url(#clip-folder-new)">
                    <path
                      id="Union_1"
                      data-name="Union 1"
                      d="M16.991,419.116A16.989,16.989,0,0,1,0,402.125V16.991A16.989,16.989,0,0,1,16.991,0H146.124a17,17,0,0,1,10.342,3.513L227.217,57.77H437.805A16.989,16.989,0,0,1,454.8,74.761v53.244h40.213A16.992,16.992,0,0,1,511.6,148.657L454.966,405.222a17,17,0,0,1-16.6,13.332H410.053v.562ZM63.06,384.573H424.722L473.86,161.988H112.2Z"
                      fill="var(--c-action-primary)"
                      stroke=""
                      strokeWidth="1"
                    />
                  </g>
                </svg>
              </span>
            </div>
          </div>
          <div className="modal-body">
            <h2 className="modal-title">Upload a file</h2>
            <p className="modal-description">Attach the file below</p>
            <Box
              sx={{
                border: "2px dashed black",
                borderRadius: "8px",
                p: 4,
                textAlign: "center",
                backgroundColor: "#eddaf1",
                "&:hover": { backgroundColor: "#eddaf1" },
              }}
            >
              <CloudUploadIcon sx={{ fontSize: 60, color: "#9c27b0" }} />
              <Typography variant="h6" sx={{ mb: 1 }}>
                Drag and drop files here
              </Typography>
              <Typography variant="body2" sx={{ mb: 2 }}>
                or click below to select files
              </Typography>
              <div className="row">
                <div className="col-7 text-end">
                  <Button
                    style={{ backgroundColor: "#9c27b0" }}
                    variant="contained"
                    component="label"
                    startIcon={<CloudUploadIcon />}
                  >
                    Select File
                    <input type="file" hidden onChange={handleFileChange} />
                  </Button>
                </div>
                <div className="col-5 text-start mt-1">
                  <span style={{ fontSize: "14px", fontWeight: "500" }}>
                    {file ? file.name : ""}
                  </span>
                </div>
              </div>
              <div
                style={{
                  fontSize: "10px",
                  fontWeight: "600",
                  marginTop: "20px",
                }}
              >
                Accepted File Type : .xls or .xlsx
              </div>
            </Box>
          </div>
          <div className="modal-footer">
            <button className="btn-upload-cancel">Cancel</button>
            <button className="btn-upload" onClick={handleSubmit}>
              Upload File
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
export default UploadExcel;
