import React from 'react'
import { Link } from 'react-router-dom'
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import "./Success.css"
import shadows from '@mui/material/styles/shadows';
const Success = () => {
  return (
    <div className="text-center success-container">
    <div className="card Signupend-page" style={{boxShadow:"2px 6px 15px 0 rgb(12 2 35 / 32%)"}}>
      <div className="card-body">
        <div className="icon-wrapper mb-3">
        <CheckCircleIcon
        sx={{
          fontSize: 80,
          color: "#4caf50", // Green color for success
        }}
      />
        </div>
        <h2 className="mb-3">Uploaded!</h2>
        <p>Your file successfully Uploaded.<br /> Thank you for your patience!</p>
        <Link to="/invoice/For-Download" className="btn btn-primary">
          Go to Downlad Invoices
        </Link>
      </div>
    </div>
  </div>
  )
}

export default Success