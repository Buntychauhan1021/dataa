import React from "react";
import { jsPDF } from "jspdf";
import "../InvoiceFormat/InvoiceFormat.css";
import html2canvas from "html2canvas";
import oryko from "./oryko.png"
import { Link, useLocation } from "react-router-dom";
import {
  FaMapMarkerAlt,
  FaTruck,
  FaCalendarAlt,
} from "react-icons/fa";
import axios from "axios";
import baseUrl from "../config/baseUrl";
const InvoiceDetails = ({ invoiceData }) => {
  return (
    <div
      style={{
        width: "800px",
        marginLeft: "10px",
        marginTop: "30px",
        marginBottom: "30px",
      }}
    >
      <div id="invoice" style={{ background: "#fff", padding: "10px", marginLeft: "5px" }}>
        <div className="border-bottom pb-2 mb-2 d-flex flex-md-row justify-content-between align-items-start">
          <div className="d-flex align-items-start gap-3">
            <img
              src={oryko}
              alt="logo"
              height={60}
            />
            <div>
              <h5 className="fw-bold mb-1" style={{ fontSize: "0.9rem" }}>
                EDFINITE TECHNOLOGIES PRIVATE LIMITED
              </h5>
              <p className="mb-0 small text-muted">GST NO.: 08AAFCE8006Q1Z6</p>
            </div>
          </div>
          <div
            className="text-muted small fst-italic mt-3 mt-md-0"
            style={{ fontSize: "0.7rem" }}
          >
            * Keep this invoice for warranty purposes
          </div>
        </div>

        <div className="row g-2 mb-3">
          <div className="col-6">
            <div className="p-2 bg-white border h-100">
              <div className="d-flex m-1 me-0 flex-nowrap">
                <div
                  className="text-white rounded-circle d-flex justify-content-center align-items-center me-2"
                  style={{
                    width: "30px",
                    height: "30px",
                    backgroundColor: "#17a2b8",
                    fontSize: "0.9rem",
                  }}
                >
                  <FaCalendarAlt />
                </div>
                <h6
                  className="fw-semibold text-dark mt-1 mb-0"
                  style={{ fontSize: "0.95rem" }}
                >
                  Order Info
                </h6>
              </div>
              <div
                className="small text-muted ps-1"
                style={{ fontSize: "0.8rem" }}
              >
                <div>
                  <strong className="text-dark">Order ID:</strong>{invoiceData.orderNo}
                </div>
                <div>
                  <strong className="text-dark">Order Date:</strong>{invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}
                </div>
                <div>
                  <strong className="text-dark">Invoice Date:</strong>{invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}
                </div>
              </div>
            </div>
          </div>

          {/* <div className="col-4 ">
            <div className="p-2 bg-white border h-100">
              <div className="d-flex m-1 me-0">
                <div
                  className="bg-success text-white rounded-circle d-flex justify-content-center align-items-center me-2"
                  style={{ width: "30px", height: "30px", fontSize: "0.9rem" }}
                >
                  <FaMapMarkerAlt />
                </div>
                <h6
                  className="fw-semibold text-dark mt-1 mb-0"
                  style={{ fontSize: "0.95rem" }}
                >
                Billing Address
                </h6>
              </div>
              <div
                className="small text-muted ps-1"
                style={{ fontSize: "0.8rem" }}
              >
                {invoiceData.fullName
                  .split(" ")
                  .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                  .join(" ")}

                <p className="mb-0">
                  {invoiceData.billingAddress}
                </p>
                <span>

                  Phone : {invoiceData.mobileNo}
                </span>
              </div>
            </div>
          </div> */}

          <div className="col-6">
            <div className="p-2 bg-white border h-100">
              <div className="d-flex m-1 me-0">
                <div
                  className="bg-danger text-white rounded-circle d-flex justify-content-center align-items-center me-2"
                  style={{ width: "30px", height: "30px", fontSize: "0.9rem" }}
                >
                  <FaTruck />
                </div>
                <h6
                  className="fw-semibold text-dark mt-1 mb-0"
                  style={{ fontSize: "0.95rem" }}
                >
                  Billing Address
                </h6>
              </div>
              <div
                className="small text-muted ps-1"
                style={{ fontSize: "0.8rem" }}
              >
                {invoiceData.fullName
                  .split(" ")
                  .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                  .join(" ")}

                <p className="mb-0">
                  {invoiceData.billingAddress}
                </p>
                <span>
                  Phone : {invoiceData.mobileNo}
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className=" shadow-sm mb-3">
          <div className="border  p-2  bg-white shadow-sm">
            <div className="d-flex justify-content-between align-items-start">
              <div>
                <div className="fw-semibold text-dark ">{invoiceData.productTitle}</div>
                <div className="text-muted ">
                  {invoiceData.productName}
                </div>
                <div className="text-muted small">18% GST</div>
              </div>

              <div className="text-start ">
                <div className="fw-bold text-dark">
                  Qty : <span className="fw-normal">1</span>
                </div>
                <div className="fw-bold text-dark">
                  Price: <span className="fw-normal">₹{invoiceData.productPrice}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border p-2 bg-light d-flex justify-content-between align-items-center text-danger fw-semibold shadow-sm">
            <span>Discount</span>
            <span>- ₹{invoiceData.discount}</span>
          </div>
          <div className="row" style={{ fontSize: "0.9rem" }}>
            <div className="col-4 pe-0">
              <div className="border shadow-sm p-3 pb-0 bg-white h-100">
                <h6
                  className="fw-semibold text-muted  border-bottom"
                  style={{ fontSize: "0.9rem" }}
                >
                  Taxable :
                </h6>
                <div
                  className="d-flex justify-content-between align-items-center"
                  style={{ minHeight: "30px" }}
                >
                  <span>Price: </span>
                  <span>₹{invoiceData.baseAmount}</span>
                </div>
                <div
                  className="d-flex justify-content-between align-items-center"
                  style={{ minHeight: "30px" }}
                >
                  <span>Tax: </span>
                  <span>₹{invoiceData.gst}</span>
                </div>
                <div
                  className="d-flex justify-content-between fw-bold align-items-center"
                  style={{ minHeight: "30px" }}
                >
                  <span>Total: </span>
                  <span>₹{(invoiceData.baseAmount + invoiceData.gst).toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div className="col-4 ps-0 pe-0">
              <div className="border shadow-sm p-3 pb-0 bg-white h-100">
                <h6
                  className="fw-semibold text-muted border-bottom "
                  style={{ fontSize: "0.9rem" }}
                >
                  Plateform Fee
                </h6>
                <div
                  className="d-flex justify-content-between  align-items-center"
                  style={{ minHeight: "30px" }}
                >
                  <span>Price: </span>
                  <span>₹{invoiceData.shippingCharge1}</span>
                </div>
                <div
                  className="d-flex justify-content-between align-items-center"
                  style={{ minHeight: "30px" }}
                >
                  <span>Tax: </span>
                  <span>₹{invoiceData.shippingCharge2}</span>
                </div>
                <div
                  className="d-flex justify-content-between fw-bold align-items-center"
                  style={{ minHeight: "30px" }}
                >
                  <span>Total: </span>
                  <span>₹{invoiceData.shippingCharges}</span>
                </div>
              </div>
            </div>

            <div className="col-4 ps-0">
              <div className="border shadow-sm p-3 pb-0 bg-white h-100">
                <h6
                  className="fw-semibold text-muted  border-bottom "
                  style={{ fontSize: "0.9rem" }}
                >
                  Order Summary
                </h6>
                <div
                  className="d-flex justify-content-between  align-items-center"
                  style={{ minHeight: "30px" }}
                >
                  <span>Items: </span>
                  <span>1</span>
                </div>
                <div
                  className="d-flex justify-content-between  align-items-center"
                  style={{ minHeight: "30px" }}
                >
                  <span>Total Tax: </span>
                  <span>₹{(invoiceData.gst + invoiceData.shippingCharge2).toFixed(2)}</span>
                </div>
                <div
                  className="d-flex justify-content-between fw-bold align-items-center"
                  style={{ minHeight: "30px" }}
                >
                  <span>Final Total: </span>
                  <span>₹{invoiceData.paidAmount.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>

          <div
            className="d-flex justify-content-between align-items-center p-2  fw-bold"
            style={{ backgroundColor: "#a3d9a5", color: "#1b5e20" }}
          >
            <span>Grand Total</span>
            <span>₹{invoiceData.paidAmount.toFixed(2)}</span>
          </div>
        </div>
        <div className="mb-2 text-center text-muted small fst-italic">
          This is a computer-generated invoice. No signature is required.
        </div>
        <div
          className="p-3 bg-white border shadow-sm mb-4 small"
          style={{ fontSize: "0.8rem" }}
        >
          <div
            className="d-flex justify-content-between align-items-start border-bottom pb-3 mb-3"
            style={{ flexWrap: "nowrap" }}
          >
            <div style={{ width: "50%" }}>
              <h6
                className="fw-bold text-dark mb-1"
                style={{ fontSize: "0.95rem" }}
              >
                Direct Deposit / Bank Wire Transfer:
              </h6>
              <p className="mb-0 text-muted">
                Deposit the amount at your nearest
                <br />
                <strong className="text-uppercase text-secondary">
                  IDFC FIRST BANK 
                </strong>
                <br />
                in our accounts in favour of
                <br />
                <strong className="text-uppercase text-secondary">
                  EDFINITE TECHNOLOGIES PRIVATE LIMITED
                </strong>
                .
              </p>
            </div>

            <div style={{ width: "50%" }}>
              <h6
                className="fw-bold text-dark mb-1"
                style={{ fontSize: "0.95rem" }}
              >
                Confirmation:
              </h6>
              <p className="mb-0 text-muted">
                Send the payment confirmation to:
                <a href="mailto:support@oryko.in" className="text-success ms-1">
                  support@oryko.in
                </a>
              </p>
            </div>
          </div>

          <div
            className="d-flex justify-content-between align-items-start"
            style={{ flexWrap: "nowrap" }}
          >
            <div style={{ width: "50%" }}>
              <h6
                className="fw-bold text-dark mb-1"
                style={{ fontSize: "0.95rem" }}
              >
                Transfer using account:
              </h6>
              <p className="mb-0 text-muted">
                <strong>Bank:</strong> IDFC FIRST BANK
                <br />
                <strong>A/C No:</strong>{" "}
                <span className="text-secondary">10226466663</span>
                <br />
                <strong>IFSC Code:</strong>{" "}
                <span className="text-secondary">IDFB0020101</span>
              </p>
            </div>

            <div style={{ width: "50%" }}>
              <h6
                className="fw-bold text-dark mb-1"
                style={{ fontSize: "0.95rem" }}
              >
                More Info:
              </h6>
              <p className="mb-0 text-muted">
                Visit our website:
                <a
                  href="https://oryko.in/"
                  target="_blank"
                  className="text-success ms-1"
                >
                  https://oryko.in/
                </a>
              </p>
            </div>
          </div>
        </div>

        <div className="text-center text-muted small fst-italic">
          This is a computer-generated invoice. No signature is required.
        </div>
        <div
          style={{
            marginTop: "15%",
            textAlign: "center",
            fontSize: "16px",
            fontWeight: "600",
          }}
        >
          Floor No.: THIRD FLOOR
Building No./Flat No.: S-324
Name Of Premises/Building: Balaji Tower 6
Road/Street: Tonk Road
Locality/Sub Locality: Durgapura
City/Town/Village: Jaipur
District: Jaipur
State: Rajasthan
PINCODE :302033
        </div>
      </div>

    </div>
  );
};
function InvoiceElyvnFormat() {
  const auth = localStorage.getItem("user");
  const location = useLocation();
  const { item, module } = location.state || {};
  const downloadPDF = async () => {
    const input = document.getElementById("invoice");
    const formData = new FormData();
    formData.append("orderNo", item.orderNo);
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG");
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${item.orderNo}` + ".pdf");
    });
    const config = {
      headers: {
        "Content-type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${auth}`,
      },
    };
    if (module !== "/Invoice/Downloaded") {
      await axios.post(
        `${baseUrl}/changeStatusDownloadedInvoice`,
        formData,
        config
      );
    }
  };
  return (
    <div>
      <div className="row m-0 p-0">
        <div className="col-6">
          <Link to={`${module}`}>
            <button
              style={{
                backgroundColor: "#ff9707",
                color: "#fff",
                width: "80px",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "16px",
                marginTop: "20px",
                padding: "4px 5px",
              }}
            // onClick={downloadPDF}
            >
              Back
            </button>
          </Link>
        </div>
        <div className="col-5 offset-1">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width: "80px",
              padding: "4px 5px",
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
      <InvoiceDetails invoiceData={item} />
    </div>
  );
}
export default InvoiceElyvnFormat;





