import React from "react";
import { jsPDF } from "jspdf";
import "../InvoiceFormat/InvoiceFormat.css";
import html2canvas from "html2canvas";
// import React from "react";
import img from "./logo.png";
// import oryko from "./oryko.png"
import { Link, useLocation } from "react-router-dom";
import {
  FaMapMarkerAlt,
  FaTruck,
  FaCalendarAlt,
} from "react-icons/fa";
import axios from "axios";
import baseUrl from "../config/baseUrl";
const InvoiceDetails = ({ invoiceData }) => {
  return (
    <div
      style={{
        width: "800px",
        marginLeft: "10px",
        marginTop: "30px",
        marginBottom: "30px",
      }}
    >
      <div id="invoice" style={{ background: "#fff", padding: "10px", marginLeft: "5px" }}>
         <div
      className="my-1 p-4 shadow"
      style={{
        margin: "auto",
        padding: "2rem",
        backgroundColor: "#9090c3", 
        color: "#f0f0f0",
        maxWidth: "900px",
        fontSize: "0.8rem",
        boxShadow: "0 0 20px rgba(0, 0, 0, 0.2)",
      }}
    >
      <div
        className="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2"
        style={{ borderColor: "#0a2855" }}
      >
        <div className="col-6 align-items-center ">
          <img
            src={img}
            alt="Company Logo"
            style={{ height: "40px", objectFit: "contain" }}
          />
          <div>
            <h5 style={{ margin: 0, color: "#0a2855", fontSize: "1.1rem" }}>
              STREAKGEN TECHNOLOGY PRIVATE LIMITED
            </h5>
          </div>
        </div>

        <div className="col-6 text-end">
          <p style={{ marginBottom: 0, color: "#e1e1ef" }}>
            GST NO: 24ABPCS1413A1ZU
          </p>
          <p style={{ marginBottom: 0, fontSize: "13px", color: "#e1e1ef" }}>
            Shop No FF-106, Aditya Avenew, P No 102 TO 107, Sidsar Road,
            Shivalik Arogyadham, Chitra, Bhavnagar, Gujarat 364004
          </p>
          <p style={{ fontSize: "13px", color: "#e1e1ef" }}>
            Email: streakgentechnology@gmail.com
            {/* <a
              href="https://elvyn.co.in"
              style={{ color: "#0a2855", textDecoration: "underline" }}
            >
              https://elvyn.co.in
            </a> */}
          </p>
        </div>
      </div>

      <div className="row">
        <div className="col-4">
          <h6 style={{ color: "#0a2855" }}>Billing Address</h6>
          <p style={{ fontSize: "14px" }}>
            {invoiceData.fullName
                .split(" ")
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ")} <br/>
                {invoiceData.billingAddress} <br/>
                {invoiceData.mobileNo}
          </p>
        </div>

        <div className="col-4 mb-3">
          <h6 style={{ color: "#0a2855" }}>Shipping Address</h6>
          <p style={{ fontSize: "14px" }}>
            {invoiceData.fullName
                .split(" ")
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ")} <br/>
                {invoiceData.billingAddress} <br/>
                {invoiceData.mobileNo}
          </p>
        </div>

        <div className="col-4 mb-3">
          <h6 style={{ color: "#0a2855" }}>Order Info</h6>
          <p style={{ fontSize: "14px" }}>
            Order ID: {invoiceData.orderNo}
            <br />
            Order Date: {invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}
            <br />
            Invoice Date: {invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}
          </p>
        </div>
      </div>

     <div className="mb-3">
  <table
    style={{
      backgroundColor: "#c9c9e3",
      color: "#0a2855",
      borderCollapse: "collapse",
      width: "100%",
      boxShadow: "0 0 8px rgba(0,0,0,0.2)",
    }}
  >
    <thead style={{ backgroundColor: "#b8b8dc" }}>
      <tr style={{ color: "#0a2855", fontSize: "16px" }}>
        <th style={{ padding: "10px", border: "1px solid #9b9bc4", textAlign: "left" }}>Product</th>
        <th style={{ padding: "10px", border: "1px solid #9b9bc4", textAlign: "left" }}>Title</th>
        <th style={{ padding: "10px", border: "1px solid #9b9bc4", textAlign: "center" }}>Qty</th>
        <th style={{ padding: "10px", border: "1px solid #9b9bc4", textAlign: "right" }}>Price(₹)</th>
        <th style={{ padding: "10px", border: "1px solid #9b9bc4", textAlign: "right" }}>Tax(₹)</th>
        <th style={{ padding: "10px", border: "1px solid #9b9bc4", textAlign: "right" }}>Total(₹)</th>
      </tr>
    </thead>
    <tbody>
      {(invoiceData.productName?.split("&&&") || []).map((productName, index) => (
        <tr key={index} style={{ backgroundColor: "#f0f0fa" }}>
          <td style={{ padding: "12px", border: "1px solid #b0b0d4" }}>{productName}</td>
          <td style={{ padding: "12px", border: "1px solid #b0b0d4" }}>{invoiceData.productTitle?.split("&&&")[index]}</td>
          <td style={{ padding: "12px", border: "1px solid #b0b0d4", textAlign: "center" }}>1</td>
          <td style={{ padding: "12px", border: "1px solid #b0b0d4", textAlign: "right" }}>
            ₹{invoiceData.productPrice?.split("&&&")[index]}
          </td>
          <td style={{ padding: "12px", border: "1px solid #b0b0d4", textAlign: "right" }}>-</td>
          <td style={{ padding: "12px", border: "1px solid #b0b0d4", textAlign: "right" }}>-</td>
        </tr>
      ))}

      {/* Total Row */}
      {/* <tr style={{ backgroundColor: "#e3e3f5" }}>
        <td colSpan="5" style={{ padding: "12px", border: "1px solid #b0b0d4", textAlign: "right", fontWeight: "bold" }}>
          Total
        </td>
        <td style={{ padding: "12px", border: "1px solid #b0b0d4", textAlign: "right", fontWeight: "bold" }}>
          ₹{invoiceData.paidAmount}
        </td>
      </tr> */}
    </tbody>
  </table>
</div>


      <div className="d-flex justify-content-end">
        <div
          style={{
            width: "350px",
            backgroundColor: "#7878a5",
            padding: "15px",
            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.2)",
            color: "#f0f0f0",
            borderRadius: "2px"
          }}
        >
          <div className="d-flex justify-content-between py-1">
            <span>Discount:</span>
            <span>₹{invoiceData.discount}</span>
          </div>
          <div className="d-flex justify-content-between py-1">
            <span>Taxable Value:</span>
            <span>₹{invoiceData.baseAmount}</span>
          </div>
          <div className="d-flex justify-content-between py-1">
            <span>Tax:</span>
            <span>₹{invoiceData.gst}</span>
          </div>
          <div className="d-flex justify-content-between py-1">
            <span>Shipping Charges:</span>
            <span>{invoiceData.shippingCharges}</span>
          </div>
          <div
            className="d-flex justify-content-between py-1 mt-3"
            style={{
              fontWeight: "bold",
              fontSize: "1rem",
              borderTop: "2px solid #0a2855",
              paddingTop: "15px",
              color: "#0a2855",
            }}
          >
            <span>Grand Total:</span>
            <span>₹{invoiceData.paidAmount.toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className="p-3 mt-2">
        <div className="row">
          <div className="col-12 col-sm-6 mb-1">
            <h6 className="fw-bold mb-2" style={{ color: "#0a2855" }}>
              Direct Deposit / Bank Wire Transfer
            </h6>
            <p className="mb-1 text-light">
              Deposit the amount at your nearest <strong>HDFC BANK</strong>
              <br />
              in our account in favour of:
            </p>
            <p className="fw-bold text-light">
              STREAKGEN TECHNOLOGY PRIVATE LIMITED
            </p>
          </div>
          <div className="col-12 col-sm-6 text-light mb-3" style={{ fontSize: "14px" }}>
            <h6 className="fw-bold mb-2" style={{ color: "#0a2855" }}>Confirmation</h6>
            <p className="mb-2">
              Send payment confirmation to:{" "}
              <a
                href="mailto:streakgentechnology@gmail.com"
                style={{ textDecoration: "underline", color: "#0a2855" }}
              >
                streakgentechnology@gmail.com
              </a>
            </p>
          </div>
        </div>

        <div className="row">
          <div className="col-12 col-sm-6">
            <h6 className="fw-bold" style={{ color: "#0a2855" }}>Transfer Using Account</h6>
            <ul className="list-unstyled text-light" style={{ fontSize: "14px" }}>
              <li><strong>Bank:</strong> HDFC BANK</li>
              <li><strong>A/C No:</strong> 50200107829702</li>
              <li><strong>IFSC Code:</strong> HDFC0001687</li>
            </ul>
          </div>

          {/* <div className="col-12 col-sm-6 text-light" style={{ fontSize: "14px" }}>
            <h6 className="fw-bold" style={{ color: "#0a2855" }}>More Info</h6>
            <p>
              <a
                href="https://elvyn.co.in"
                target="_blank"
                rel="noreferrer"
                style={{ textDecoration: "underline", color: "#0a2855" }}
              >
                https://elvyn.co.in
              </a>
            </p>
          </div> */}
        </div>
      </div>

      <div className="text-center" style={{ color: "#e1e1ef", fontSize: "14px" }}>
        <p className="m-0">This is a computer-generated invoice. No signature required.</p>
        <p className="m-0">Keep this invoice for warranty purposes.</p>
      </div>
    </div>
      </div>

    </div>
  );
};
function InvoiceElyvnFormat() {
  const auth = localStorage.getItem("user");
  const location = useLocation();
  const { item, module } = location.state || {};
  const downloadPDF = async () => {
    const input = document.getElementById("invoice");
    const formData = new FormData();
    formData.append("orderNo", item.orderNo);
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG");
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${item.orderNo}` + ".pdf");
    });
    const config = {
      headers: {
        "Content-type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${auth}`,
      },
    };
    if (module !== "/Invoice/Downloaded") {
      await axios.post(
        `${baseUrl}/changeStatusDownloadedInvoice`,
        formData,
        config
      );
    }
  };
  return (
    <div>
      <div className="row m-0 p-0">
        <div className="col-6">
          <Link to={`${module}`}>
            <button
              style={{
                backgroundColor: "#ff9707",
                color: "#fff",
                width: "80px",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "16px",
                marginTop: "20px",
                padding: "4px 5px",
              }}
            // onClick={downloadPDF}
            >
              Back
            </button>
          </Link>
        </div>
        <div className="col-5 offset-1">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width: "80px",
              padding: "4px 5px",
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
      <InvoiceDetails invoiceData={item} />
    </div>
  );
}
export default InvoiceElyvnFormat;



// const Invoice = () => {
//   return (
   
//   );
// };

// export default Invoice;




