import React from "react";
import { jsPDF } from "jspdf";
import "../InvoiceFormat/InvoiceFormat.css"; // Optional: Your custom styles (if needed)
import html2canvas from "html2canvas";
import elvyn from "./elvyn.png"
import { Link, useLocation } from "react-router-dom";
import {
  FaMapMarkerAlt,
  FaTruck,
  FaCalendarAlt,
} from "react-icons/fa";
import axios from "axios";
import baseUrl from "../config/baseUrl";
const InvoiceDetails = ({ invoiceData }) => {
  return (
    <div
      style={{
        width: "800px",
        marginLeft: "10px",
        marginTop: "30px",
        marginBottom: "30px",
      }}
    >
      <div id="invoice" style={{ background: "#fff", padding: "10px", marginLeft: "5px", width: "110%" }}>
        <div className="p-2 mb-2 rounded-4 shadow-sm" style={{ backgroundColor: "" }}>
          <div className="d-flex justify-content-between align-items-center flex-wrap">
            {/* <div className="d-flex align-items-center gap-2">
          
             <img
            src={rishiLogo}
            alt="invoice"
            style={{ maxWidth: "150px", display: "inline-block", marginRight: "95px" }}
          />
          </div> */}
            <div className="d-flex align-items-center gap-1">
              <img
                src={elvyn}
                alt="Adibliss Logo"
                style={{ background: "transparent", height: "50px", width: "90px" }} // optional height
              />
              <div>
                <h1
                  className="ps-3 mb-0"
                  style={{ color: "#002f76", fontSize: "0.7rem", paddingTop: "6px" }}
                >
                  Adibliss Infotech Private Limited
                </h1>
                <h2
                  className="ps-3"
                  style={{ color: "#002f76", fontSize: "0.7rem", paddingTop: "1px" }}
                >
                  GST NO: 08AAFCE8006Q1Z6
                </h2>
              </div>
            </div>

            <div className="text-muted small fst-italic text-end mt-2 mt-md-0">
              * Keep this invoice for warranty purposes
            </div>
          </div>
        </div>

        <div className="row g-4 mb-2">
          <div className="col-md-4">
            <div className="border rounded-4 p-3 h-100 shadow-sm" style={{ backgroundColor: "#eef6f9" }}>
              <h6 className="fw-semibold mb-0 text-secondary">
                <FaCalendarAlt className="me-2 text-info" />
                Order Info
              </h6>
              <p className="mb-0">Order ID: <strong>{invoiceData.orderNo}</strong></p>
              <p className="mb-0">Order Date: <strong>{invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}</strong></p>
              <p className="mb-0">Invoice Date: <strong>{invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}</strong></p>
            </div>
          </div>

          <div className="col-md-4">
            <div className="border rounded-4 p-3 h-100 shadow-sm" style={{ backgroundColor: "#eef6f9" }}>
              <h6 className="fw-semibold  text-secondary">
                <FaMapMarkerAlt className="me-2 text-success" />
                Billing Address
              </h6>
              {invoiceData.fullName
                .split(" ")
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ")}

              <p className="mb-0">
                {invoiceData.billingAddress}
              </p>
              <span>

                Phone : {invoiceData.mobileNo}
              </span>
            </div>
          </div>

          <div className="col-md-4">
            <div className="border rounded-4 p-3 h-100 shadow-sm" style={{ backgroundColor: "#eef6f9" }}>
              <h6 className="fw-semibold text-secondary">
                <FaTruck className="me-2 text-danger" />
                Shipping Address
              </h6>
              {invoiceData.fullName
                .split(" ")
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ")}

              <p className="mb-0">
                {invoiceData.billingAddress}
              </p>
              <span>

                Phone : {invoiceData.mobileNo}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white border rounded-4 shadow-sm mb-4">
          <div className="text-white py-3 px-3 fw-bold d-none d-md-flex rounded-top-4" style={{ backgroundColor: "#3db5e0" }}>
            <span className="col-md-2">Product</span>
            <span className="col-md-2">Title</span>
            <span className="col-md-2">Qty</span>
            <span className="col-md-2 ps-4">Price (₹)</span>
            <span className="col-md-2">Tax (₹)</span>
            <span className="col-md-2">Total (₹)</span>
          </div>

          {/* Dynamic Product Rows */}
          {(invoiceData.productTitle?.split("&&&") || []).map((title, index) => (
            <div key={index} className="row g-2 px-3 py-2 align-items-center" style={{ backgroundColor: "#f1f7ff" }}>
              <div className="col-4 col-md-2 text-dark">{title}</div>
              <div className="col-8 col-md-2">
                {invoiceData.productName?.split("&&&")[index]}<br />
                <small className="text-muted">18% GST</small>
              </div>
              <div className="col-6 col-md-2">1</div>
              <div className="col-6 col-md-2 ps-md-4">{invoiceData.productPrice?.split("&&&")[index]}</div>
              <div className="col-6 col-md-2">-</div>
              <div className="col-6 col-md-2">-</div>
            </div>
          ))}

          {/* Discount Row */}
          <div className="row g-2 px-3 py-2 align-items-center bg-light border-top">
            <div className="col-6 col-md-2"></div>
            <div className="col-6 col-md-2"></div>
            <div className="col-6 col-md-2 ps-5 text-muted">Discount</div>
            <div className="col-6 col-md-2 ps-md-4 text-danger fw-semibold">{invoiceData.discount}</div>
            <div className="col-6 col-md-2">-</div>
            <div className="col-6 col-md-2">-</div>
          </div>

          {/* Taxable Value Row */}
          <div className="row g-2 px-3 py-2 align-items-center" style={{ backgroundColor: "#eef6f9" }}>
            <div className="col-6 col-md-2"></div>
            <div className="col-6 col-md-2"></div>
            <div className="col-6 col-md-2 ps-5 text-muted">Taxable Value</div>
            <div className="col-6 col-md-2 ps-md-4">{invoiceData.baseAmount}</div>
            <div className="col-6 col-md-2">{invoiceData.gst}</div>
            <div className="col-6 col-md-2">{(invoiceData.baseAmount + invoiceData.gst).toFixed(2)}</div>
          </div>

          {/* Shipping Charge Row */}
          <div className="row g-2 px-3 py-2 align-items-center bg-light">
            <div className="col-6 col-md-2"></div>
            <div className="col-6 col-md-2"></div>
            <div className="col-6 col-md-2 ps-5 text-muted">Shipping Charge</div>
            <div className="col-6 col-md-2 ps-md-4">{invoiceData.shippingCharge1}</div>
            <div className="col-6 col-md-2">{invoiceData.shippingCharge2}</div>
            <div className="col-6 col-md-2">{invoiceData.shippingCharges}</div>
          </div>

          {/* Total Row */}
          <div className="row g-2 px-3 py-1 align-items-center fw-semibold rounded-bottom-4" style={{ backgroundColor: "#dcf2fa" }}>
            <div className="col-6 col-md-2"></div>
            <div className="col-6 col-md-2">Total</div>
            <div className="col-6 col-md-2">
              {(invoiceData.productTitle?.split("&&&").length || 1)} {/* Total Qty */}
            </div>
            <div className="col-6 col-md-2"></div>
            <div className="col-6 col-md-2 text-success">{(invoiceData.gst + invoiceData.shippingCharge2).toFixed(2)}</div>
            <div className="col-6 col-md-2 text-success">{invoiceData.paidAmount.toFixed(2)}</div>
          </div>
        </div>


        <div className="d-flex justify-content-end mb-2">
          <div className="col-12 col-md-3 bg-light border-start border-4 border-success rounded-4 p-3 shadow-sm">
            <div className="d-flex justify-content-between fw-bold text-dark">
              <span>Grand Total:₹{invoiceData.paidAmount.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="text-center text-muted small fst-italic">
          This is a computer-generated invoice. No signature is required.
        </div>
        <div
          className="mb-2 ps-4 pe-4 pt-2 rounded-4"
        // style={{ backgroundColor: "#eef6f9" }}
        >
          <div className="d-flex flex-column flex-sm-row justify-content-between gap-4 px-2">
            <div className="text-dark w-100">
              <div className="mb-3">
                <h6 className="fw-bold" style={{ color: "#312a88" }}>
                  Direct Deposit / Bank Wire Transfer:
                </h6>
                <p className="mb-1">
                  Deposit the amount at your nearest
                  <br />
                  <strong className="text-uppercase text-secondary">
                    IDFC FIRST BANK
                  </strong>
                  <br />
                  in our accounts in favour of <br />
                  <strong className="text-uppercase text-secondary">
                    Adibliss Infotech Private Limited
                  </strong>
                  .
                </p>
              </div>

              <div className="mb-3">
                <h6 className="fw-bold" style={{ color: "#312a88" }} >
                  Transfer using account:
                </h6>
                <p className="mb-1">
                  <strong>Bank:</strong>  IDFC FIRST BANK
                  <br />
                  <strong>A/C No:</strong>{" "}
                  <span className="text-secondary">10226466663</span>
                  <br />
                  <strong>IFSC Code:</strong>{" "}
                  <span className="text-secondary">IDFB0020101</span>
                </p>
              </div>
            </div>
            <div className="text-dark w-100">
              <div className="mb-3">
                <h6 className="fw-bold" style={{ color: "#312a88" }}>

                  Confirmation:
                </h6>
                <p className="mb-1">
                  Send the payment confirmation to:
                  <a
                    href="mailto:adiblissinfotech@gmail.com"
                    className="text-decoration-none text-success ms-1"
                  >
                    adiblissinfotech@gmail.com
                  </a>
                </p>
              </div>

              <div>
                <h6 className="fw-bold" style={{ color: "#312a88" }} >
                  More Info:
                </h6>
                <p className="mb-0">
                  Visit our website:
                  <a
                    href="https://elvyn.co.in/"
                    target="_blank"
                    className="text-decoration-none text-success ms-1"
                  >
                    https://elvyn.co.in/
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
        {/* <div className="row order-details flex mb-4 mt-4">
  <div className="col-12 customer-details mt-1">
    <span >
      Direct Deposit / Bank Wire Transfer:<br />
      <span style={{ marginLeft: '', display: 'inline-block' }}>
        Deposit the amount at your nearest JANA SMALL FINANCE BANK in our accounts in favour of KASHIRALABS INDIA PVT LTD.
      </span>
    </span>
  </div>

  <div className="col-12 customer-details mt-1">
    <span >
      Transfer using account:<br />
      <span style={{ marginLeft: '', display: 'inline-block' }}>
        Jana Small Finance Bank A/C No:  4759020001219416 <br></br> IFSC-JSFB0004759
      </span>
    </span>
  </div>
  <div className="col-12 customer-details mt-1">
    <span >
        <br />
     <span style={{ marginLeft: '', display: 'inline-block' }}>
  Send confirmation email to <a href="mailto:support@xuwi.in">support@xuwi.in</a>
</span>
    </span>
  </div>

  <div className="col-12 customer-details mt-1">
   <span>
  For Full Details Visit Our Website: <a href="https://xuwi.co.in" target="_blank" rel="noopener noreferrer">xuwi.co.in</a><br />
</span>

  </div>
</div> */}



        <div
          style={{
            marginTop: "1%",
            textAlign: "center",
            fontSize: "16px",
            fontWeight: "600",
          }}
        >
          1st Floor,Office No.F-01A-72 Upper Level,Haware Centurion,Plot No 88 to 91 Navi Mumba,Nerul East, Navi Mumbai,Thane,Maharashtra Pin Code 400706
        </div>
      </div>

    </div>
  );
};
function InvoiceElyvnFormat() {
  const auth = localStorage.getItem("user");
  const location = useLocation(); // Get the location object
  const { item, module } = location.state || {}; // Access the object passed via state
  const downloadPDF = async () => {
    const input = document.getElementById("invoice"); // Select the invoice container
    const formData = new FormData();
    formData.append("orderNo", item.orderNo);
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG"); // Convert canvas to image
      const pdf = new jsPDF("p", "mm", "a4"); // Create a jsPDF document
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight); // Add image to PDF
      pdf.save(`${item.orderNo}` + ".pdf"); // Save PDF
    });
    const config = {
      headers: {
        "Content-type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${auth}`,
      },
    };
    if (module !== "/Invoice/Downloaded") {
      await axios.post(
        `${baseUrl}/changeStatusDownloadedInvoice`,
        formData,
        config
      );
    }
  };
  return (
    <div>
      <div className="row m-0 p-0">
        <div className="col-6">
          <Link to={`${module}`}>
            <button
              style={{
                backgroundColor: "#ff9707",
                color: "#fff",
                width: "80px",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "16px",
                marginTop: "20px",
                padding: "4px 5px",
              }}
            // onClick={downloadPDF}
            >
              Back
            </button>
          </Link>
        </div>
        <div className="col-5 offset-1">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width: "80px",
              padding: "4px 5px",
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
      <InvoiceDetails invoiceData={item} />
    </div>
  );
}
export default InvoiceElyvnFormat;





