import React, { useState, useEffect } from "react";
import "./Header.css";
import { styled, alpha } from "@mui/material/styles";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import InputBase from "@mui/material/InputBase";
import Badge from "@mui/material/Badge";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import Button from "@mui/material/Button";
import SearchIcon from "@mui/icons-material/Search";
import NotificationsIcon from "@mui/icons-material/Notifications";
import MoreIcon from "@mui/icons-material/MoreVert";
import Avatar from "@mui/material/Avatar";
import { Divider, Typography } from "@mui/material";
import {Link} from "react-router-dom"
import MenuIcon from "@mui/icons-material/Menu";
import Stack from "@mui/material/Stack";
import DoneAllIcon from "@mui/icons-material/DoneAll";
import { useStateContext } from "../../context/ContextProvider";
import { useNavigate } from "react-router";
import Popover from "@mui/material/Popover";
import MenuItemProfile from '@mui/icons-material/PersonAddAltOutlined';
import axios from "axios";
import baseUrl from "../config/baseUrl";

const Header = ({ handleToggleSidebar, isSidebarOpen }) => {
  const { setIsLoginUser,profileImage} = useStateContext();
  const [greeting, setGreeting] = useState('');
  const auth = localStorage.getItem("user");
  const userName = localStorage.getItem("userName")
  const navigate = useNavigate();
  const [anchorEle, setAnchorEle] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false)

  const open = Boolean(anchorEle);
  const id = open ? "simple-popover" : undefined;


  useEffect(() => {
    const setGreetingMessage = () => {
      const now = new Date();
      const hours = now.getHours(); // Get the current hour (0-23)
      if (hours >= 0 && hours < 12) {
        setGreeting('Good Morning');
      } else if (hours >= 12 && hours < 17) {
        setGreeting('Good Afternoon');
      } else {
        setGreeting('Good Evening');
      }
    };

    setGreetingMessage();

    // Optional: Update the greeting every minute
    const intervalId = setInterval(setGreetingMessage, 60000);

    return () => clearInterval(intervalId); // Cleanup on unmount
  }, []);

  const Search = styled("div")(({ theme }) => ({
    position: "relative",
    borderRadius: theme.shape.borderRadius * 2,
    backgroundColor: alpha(theme.palette.grey[200], 0.5),
    "&:hover": {
      backgroundColor: alpha(theme.palette.grey[200], 0.7),
    },
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      marginLeft: theme.spacing(3),
      width: "auto",
    },
  }));
  const SearchIconWrapper = styled("div")(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: "100%",
    position: "absolute",
    pointerEvents: "none",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  }));
  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: theme.palette.text.primary,
    "& .MuiInputBase-input": {
      padding: theme.spacing(1, 1, 1, 0),
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create("width"),
      width: "100%",
      [theme.breakpoints.up("md")]: {
        width: "30ch",
      },
    },
  }));
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = React.useState(null);
  const [dropdownAnchorEl, setDropdownAnchorEl] = React.useState(null);
  const isMenuOpen = Boolean(anchorEl);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
  const isDropdownOpen = Boolean(dropdownAnchorEl);
  const handleProfileMenuOpen = (event) => {
    setAnchorEle(event.currentTarget);
  };
  const handleMobileMenuClose = () => {
    setMobileMoreAnchorEl(null);
  };
  const handleMenuClose = () => {
    setAnchorEl(null);
    handleMobileMenuClose();
  };
  const handleMobileMenuOpen = (event) => {
    setMobileMoreAnchorEl(event.currentTarget);
  };
  // const handleDropdownOpen = (event) => {
  //   setDropdownAnchorEl(event.currentTarget);
  // };
  // const handleDropdownClose = () => {
  //   setDropdownAnchorEl(null);
  // };
  const menuId = "primary-search-account-menu";
  const renderMenu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      id={menuId}
      keepMounted
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      open={isMenuOpen}
      onClose={handleMenuClose}
    >
      <MenuItem onClick={handleMenuClose}>Profile</MenuItem>
      <MenuItem onClick={handleMenuClose}>My account</MenuItem>
    </Menu>
  );
  const mobileMenuId = "primary-search-account-menu-mobile";
  const renderMobileMenu = (
    <Menu
      anchorEl={mobileMoreAnchorEl}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      id={mobileMenuId}
      keepMounted
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      open={isMobileMenuOpen}
      onClose={handleMobileMenuClose}
    >
      {/* <MenuItem>

        <IconButton
          size="large"
          aria-label="show 17 new notifications"
          color="inherit"
          type="button"
          data-bs-toggle="modal"
          data-bs-target="#staticBackdrop"
          onClick={handleClick}
        >
          <Badge badgeContent={count} color="error">
            <NotificationsIcon style={{ color: "#000" }} />
          </Badge>
          <p style={{ fontSize: "15px", marginLeft: "20px" }}>Notifications</p>
        </IconButton>

        <div
          className="modal fade"
          id="staticBackdrop"
          data-bs-backdrop="static"
          data-bs-keyboard="false"
          tabIndex="-1"
          aria-labelledby="staticBackdropLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog modal-dialog-scrollable">
            <div className="modal-content">
              <div className="modal-header">
                <h1 className="modal-title fs-5" id="staticBackdropLabel">
                  Notifications
                </h1>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div className="modal-body" style={{ height: "25rem" }}>
                {adminsNotification.map((item, index) => (
                  <div className="row" key={index} style={{ marginBottom: "20px", padding: "10px" }}>
                    <div className="col-2">
                      <Stack direction="row" spacing={2}>
                        <Avatar alt="User Avatar" src="https://cdn-icons-png.flaticon.com/128/16306/16306974.png" />
                      </Stack>
                    </div>
                    <div className="col-10">
                      <p className="title" style={{ fontSize: "16px", fontWeight: "bold", margin: "0 0 5px 0", color: "#333" }}>
                        By Admin
                      </p>
                      <p style={{ fontSize: "14px", margin: "0 0 10px 0", fontWeight: "500", color: "#555", padding: "8px", borderRadius: "4px", border: "1px solid #ddd", backgroundColor: "#f9f9f9" }}>
                        {item.message}
                      </p>
                      <div className="row" style={{ fontSize: "14px" }}>
                        <div className="col-5" style={{ fontWeight: "600", color: "#777" }}>
                          {item.message_dateTime.date}
                        </div>
                        <div className="col-7" style={{ fontWeight: "600", color: "#777", textAlign: "right" }}>
                          {item.message_dateTime.Time}
                        </div>
                      </div>
                    </div>
                    <Divider style={{ width: "100%", margin: "10px 0" }} />
                  </div>
                ))}
              </div>
              <div className="modal-footer d-flex justify-content-between align-items-center">
                <div className="d-flex">
                  <DoneAllIcon className="text-primary" />
                  <p className="ms-2 text-primary">Mark all as read</p>
                </div>
                <button type="button" className="btn btn-primary" onClick={clearAllNotifications}>
                  clear all
                </button>
              </div>
            </div>
          </div>
        </div>
      </MenuItem> */}
      <MenuItem>
      <Link to="/employee/EditProfile" style={{display:"flex",textDecoration:"none",fontSize: "15px",color:"black"}}>
      <MenuItemProfile className="ms-3"/>
        <p style={{ fontSize: "15px", marginLeft: "20px",color:"black" }}>Profile</p>
        </Link>
      </MenuItem>
    </Menu>
  );
  // const renderDropdownMenu = (
  //   <Menu
  //     anchorEl={dropdownAnchorEl}
  //     open={isDropdownOpen}
  //     onClose={handleDropdownClose}
  //     anchorOrigin={{ vertical: "top", horizontal: "right" }}
  //     transformOrigin={{ vertical: "top", horizontal: "right" }}
  //   >
  //     <MenuItem onClick={handleDropdownClose}>Option 1</MenuItem>
  //     <MenuItem onClick={handleDropdownClose}>Option 2</MenuItem>
  //     <MenuItem onClick={handleDropdownClose}>Option 3</MenuItem>
  //   </Menu>
  // );
  const handleLogout = () => {
    setIsModalOpen(true); // Open modal when logout is clicked
  };
  const LoggedOut = () => {
    const auth = localStorage.getItem('user')
    const fatchlogoutattendance = async () => {
      try {
        const config = {
          headers: {
            "Content-type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ${auth}`,
          },
        };
        let result = await axios.post(`${baseUrl}/logout_employee`, {}, config);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    setTimeout(() => {
      fatchlogoutattendance()
      setIsModalOpen(false);
      localStorage.clear("user");
      localStorage.clear("role");
      setIsLoginUser(undefined);
      navigate("/employee/login-employee");
    }, 1000);
  };



  return (
    <Box sx={{ flexGrow: 1 }} className="d-flex" >
      <AppBar
        position="static"
        sx={{
          backgroundColor: "#fff",
          color: "#000",
          boxShadow: "none", // Remove box shadow
          borderBottom: "1px solid #e0e0e0", // Add bottom border
        }}

      >
        <Toolbar className="padding-small-screen">
          <Box sx={{ display: "flex", alignItems: "center", }}>
            {/* <IconButton
                size="large"
                edge="start"
                color="inherit"
                aria-label="menu"
                className="menu-icon "
              > */}
            {!isSidebarOpen && <MenuIcon onClick={handleToggleSidebar} />}
            {/* </IconButton> */}
            <IconButton
              size="large"
              edge="end"
              aria-label="account of current user"
              aria-controls={menuId}
              aria-haspopup="true"
              color="inherit"
            >
              <Avatar src={`${baseUrl}/${profileImage}`} alt="Profile Image" className="profile-set" title="profile" />
            </IconButton>
            <Box className="greet-name">
              <Typography className="header-greeting">{greeting}</Typography>
              <Typography className="header-userName" variant="caption"  title="User Name">{userName}</Typography>
            </Box>
          </Box>
          <Box
            sx={{
              flexGrow: 1,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Search className="header-search">
              <SearchIconWrapper>
                <SearchIcon />
              </SearchIconWrapper>
              <StyledInputBase
                placeholder="Search…"
                inputProps={{ "aria-label": "search" }}
                title="Search Bar"
              />
            </Search>

          </Box>
          {/* <Box style={{marginRight:"90px"}}>
            <AsignMerchant />
          </Box> */}
          {/* <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <IconButton
              size="large"
              aria-label="show 17 new notifications"
              color="inherit"
              className="notification-icon"
              sx={{ display: { xs: "none", md: "flex" } }}
              aria-describedby={id}
              variant="contained"
              onClick={handleProfileMenuOpen}
              title="Notification"
            >
              <Badge badgeContent={count} color="error">
                <NotificationsIcon style={{ color: "#000" }} />
              </Badge>
            </IconButton>
            <Popover
              id={id}
              open={open}
              anchorEl={anchorEle}
              onClose={handleClose}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
              style={{ marginLeft: "-38px", height: "75%" }}
            >
              <div style={{ width: "315px", padding: "10px", overflowY: "hidden" }}>
                <div>
                  <Typography variant="h6" component="div" style={{ fontWeight: "bold", textShadow: "1px 1px red" }}>
                    Notifications
                  </Typography>
                  <hr />
                  <div style={{ maxHeight: "290px", ooverflowY: "auto", overflowX: "hidden" }}>
                    {adminsNotification.map((item, index) => (
                      <div className="row" key={index} style={{ marginBottom: "20px", padding: "10px" }}>
                        <div className="col-2">
                          <Stack direction="row" spacing={2}>
                            <Avatar alt="User Avatar" src="https://cdn-icons-png.flaticon.com/128/16306/16306974.png" />
                          </Stack>
                        </div>
                        <div className="col-10">
                          <p className="title" style={{ fontSize: "16px", fontWeight: "bold", margin: "0 0 5px 0", color: "#333" }}>
                            By Admin
                          </p>
                          <p style={{ fontSize: "14px", margin: "0 0 10px 0", fontWeight: "500", color: "#555", padding: "8px", borderRadius: "4px", border: "1px solid #ddd", backgroundColor: "#f9f9f9" }}>
                            {item.message}
                          </p>
                          <div className="row" style={{ fontSize: "14px" }}>
                            <div className="col-5" style={{ fontWeight: "600", color: "#777" }}>
                              {item.message_dateTime.date}
                            </div>
                            <div className="col-7" style={{ fontWeight: "600", color: "#777", textAlign: "right" }}>
                              {item.message_dateTime.time}
                            </div>
                          </div>
                        </div>
                        <Divider style={{ width: "100%", margin: "10px 0" }} />
                      </div>
                    ))}
                  </div>
                  <div className="d-flex justify-content-between align-items-center mt-3 pb-2 b-0">
                    <div className="d-flex align-items-center">
                      <DoneAllIcon className="text-primary" />
                      <p className="ms-2 text-primary" style={{ margin: 0 }} title="Read All">
                        Mark all as read
                      </p>
                    </div>
                    <Button size="small" variant="contained" onClick={clearAllNotifications} title="Delete All">
                      clear all
                    </Button>
                  </div>
                </div>

              </div>
            </Popover>
            <Button
              variant="contained"
              color="primary"
              sx={{ ml: 2 }}
              onClick={handleLogout}
              title="Log Out"
            >
              Log Out
            </Button>
            {isModalOpen && (
        <LogoutModal open={isModalOpen} onClose={() => setIsModalOpen(false)} LoggedOut={LoggedOut} />
      )}
          </Box> */}
          <Box sx={{ display: { xs: "flex", md: "none" } }}>
            <IconButton
              size="large"
              aria-label="show more"
              aria-controls={mobileMenuId}
              aria-haspopup="true"
              onClick={handleMobileMenuOpen}
              color="inherit"
            >
              <MoreIcon />
            </IconButton>
          </Box>
        </Toolbar>
      </AppBar>
      {renderMobileMenu}
      {renderMenu}
      {/* {renderDropdownMenu} */}
    </Box>
  );
};
export default Header;


