import React from "react";
// import "./dotOneDeliveryChallanFormat.css";
// import elvyn from "./elvyn.png";
// import CompanySignature from "./dotOneCompanySignature.jpeg"
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import axios from "axios";
import baseUrl from "../config/baseUrl";
import { Link, useLocation } from 'react-router-dom';
const InvoiceDotOneFormat = () => {
    const theme = {
        purple: "#6f42c1",
        black: "#000000",
        white: "#ffffff",
        lightGray: "#f8f9fa",
        gradient: "linear-gradient(to right, #6f42c1, #4b2b8c)",
    };
    const auth = localStorage.getItem("user")
    const location = useLocation(); // Get the location object
    const { item, module } = location.state || {}; // Access the object passed via state
    let fullNameStartLetter = item.fullName ? item.fullName.split("")[0] : ""
    const downloadPDF = async () => {
        const input = document.getElementById("deliveryChallan"); // Select the invoice container
        const formData = new FormData();
        formData.append("orderNo", item.orderNo)
        const options = {
            useCORS: true,
            logging: true,
            allowTaint: false,
            scrollX: 0,
            scrollY: -window.scrollY,  // Handle scrolling if needed
        };
        html2canvas(input, options).then((canvas) => {
            const imgData = canvas.toDataURL("image/JPEG"); // Convert canvas to image
            const pdf = new jsPDF("p", "mm", "a4"); // Create a jsPDF document
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

            pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight); // Add image to PDF
            pdf.save("dc_" + `${item.orderNo}` + ".pdf"); // Save PDF
        });
        const config = {
            headers: {
                "Content-type": "application/json",
                Accept: "application/json",
                Authorization: `Bearer ${auth}`,
            },
        };
        if (module !== "/invoice/DownloadedChalaan") {
            const response = await axios.post(`${baseUrl}/changeStatusDeliveryChallan`, formData, config)
        }
    };
    return (
        <div>
            <div className="row ms-4 me-4">
                <div className="col-6">
                    <Link to={`${module}`}>
                        <button
                            style={{
                                backgroundColor: "#ff9707",
                                color: "#fff",
                                width: "80px",
                                border: "none",
                                borderRadius: "5px",
                                cursor: "pointer",
                                fontSize: "16px",
                                marginTop: "20px",
                                padding: "4px 5px"
                            }}
                        // onClick={downloadPDF}
                        >
                            Back
                        </button>
                    </Link>
                </div>
                <div className="col-6 text-end">
                    <button
                        style={{
                            backgroundColor: "#ff9707",
                            color: "#fff",
                            border: "none",
                            borderRadius: "5px",
                            cursor: "pointer",
                            fontSize: "16px",
                            marginTop: "20px",
                            width: "80px",
                            padding: "4px 5px"
                        }}
                        onClick={downloadPDF}
                    >
                        Download
                    </button>
                </div>
            </div>
            <div className='delivery-chalaan-container mt-4 mb-4 me-3 p-4' id="deliveryChallan">
                <div className="container my-4 px-3 px-md-5 py-4" style={{ backgroundColor: theme.white, borderRadius: "16px", boxShadow: "0 0 30px rgba(0,0,0,0.1)", fontFamily: "'Segoe UI', sans-serif", maxWidth: "1300px", }}>
                    <div className="py-4 px-3 mb-4 text-white">
                        <div className="d-flex flex-row justify-content-between align-items-start gap-3">
                            {/* Company Info Section */}
                            <div>
                                <div className="mb-3">
                                    <img
                                        src={"elvyn"}
                                        alt="Company Logo"
                                        style={{
                                            width: "80px",
                                            height: "80px",
                                            objectFit: "contain",
                                            borderRadius: "8px",
                                        }}
                                    />
                                </div>
                                <div>
                                    <div className="row mb-2">
                                        <div
                                            className="col-12"
                                            style={{ fontWeight: 800, fontSize: "1.25rem", color: "#0d6efd" }}
                                        >
                                            Adibliss Infotech Private Limited
                                        </div>
                                    </div>
                                    <p className="mb-2">
                                        <strong style={{ fontWeight: 800 }}>Address:</strong> 1st Floor, Office No. F-01A-72 Upper Level, Haware Centurion, Plot No. 88 to 91, Navi Mumbai, Nerul East, Thane, Maharashtra - 400706
                                    </p>
                                    <p className="mb-1" >
                                        <strong style={{ fontWeight: 800 }}>Phone:</strong> +91 7065424993
                                    </p>
                                    <p className="mb-1">
                                        <strong style={{ fontWeight: 800 }}>Email:</strong> adiblissinfotech@gmail.com
                                    </p>
                                    <p className="mb-0">
                                        <strong style={{ fontWeight: 800 }}>GSTIN:</strong> 08AAFCE8006Q1Z6
                                    </p>
                                </div>
                            </div>

                            {/* Challan Info Section */}
                            <div className="text-end">
                                <h4 className="fw-bold mt-1" style={{ fontWeight: 800 }}>Delivery Challan</h4>
                                <p className="mb-1">
                                    <strong style={{ fontWeight: 700 }}>Challan No:</strong> {item.orderNo}
                                </p>
                                <p>
                                    <strong style={{ fontWeight: 700 }}>Date:</strong> {item.transactionInvoiceCreatedOn ? item.transactionInvoiceCreatedOn.split(" ")[0] : ""}
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="row mb-4">
                        {/* Billing Information */}
                        <div className="col-12 col-md-6 mb-3 mb-md-0">
                            <div className="p-3 border rounded shadow-sm h-100">
                                <h5 className="fw-bold mb-3" style={{ color: theme.purple }}>
                                    Billing Information
                                </h5>
                                <ul className="list-unstyled small mb-0" >
                                    <li className="mb-3"><strong>Name:</strong> {item.fullName}</li>
                                    <li className="mb-3"><strong>Address:</strong> {item.billingAddress}</li>
                                    <li className="mb-3"><strong>Phone:</strong> {item.mobileNo}</li>
                                    <li className="mb-3"><strong>Email:</strong> {item.Email}</li>
                                    <li className="mb-3"><strong>GSTIN:</strong> {item.billingGSTIN || '----'}</li>
                                    <li className="mb-0"><strong>Challan No:</strong> {item.orderNo}</li>
                                </ul>
                            </div>
                        </div>

                        {/* Shipping Information */}
                        <div className="col-12 col-md-6">
                            <div className="p-3 border rounded shadow-sm h-100">
                                <h5 className="fw-bold mb-3" style={{ color: theme.purple }}>
                                    Shipping Information
                                </h5>
                                <ul className="list-unstyled small mb-0">
                                    <li className="mb-3"><strong>Name:</strong> {item.fullName}</li>
                                    <li className="mb-3"><strong>Address:</strong> {item.billingAddress}</li>
                                    <li className="mb-3"><strong>Phone:</strong> {item.mobileNo}</li>
                                    <li className="mb-3"><strong>Email:</strong> {item.Email}</li>
                                    <li className="mb-3"><strong>GSTIN:</strong> {item.shippingGSTIN || '----'}</li>
                                    <li className="mb-0"><strong>Delivery Time:</strong> {item.deliveryTime}</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div className="table-responsive mb-4">
                        <table className="table table-bordered align-middle mb-0">
                            <thead style={{ background: "linear-gradient(to right, #6f42c1, #4b2b8c)", color: "#ffffff", letterSpacing: "0.6px", fontSize: "15px", textTransform: "uppercase" }}>
                                <tr className="text-center text-nowrap">
                                    <th style={{ padding: "14px" }}>SL</th>
                                    <th style={{ padding: "14px" }}>Product</th>
                                    <th style={{ padding: "14px" }}>Category</th>
                                    <th style={{ padding: "14px" }}>Qty</th>
                                    <th style={{ padding: "14px" }}>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="text-center" style={{ backgroundColor: "#fdfcfe", color: "#212529" }}>
                                    <td style={{ padding: "12px" }}>1</td>
                                    <td style={{ padding: "12px" }}>{item.productName}</td>
                                    <td style={{ padding: "12px" }}>{item.productTitle}</td>
                                    <td style={{ padding: "12px" }}>1</td>
                                    <td style={{ padding: "12px" }}>₹{item.paidAmount}</td>
                                </tr>
                                <tr style={{ backgroundColor: "#ede4fb" }}>
                                    <td colSpan="4" className="text-end fw-bold" style={{ padding: "14px", color: "#4b2b8c" }}>
                                        Total
                                    </td>
                                    <td className="fw-bold text-center" style={{ padding: "14px", color: "#4b2b8c" }}>
                                        ₹{item.paidAmount}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div className="p-3 mb-4 rounded" style={{ backgroundColor: theme.lightGray }}>
                        <h5 className="fw-bold mb-2" style={{ color: theme.purple }}>
                            Terms & Conditions
                        </h5>
                        <ul className="mb-0 small ps-3">
                            <li>Amount cannot be refunded.</li>
                            <li>If package is damaged, exchange is available.</li>
                        </ul>
                    </div>
                    <div className="row gap-3">
                        {/* Authorized Signature Section */}
                        <div className="col-md-6 d-flex flex-column">
                            <p className="fw-bold mb-2" style={{ color: theme.purple }}>
                                Authorized Signature
                            </p>
                            <div className="border rounded shadow-sm bg-white p-3 h-100 d-flex flex-column justify-content-between">
                                <div className="text-center">
                                    <img
                                        src={"CompanySignature"}
                                        alt="Company Signature"
                                        style={{
                                            maxHeight: "100px",
                                            maxWidth: "220px",
                                            objectFit: "contain",
                                            transform: "scale(1.1)",
                                            transformOrigin: "center",
                                        }}
                                    />
                                </div>
                                <div
                                    style={{
                                        borderTop: "2px solid #000",
                                        width: "70%",
                                        margin: "30px auto 10px auto",
                                    }}
                                />
                            </div>
                        </div>

                        {/* Received By Section */}
                        <div className="col-md-5 d-flex flex-column">
                            <p className="fw-bold mb-2" style={{ color: theme.purple }}>
                                Received By
                            </p>
                            <div className="border rounded shadow-sm bg-white p-3 h-100 d-flex flex-column justify-content-between">
                                <div>
                                    <p className="mb-2">
                                        <strong style={{ color: theme.purple }}>Name:</strong> {item.fullName}
                                    </p>
                                    <p className="mb-3">
                                        <strong style={{ color: theme.purple }}>Date:</strong> {item.deliveryDate}
                                    </p>
                                    <div className="text-center mb-2">
                                        <img
                                            src={`${baseUrl}/${fullNameStartLetter}/${item.signatureImageName}`}
                                            alt="Buyer Signature"
                                            style={{
                                                maxHeight: "120px",
                                                maxWidth: "100%",
                                                objectFit: "contain",
                                            }}
                                        />
                                    </div>
                                </div>
                                <div
                                    style={{
                                        borderTop: "2px solid #000",
                                        width: "100%",
                                        marginTop: "30px",
                                    }}
                                />
                            </div>
                        </div>
                    </div>

                </div>



                {/* <div className="row" id="dot-one-format-container">
                    <div className="row m-0 p-0 col-border row-color text-white text-center">
                        <h3>Delivery Challan</h3>
                    </div>
                    <div className="row m-0 p-0 line-gap">
                        <div className="col-6 col-border p-3">
                            <div className="row">
                                <div className="col-12 company-name">DOTONE INFOTECH PRIVATE LIMITED</div>
                            </div>
                            <div className="row mt-3">
                                <div className="col-2 left-head">
                                    Address:
                                </div>
                                <div className="col-6 right-text">
                                    G-2008, Raj Nagar Extension, Ghaziabad,
                                    Ghaziabad, Ghaziabad, Uttar Pradesh-201017
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-2 left-head">Phone No:</div>
                                <div className="col-6 text-start right-text">+91 7065424993</div>
                            </div>
                            <div className="row">
                                <div className="col-2 left-head">Email :</div>
                                <div className="col-6 right-text">support@limezo.in</div>
                            </div>
                            <div className="row">
                                <div className="col-2 left-head">GSTIN :</div>
                                <div className="col-6 right-text">09AAJCD9084F128</div>
                            </div>
                        </div>
                        <div className="col-6 text-center col-border p-3">
                            <img src={"jhj"} alt="image" />
                        </div>
                    </div>
                    <div className="row m-0 p-0 col-border row-color text-white text-center">
                        <div className="col-6 table-column">DELIVERY CHALLAN FOR</div>
                        <div className="col-6 table-column">SHIP TO</div>
                    </div>
                    <div className="row m-0 p-0">
                        <div className="col-6 col-border line-gap p-3">
                            <div className="row">
                                <div className="col-3 left-head">Party Name:</div>
                                <div className="col-9 right-text">{item.fullName}</div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">
                                    Billing Address:
                                </div>
                                <div className="col-9 right-text">
                                    {item.billingAddress}
                                </div>
                            </div>
                            
                            <div className="row">
                                <div className="col-3 left-head">Phone :</div>
                                <div className="col-9 right-text">{item.mobileNo}</div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">Email:</div>
                                <div className="col-9 right-text">{item.Email}</div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">GSTIN:</div>
                                <div className="col-9 right-text">--</div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">Challan No:</div>
                                <div className="col-9 right-text">{item.orderNo}</div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">Challan Date:</div>
                                <div className="col-9 right-text">{item.transactionInvoiceCreatedOn ? (item.transactionInvoiceCreatedOn).split(" ")[0] : ""}</div>
                            </div>
                           
                        </div>
                        <div className="col-6 col-border line-gap p-3">
                            <div className="row">
                                <div className="col-3 left-head">Shipping Name:</div>
                                <div className="col-9 right-text">{item.fullName}</div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">
                                    Shipping Address:
                                </div>
                                <div className="col-9 right-text">
                                    {item.billingAddress}
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">Phone No:</div>
                                <div className="col-9 right-text">{item.mobileNo}</div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">Email:</div>
                                <div className="col-9 right-text">{item.Email}</div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">GSTIN:</div>
                                <div className="col-9 right-text">--</div>
                            </div>
                            <div className="row">
                                <div className="col-3 left-head">Delivery Time:</div>
                                <div className="col-9 right-text">{item.deliveryTime}</div>
                            </div>
                        </div>
                    </div>
                    <div className="row m-0 p-0 col-border row-color text-white text-center">
                        <div className="col-2 table-column">SL NO.</div>
                        <div className="col-3 table-column">Product</div>
                        <div className="col-2 table-column">Category</div>
                        <div className="col-3 table-column">Quantity</div>
                        
                        <div className="col-2 table-column">Amount</div>
                    </div>
                    <div className="row m-0 p-0">
                        <div className="col-2 text-center col-border right-text p-4">1</div>
                        <div className="col-3 text-center col-border right-text p-4 fw-bold">
                            {item.productName}
                        </div>
                        
                        <div className="col-2 text-center col-border right-text p-4">{item.productTitle}</div>
                        <div className="col-3 text-center col-border right-text p-4">1</div>
                   
                        <div className="col-2 text-center col-border right-text p-4">{item.paidAmount} /-</div>
                    </div>
                    <div className="row m-0 p-0 col-border row-color text-white text-center">
                        <div className="col-8 table-column text-end">Total</div>
                        <div className="col-2 table-column">=</div>
                        <div className="col-2 table-column">{item.paidAmount} /-</div>
                    </div>
                    <div className="row m-0 p-0">
                        <div className="col-6 col-border p-3">
                            <div className="row">
                                <div className="col-12 right-text">Terms And Conditions</div>
                            </div>
                            <div className="row">
                                <div className="col-12 right-text">1. Amount can not be Refunded</div>
                            </div>
                            <div className="row">
                                <div className="col-12 right-text">2. if any damage or package broken,exchange is available. </div>
                            </div>
                        </div>
                        <div className="col-6 col-border p-3">
                            <div className="row m-0 p-0 text-center">
                                <div className="col-12">
                                    For Company Signature
                                </div>
                            </div>
                            <div className="row m-0 p-3 text-center">
                                <div className="col-12">
                                    <img src={CompanySignature} alt="image" style={{ height: "87px", width: "192px", transform: "scale(1.2)", transformOrigin: "center" }} />
                                </div>
                            </div>
                            <div className="row m-0 p-0 text-center">
                                <div className="col-12">
                                    Authorize Signature
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row m-0 p-0 col-border row-color text-center" style={{ opacity: "1", color: "rgb(167 56 56)" }}>
                        .
                    </div>
                    <div className="row m-0 p-0 col-border line-gap">
                        <div className="col-6 col-border p-3">
                            <div className="row">
                                <div className="col-12 left-head">Received By:</div>
                            </div>
                            <div className="row">
                                <div className="col-2 left-head">Name:</div>
                                <div className="col-6 right-text">{item.fullName}</div>
                            </div>
                            <div className="row">
                                <div className="col-2 left-head">Comment:</div>
                               
                            </div>
                            <div className="row">
                                <div className="col-2 left-head">Date:</div>
                                <div className="col-6 right-text">{item.deliveryDate}</div>
                            </div>
                            <div className="row">
                                <div className="col-2 left-head">Signature:</div>
                               
                            </div>
                        </div>
                        <div className="col-6">
                            <div className="row">
                                <div className="col-12 p-3">
                                    <img
                                        src={`${baseUrl}/${fullNameStartLetter}/${item.signatureImageName}`}
                                        alt="buyer Sign"
                                        style={{ minWidth: "400px", height: "130px" }}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div> */}
            </div>
        </div>

    );
};

export default InvoiceDotOneFormat;