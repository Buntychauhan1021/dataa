import React from "react";
import logo from "./LogoImg.png";
import CompanySignature from "./signature.jpeg"
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import axios from "axios";
import baseUrl from "../config/baseUrl";
import { Link, useLocation } from 'react-router-dom';
const InvoiceDotOneFormat = () => {
    const auth = localStorage.getItem("user")
    const location = useLocation(); // Get the location object
    const { item, module } = location.state || {}; // Access the object passed via state
    let fullNameStartLetter = item.fullName ? item.fullName.split("")[0] : ""
    const downloadPDF = async () => {
        const input = document.getElementById("deliveryChallan"); // Select the invoice container
        const formData = new FormData();
        formData.append("orderNo", item.orderNo)
        const options = {
            useCORS: true,  // Enable CORS to load external images
            logging: true,  // Enable logging for debugging
            allowTaint: false,  // Prevent canvas tainting
            scrollX: 0,
            scrollY: -window.scrollY,  // Handle scrolling if needed
        };
        html2canvas(input, options).then((canvas) => {
            const imgData = canvas.toDataURL("image/JPEG"); // Convert canvas to image
            const pdf = new jsPDF("p", "mm", "a4"); // Create a jsPDF document
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

            pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight); // Add image to PDF
            pdf.save("dc_" + `${item.orderNo}` + ".pdf"); // Save PDF
        });
        const config = {
            headers: {
                "Content-type": "application/json",
                Accept: "application/json",
                Authorization: `Bearer ${auth}`,
            },
        };
        if (module !== "/invoice/DownloadedChalaan") {
            const response = await axios.post(`${baseUrl}/changeStatusDeliveryChallan`, formData, config)
        }
    };
    return (
        <div style={{
            //  width: "800px",
            marginLeft: "10px",
            marginTop: "30px",
            marginBottom: "30px",
        }}>
            <div className="row ms-4 me-4">
                <div className="col-6">
                    <Link to={`${module}`}>
                        <button
                            style={{
                                backgroundColor: "#ff9707",
                                color: "#fff",
                                width: "80px",
                                border: "none",
                                borderRadius: "5px",
                                cursor: "pointer",
                                fontSize: "16px",
                                marginTop: "20px",
                                padding: "4px 5px"
                            }}
                        // onClick={downloadPDF}
                        >
                            Back
                        </button>
                    </Link>
                </div>
                <div className="col-6 text-end">
                    <button
                        style={{
                            backgroundColor: "#ff9707",
                            color: "#fff",
                            border: "none",
                            borderRadius: "5px",
                            cursor: "pointer",
                            fontSize: "16px",
                            marginTop: "20px",
                            width: "80px",
                            padding: "4px 5px"
                        }}
                        onClick={downloadPDF}
                    >
                        Download
                    </button>
                </div>
            </div>
            <div className='delivery-chalaan-container mt-4 mb-4 me-3 p-4' id="deliveryChallan">
                <div style={{ background: "#f7f9fc", minHeight: "100vh", padding: "40px 20px" }}>
                    <div className="container" style={{ maxWidth: "1100px" }}>
                        <div className="bg-white rounded shadow p-4">
                            <div className="rounded p-4 mb-2 " style={{ backgroundColor: "#2f3d55ff", boxShadow: "0 0 10px rgba(26, 26, 26, 0.5)" }}>
                                <div className="d-flex justify-content-between align-items-center flex-column flex-md-row gap-3 mb-4">
                                    <div className="d-flex align-items-center w-100">
                                        <img src={logo} alt="Streakgen" style={{ height: 70 }} />
                                        <div className="ms-auto text-white text-end">
                                            <div><strong>Challan No:</strong> {item.orderNo}</div>
                                            <div><strong>Date:</strong> {item.transactionInvoiceCreatedOn ? (item.transactionInvoiceCreatedOn).split(" ")[0] : ""}</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="text-white" style={{ fontSize: "15px" }}>
                                    <div><span className="text-primary fw-bold">Address :</span> STREAKGEN TECHNOLOGY PRIVATE LIMITED
                                        Address - Shop No FF-106, Aditya Avenew, P No 102 TO 107, Sidsar Road, Shivalik Arogyadham, Chitra, Bhavnagar, Gujarat - 364004</div>
                                    <div><span className="text-primary fw-bold">Phone :</span> +91 9327340307</div>
                                    <div><span className="text-primary fw-bold">Email :</span> streakgentechnology@gmail.com</div>
                                    <div><span className="text-primary fw-bold">GSTIN :</span> 24ABPCS1413A1ZU</div>
                                </div>
                            </div>


                            {/* Billing & Shipping Combined */}
                            <div className=" border shadow-sm p-0 mb-2 d-flex" style={{ backgroundColor: "#244984ff" }}>
                                <div className="p-3 flex-fill " style={{ minWidth: "50%", borderRight: "3px solid #4479ffff" }}>
                                    <h6 className="fw-bold mb-2 fs-5 text-black">Billing Information</h6>
                                    <div className="text-white" style={{ fontSize: 14 }}>
                                        <div><span className="text-black fw-bold">Name : </span>  {item.fullName}</div>
                                        <div><span className="text-black fw-bold">Address :</span> {item.billingAddress}</div>
                                        <div><span className="text-black fw-bold">Phone :</span> {item.mobileNo}</div>
                                        <div><span className="text-black fw-bold">Email :</span> {item.Email}</div>
                                        <div><span className="text-black fw-bold">Challan No :</span> {item.orderNo}</div>
                                    </div>
                                </div>
                                <div className="p-3 flex-fill" style={{ minWidth: "50%" }}>
                                    <h6 className="fw-bold mb-2 fs-5 text-black">Shipping Information</h6>
                                    <div className="text-white" style={{ fontSize: 14 }}>
                                        <div><span className="text-black fw-bold">Name :</span>  {item.fullName}</div>
                                        <div><span className="text-black fw-bold">Address :</span> {item.billingAddress}</div>
                                        <div><span className="text-black fw-bold">Phone :</span> {item.mobileNo}</div>
                                        <div><span className="text-black fw-bold">Email :</span> {item.Email}</div>
                                        <div><span className="text-black fw-bold">Delivery Time :</span> {item.deliveryTime}</div>
                                    </div>
                                </div>
                            </div>
                            <div
                                style={{
                                    display: "grid",
                                    gap: "1px",
                                    border: "1px solid #555",
                                    fontSize: "14px",
                                    marginBottom: "0.5rem",
                                }}
                            >
                                {/* Header */}
                                <div
                                    style={{
                                        display: "grid",
                                        gridTemplateColumns: "1fr 3fr 3fr 1fr 2fr",
                                        alignItems: "center",
                                        textAlign: "center",
                                        backgroundColor: "#112e5c",
                                        color: "#fff",
                                        fontWeight: "bold",
                                        padding: "10px 0",
                                    }}
                                >
                                    <div>SL</div>
                                    <div>ITEM</div>
                                    <div>CATEGORY</div>
                                    <div>QTY</div>
                                    <div>PAID AMOUNT</div>
                                </div>

                                {/* Products Loop */}
                                {(item.productName?.split("&&&") || []).map((productName, index) => (
                                    <div
                                        key={index}
                                        style={{
                                            display: "grid",
                                            gridTemplateColumns: "1fr 3fr 3fr 1fr 2fr",
                                            alignItems: "center",
                                            textAlign: "center",
                                            backgroundColor: "#111",
                                            color: "#fff",
                                            padding: "10px 0",
                                        }}
                                    >
                                        <div>{index + 1}</div>
                                        <div>{productName}</div>
                                        <div>{item.productTitle?.split("&&&")[index]}</div>
                                        <div>1</div>
                                        {/* <div>₹{item.productPrice?.split("&&&")[index]}</div> */}
                                        <div>""</div>
                                    </div>
                                ))}
                                <div
                                    style={{
                                        display: "grid",
                                        gridTemplateColumns: "1fr 3fr 3fr 1fr 2fr",
                                        alignItems: "center",
                                        textAlign: "center",
                                        backgroundColor: "#f8f9fa",
                                        fontWeight: "bold",
                                        padding: "10px 0",
                                        color: "#000",
                                    }}
                                >
                                    <div style={{ gridColumn: "1 / span 4", textAlign: "right", paddingRight: "10px" }}>
                                        Total
                                    </div>
                                    <div>₹{item.paidAmount}</div>
                                </div>
                            </div>




                            {/* Terms & Signatures */}
                            <div className="rounded p-4" style={{ backgroundColor: "#2f3d55ff", boxShadow: "0 0 10px rgba(26, 26, 26, 0.5)" }}>

                                <div className="d-flex flex-row flex-md-row gap-4 align-items-start">
                                    <div className="row">
                                        <div className="col-md-6 mb-3">
                                            <h6 className="fw-bold mb-1 text-white">Terms & Conditions</h6>
                                            <ul className="mb-2 text-white" style={{ fontSize: 14 }}>
                                                <li>Amount cannot be refunded.</li>
                                                <li>If package is damaged, exchange is available.</li>
                                            </ul>
                                            <div className="fw-bold mb-2 text-white">Authorized Signature</div>
                                            <div
                                                className="bg-white text-center"
                                                style={{
                                                    border: "3px dashed #0a0a0aff",
                                                    borderRadius: 8,
                                                    height: 80,
                                                    display: "flex",
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                }}
                                            >
                                                <img
                                                    src={CompanySignature}
                                                    alt="image"
                                                    style={{
                                                        height: "87px",
                                                        width: "192px",
                                                        transform: "scale(0.85)",
                                                        transformOrigin: "center",
                                                    }}
                                                />
                                            </div>
                                        </div>

                                        <div className="col-md-6 mb-3">
                                            <div className="fw-bold mb-2 text-white">Received By</div>
                                            <div className="text-white mb-3">
                                                <strong>Name:</strong> {item.fullName}
                                            </div>
                                            <div className="text-white mb-2">
                                                <strong>Date:</strong> {item.deliveryDate}
                                            </div>
                                            <div
                                                className="bg-white text-center"
                                                style={{
                                                    border: "3px dashed #0a0a0aff",
                                                    borderRadius: 8,
                                                    height: 80,
                                                    display: "flex",
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                }}
                                            >
                                                <img
                                                    src={`${baseUrl}/${fullNameStartLetter}/${item.signatureImageName}`}
                                                    alt="buyer Sign"
                                                    style={{ minWidth: "400px", height: "130px" }}
                                                />
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
};

export default InvoiceDotOneFormat;