import React,{useState} from 'react';
import './login.css'; 
import mainImg from './img/white-outline.png';
import coin from './img/coin.png';
import spring from './img/spring.png'
import rocket from './img/rocket.png'
import dots from './img/dots.png'
import cloud from './img/white-outline.png'
import stars from './img/stars.png'
import { toast } from "react-toastify";
import baseUrl from "../config/baseUrl";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useStateContext } from '../../context/ContextProvider';
const Login = () => {
  const { setIsLoginUser } = useStateContext();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  let [message, setMessage] = useState("");

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = {
      email,
      password
    }
    const config = {
      headers: { "content-type": "multipart/form-data" },
    };
    axios
      .post(`${baseUrl}/login`, data, config)
      .then((response) => {
        setMessage((message = response.data.message));
        if (response.status==200) {
          toast.success(
            <span style={{ fontWeight: "bold", color: "#2626E8" }}>
              Hey {response.data.data.name}, Welcome to Invoice System
            </span>,
            {
              position: "top-center",
              autoClose: 2000,
            }
          );
          setTimeout(() => {
            setIsLoginUser(response.data.data.token);
            localStorage.setItem("user", response.data.data.token);
            localStorage.setItem(
              "timeZone",
              JSON.stringify({ name: "India", timeZone: "Asia/Kolkata" })
            );
            navigate("/invoice/dashboard", { state: { showModal: true } });
          }, 2000);
         
        } else {
          toast.error(message, {
            position: "bottom-right",
            autoClose: 1000,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        toast.error("Something went wrong:link::linked_paperclips:", {
          position: "bottom-right",
          autoClose: 1000,
        });
      });
  };
  return (
    <div className="form-container">
      <div className='inner-container'>
      <div className="col left-section">
        <div className="image-layer">
          <img src={mainImg} alt="Main" className="form-image-main" />
          <img src={dots} alt="Dots" className="form-image dots" />
          <img src={coin} alt="Coin" className="form-image coin" />
          <img src={spring} alt="Spring" className="form-image spring" />
          <img src={rocket} alt="Rocket" className="form-image rocket" />
          <img src={cloud} alt="Cloud" className="form-image cloud" />
          <img src={stars} alt="Stars" className="form-image stars" />
        </div>
        <p className="featured-words">
        <span>DEVELOPED BY</span><br />
          BUNTY, DUSHYANT, VAIBHAV <br />
          PIYUSH, BHAWNA, MAHIMA
        </p>
      </div>
      <div className="col right-section">
        <div className="login-form">
          <div className="form-title">
            <span>Sign In</span>
          </div>
          <div className="form-inputs">
            <div className="input-box">
              <input type="text" className="input-field" placeholder="Username" onChange={(e)=>setEmail(e.target.value)} required />
              <i className="bx bx-user icon"></i>
            </div>
            <div className="input-box">
              <input type="password" className="input-field" placeholder="Password" onChange={(e)=>setPassword(e.target.value)} required />
              <i className="bx bx-lock-alt icon"></i>
            </div>
            <div className="input-box">
              <button className="input-submit" onClick={handleSubmit}>
                <span>Sign In</span>
                <i className="bx bx-right-arrow-alt"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};
export default Login;
