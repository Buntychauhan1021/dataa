import React, { useEffect } from "react";
import Calendar from "../Calendar/Calendar";

const Modal = ({ showModal, setShowModal }) => {
  const handleClose = () => {
    setShowModal(false);
    localStorage.setItem("isModalShown", "true"); // Save flag to localStorage to track modal display
  };

  const modalClass = showModal ? "modal fade show" : "modal fade";

  useEffect(() => {
    if (showModal) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }

    // Cleanup body overflow on component unmount
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [showModal]);

  return (
    <>
      <div
        className={modalClass}
        id="exampleModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden={showModal ? "false" : "true"}
        style={{ display: showModal ? "block" : "none" }}
      >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header p-0">
              <h4 className="modal-title" id="exampleModalLabel">
                CALENDAR
              </h4>
              <button
                type="button"
                className="btn-close"
                onClick={handleClose}
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <Calendar />
            </div>
          </div>
        </div>
      </div>

      {showModal && <div className="modal-backdrop fade show" />}
    </>
  );
};

export default Modal;
