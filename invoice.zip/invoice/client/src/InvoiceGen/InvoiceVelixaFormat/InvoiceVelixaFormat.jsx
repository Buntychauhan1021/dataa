// import { useState } from 'react'
// import "./InvoiceVelixaFormat.css"
// function App() {
//   return (
//     <div className="container-fluid my-2 ">
//       <div className="d-flex justify-content-between align-items-start mb-1 rounded " style={{ backgroundColor: '#adb5bbff' }}>
//         <div className="d-flex align-items-center">
//           <img src="https://zenvvy.co.in/static/media/zenvy_logo.5c9f410ffae24ae02edf.png" alt="Zenvy Logo" style={{ height: '50px', marginRight: '10px' }} />
//           <div>
//             <h6 className="fw-bold mb-1 text-success">Adibliss Infotech Private Limited</h6>
//             <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>GST NO: 08AAFCE8006Q1Z6</p>
//           </div>
//         </div>
//         <small className="text-muted fst-italic me-3 mt-3" >
//           * Keep this invoice for warranty purposes
//         </small>
//       </div>
//       <div className="row g-3 mb-2" >
//         <div className="col-12 col-sm-4">
//           <div className="bg-light rounded p-3 shadow-sm h-100">
//             <h6 className="text-primary fw-bold mb-1">🧾 Order Info</h6>
//             <p className="mb-1">Order ID: <strong>86463200520364850</strong></p>
//             <p className="mb-1">Order Date:20-05-2025</p>
//             <p className="mb-0">Invoice Date:20-05-2025</p>
//           </div>
//         </div>
//         <div className="col-12 col-sm-4">
//           <div className="bg-light rounded p-3 shadow-sm h-100">
//             <h6 className="text-success fw-bold mb-1">📍 Billing Address</h6>
//             <p className="mb-1">Udai Bhadresha</p>
//             <p className="mb-1">Jama Masjid, Delhi 110006</p>
//             <p className="mb-0">📞 9118877413</p>
//           </div>
//         </div>
//         <div className="col-12 col-sm-4">
//           <div className="bg-light rounded p-3 shadow-sm h-100">
//             <h6 className="text-warning fw-bold mb-1">🚚 Shipping Address</h6>
//             <p className="mb-1">Udai Bhadresha</p>
//             <p className="mb-1">Jama Masjid, Delhi 110006</p>
//             <p className="mb-0">📞 9118877413</p>
//           </div>
//         </div>
//       </div>

//       <div className="table-responsive" style={{ fontSize: '0.8rem' }}>
//         <table className="table table-striped table-bordered align-middle text-center">
//           <thead className="table-dark">
//             <tr>
//               <th>Product</th>
//               <th>Title</th>
//               <th>Qty</th>
//               <th>Price (₹)</th>
//               <th>Tax (₹)</th>
//               <th>Total (₹)</th>
//             </tr>
//           </thead>
//           <tbody>
//             <tr>
//               <td>Content Writing & CopyWriting</td>
//               <td>Engaging Content Writing & Persuasive Copywriting Services</td>
//               <td>1</td>
//               <td>539.4</td>
//               <td>-</td>
//               <td>-</td>
//             </tr>
//             <tr className="table-warning">
//               <td colSpan="4" className="text-end fw-semibold">Discount</td>
//               <td colSpan="2" className="text-danger fw-bold">₹213.8</td>
//             </tr>
//             <tr>
//               <td colSpan="3" className="text-end fw-semibold">Taxable Value</td>
//               <td>325.6</td>
//               <td>58.61</td>
//               <td>384.21</td>
//             </tr>
//             <tr>
//               <td colSpan="3" className="text-end fw-semibold">Shipping Charge</td>
//               <td>97</td>
//               <td>17.46</td>
//               <td>114.46</td>
//             </tr>
//             <tr className="table-success fw-bold">
//               <td colSpan="3" className="text-end">Total</td>
//               <td></td>
//               <td>76.07</td>
//               <td>498.67</td>
//             </tr>
//           </tbody>
//         </table>
//       </div>
//       <div className="text-end mb-3">
//         <div className="d-inline-block px-4 py-2 bg-light border rounded shadow-sm">
//           <span className="fw-bold me-3 text-dark ">Grand Total</span>
//           <span className="badge bg-success">₹498.67</span>
//         </div>
//       </div>
//       <div className="bg-white border rounded p-4 shadow-sm mb-4">
//         <h6 className="fw-bold text-success">💳 Direct Deposit / Bank Wire Transfer</h6>
//         <p className="mb-1">Deposit the amount at your nearest <strong>IDFC FIRST BANK</strong> in our accounts in favour of:</p>
//         <p className="mb-3"><strong>ADIBLISS INFOTECH PRIVATE LIMITED</strong></p>

//         <div className="row">
//           <div className="col-md-6">
//             <h6 className="fw-bold text-success mb-1">Transfer Using Account</h6>
//             <ul className="mb-1">
//               <li><strong>Bank:</strong> IDFC FIRST BANK</li>
//               <li><strong>A/C No:</strong> 10226466663</li>
//               <li><strong>IFSC Code:</strong> IDFB0020101</li>
//             </ul>
//           </div>
//           <div className="col-md-6">
//             <p><strong>Confirmation:</strong><br />Send payment confirmation to: <a href="mailto:adiblissinfotech@gmail.com">adiblissinfotech@gmail.com</a></p>
//             <p><strong>More Info:</strong><br />Visit: <a href="https://elvyn.co.in" target="_blank" rel="noreferrer">https://elvyn.co.in</a></p>
//           </div>
//         </div>
//         <div className="text-center">
//           <small className="text-muted">1st Floor, Office No.F-01A-72 Upper Level, Haware Centurion, Plot No 88 to 91 Navi Mumbai, Nerul East, Mumbai, Maharashtra - 400706</small><br />
//           <small className="text-muted fst-italic">This is a computer-generated invoice. No signature required.</small>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default App



import React from "react";
import { jsPDF } from "jspdf";
import "../InvoiceFormat/InvoiceFormat.css";
import html2canvas from "html2canvas";
 import velixa from "./velixa.png"
import { Link, useLocation } from "react-router-dom";
import {
  FaMapMarkerAlt,
  FaTruck,
  FaCalendarAlt,
} from "react-icons/fa";
import axios from "axios";
import baseUrl from "../config/baseUrl";
const InvoiceDetails = ({ invoiceData }) => {
  return (
    <div
      style={{
        width: "800px",
        marginLeft: "10px",
        marginTop: "30px",
        marginBottom: "30px",
      }}
    >
      <div id="invoice" style={{ background: "#fff", padding: "10px", marginLeft: "5px" }}>
       
         <div className="container-fluid my-2 ">
      <div className="d-flex justify-content-between align-items-start mb-1 rounded " style={{ backgroundColor: '#adb5bbff' }}>
        <div className="d-flex align-items-center">
          <img src={velixa} alt="Zenvy Logo" style={{ height: '50px', marginRight: '10px' }} />
          <div>
            <h6 className="fw-bold mb-1 text-success">OPEN BRACKET CLOUD SOLUTIONS PRIVATE LIMITED</h6>
            <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>GST NO: 27AACCO3584C1ZJ
</p>
          </div>
        </div>
        <small className="text-muted fst-italic me-3 mt-3" >
          * Keep this invoice for warranty purposes
        </small>
      </div>
      <div className="row g-3 mb-2" >
        <div className="col-12 col-sm-4">
          <div className="bg-light rounded p-3 shadow-sm h-100">
            <h6 className="text-primary fw-bold mb-1">🧾 Order Info</h6>
            <p className="mb-1">Order ID: <strong>{invoiceData.orderNo}</strong></p>
            <p className="mb-1">Order Date:{invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}</p>
            <p className="mb-0">Invoice Date:{invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}</p>
          </div>
        </div>
        <div className="col-12 col-sm-4">
          <div className="bg-light rounded p-3 shadow-sm h-100">
            <h6 className="text-success fw-bold mb-1">📍 Billing Address</h6>
             <p className="mb-1"> {invoiceData.fullName
                .split(" ")
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ")}
              <br /></p>
            <p className="mb-1">{invoiceData.billingAddress}</p>
            <p className="mb-0">📞{invoiceData.mobileNo}</p>
          </div>
        </div>
        <div className="col-12 col-sm-4">
          <div className="bg-light rounded p-3 shadow-sm h-100">
            <h6 className="text-warning fw-bold mb-1">🚚 Shipping Address</h6>
             <p className="mb-1"> {invoiceData.fullName
                .split(" ")
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ")}
              <br /></p>
            <p className="mb-1">{invoiceData.billingAddress}</p>
            <p className="mb-0">📞{invoiceData.mobileNo}</p>
          </div>
        </div>
      </div>

      <div className="table-responsive" style={{ fontSize: '0.8rem' }}>
        <table className="table table-striped table-bordered align-middle text-center">
          <thead className="table-dark">
            <tr>
              <th>Product</th>
              <th>Title</th>
              <th>Qty</th>
              <th>Price (₹)</th>
              <th>Tax (₹)</th>
              <th>Total (₹)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{invoiceData.productName}</td>
              <td> {invoiceData.productTitle}</td>
              <td>1</td>
              <td>{invoiceData.productPrice}</td>
              <td>-</td>
              <td>-</td>
            </tr>
            <tr className="table-warning">
              <td colSpan="4" className="text-end fw-semibold">Discount</td>
              <td colSpan="2" className="text-danger fw-bold">₹{invoiceData.discount}</td>
            </tr>
            <tr>
              <td colSpan="3" className="text-end fw-semibold">Taxable Value</td>
              <td>{invoiceData.baseAmount}</td>
              <td>{invoiceData.gst}</td>
              <td>{(invoiceData.baseAmount + invoiceData.gst).toFixed(2)}</td>
            </tr>
            <tr>
              <td colSpan="3" className="text-end fw-semibold">Shipping Charge</td>
              <td>{invoiceData.shippingCharge1}</td>
              <td>{invoiceData.shippingCharge2}</td>
              <td>{invoiceData.shippingCharges}</td>
            </tr>
            <tr className="table-success fw-bold">
              <td colSpan="3" className="text-end">Total</td>
              <td></td>
              <td>{(invoiceData.gst + invoiceData.shippingCharge2).toFixed(2)}</td>
              <td>{invoiceData.paidAmount.toFixed(2)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="text-end mb-3">
        <div className="d-inline-block px-4 py-2 bg-light border rounded shadow-sm">
          <span className="fw-bold me-3 text-dark ">Grand Total</span>
          <span className="badge bg-success">₹{invoiceData.paidAmount.toFixed(2)}</span>
        </div>
      </div>
      <div className="bg-white border rounded p-4 shadow-sm mb-4">
        <h6 className="fw-bold text-success">💳 Direct Deposit / Bank Wire Transfer</h6>
        <p className="mb-1">Deposit the amount at your nearest <strong>UNION BANK OF INDIA</strong> in our accounts in favour of:</p>
        <p className="mb-3"><strong>OPEN BRACKET CLOUD SOLUTIONS PRIVATE LIMITED</strong></p>

        <div className="row">
          <div className="col-md-6">
            <h6 className="fw-bold text-success mb-1">Transfer Using Account</h6>
            <ul className="mb-1">
              <li><strong>Bank:</strong> UNION BANK OF INDIA</li>
              <li><strong>A/C No:</strong> 012021010000124</li>
              <li><strong>IFSC Code:</strong> UBIN0901202</li>
            </ul>
          </div>
          <div className="col-md-6">
            <p><strong>Confirmation:</strong><br />Send payment confirmation to: <a href="mailto:support@velixa.in">support@velixa.in</a></p>

            <p><strong>More Info:</strong><br />Visit: <a href="https://velixa.co.in/" target="_blank" rel="noreferrer">https://velixa.co.in/</a></p>
          </div>
        </div>
        <div className="text-center">
          <small className="text-muted">OFFICE NO 1, NAJAF APARTMENT, Chapel Road, Bandra
West, Mumbai, Mumbai Suburban, Maharashtra, 400050</small><br />
          <small className="text-muted fst-italic">This is a computer-generated invoice. No signature required.</small>
        </div>
      </div>
    </div>

      </div>

    </div>
  );
};
function InvoiceElyvnFormat() {
  const auth = localStorage.getItem("user");
  const location = useLocation();
  const { item, module } = location.state || {};
  const downloadPDF = async () => {
    const input = document.getElementById("invoice");
    const formData = new FormData();
    formData.append("orderNo", item.orderNo);
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG");
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${item.orderNo}` + ".pdf");
    });
    const config = {
      headers: {
        "Content-type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${auth}`,
      },
    };
    if (module !== "/Invoice/Downloaded") {
      await axios.post(
        `${baseUrl}/changeStatusDownloadedInvoice`,
        formData,
        config
      );
    }
  };
  return (
    <div>
      <div className="row m-0 p-0">
        <div className="col-6">
          <Link to={`${module}`}>
            <button
              style={{
                backgroundColor: "#ff9707",
                color: "#fff",
                width: "80px",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "16px",
                marginTop: "20px",
                padding: "4px 5px",
              }}
            // onClick={downloadPDF}
            >
              Back
            </button>
          </Link>
        </div>
        <div className="col-5 offset-1">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width: "80px",
              padding: "4px 5px",
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
      <InvoiceDetails invoiceData={item} />
    </div>
  );
}
export default InvoiceElyvnFormat;





