import React from "react";
import { jsPDF } from "jspdf";
import "../InvoiceFormat/InvoiceFormat.css"; // Optional: Your custom styles (if needed)
import html2canvas from "html2canvas";
import invoiceLogo from "./image.png";
import { Link, useLocation } from "react-router-dom";
import axios from "axios";
import baseUrl from "../config/baseUrl";
const InvoiceDetails = ({ invoiceData }) => {
  return (
    <div
      style={{
        width: "800px",
        marginLeft: "10px",
        marginTop: "30px",
        marginBottom: "30px",
      }}
    >
      <div id="invoice" style={{ background: "#fff", padding: "10px",marginLeft:"5px" }}>
      {/* <h3>Duplicate Invoice</h3> */}
        <div className="invoice-company-logo-container mt-4" style={{ textAlign: "left" }}>
          <img
            src={invoiceLogo}
            alt="invoice"
            style={{ maxWidth: "150px", display: "inline-block", marginRight: "95px" }}
          />
        </div>
        {/* <div className="line mt-4 mb-2"></div> */}
        <div className="row order-details flex mb-4 ">
          
          <div className="col-6 customer-billing-address head-text mt-1">
            <span className="d-block" style={{ fontSize: "15px" }}>
           {/* <i>Billing Details</i>  */}
           KASHIRALABS INDIA PVT LTD <br></br>
           GST NO. : 27AALCK5123G1ZJ
            </span>
            {/* <span className="text-font customer-name">
            {invoiceData.fullName
                .split(" ")
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ")}
              <br />
            </span>
            <span className="bill-address text-font">
              {invoiceData.billingAddress}
            </span>
            <span className="text-font">
              <br />
              Phone : {invoiceData.mobileNo}
            </span> */}
             {/* <img
            src={invoiceLogo}
            alt="invoice"
            style={{ maxWidth: "150px", display: "inline-block", marginRight: "95px" }}
          /> */}
          </div>
          
          <div className="col-4 customer-details mt-1">
           <span className="head-text d-block"style={{ textAlign: "right" }}>
            Customer Name : {invoiceData.fullName
                .split(" ")
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ")}
            </span>

            <span className="head-text d-block"style={{ textAlign: "right" }}>Purchase Date :  {invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}</span>

            <span className="head-text d-block"style={{ textAlign: "right" }}>
             Issue Date :  {invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}
            </span>
            <div style={{ height: '10px' }}></div> 
            <span className="head-text d-block"style={{ textAlign: "right" }}>
            Order Reference : {invoiceData.orderNo}
            </span>
          </div>
        </div>
        
        {/* <div className="col-12 customer-shipping-address head-text mb-2" style={{ textAlign: "right" }}>
            <span className="d-block" style={{ fontSize: "15px" }}>
           <i>Delivery Address</i> 
            </span>
            <span className="text-font customer-name">
            {invoiceData.fullName
                .split(" ")
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(" ")}
              <br />
            </span>
            <span className="shipped-address text-font">
              {invoiceData.billingAddress}
            </span>
            <span className="text-font">
              <br />
              Phone : {invoiceData.mobileNo}
            </span>
            
            
          </div> */}
          
        <table>
          <thead style={{ backgroundColor:"#f0dcc1" }}>
            <tr
              style={{
                borderBottom: "2px solid #908e8e",
                boxShadow: "0.1px 0.2px 0.2px 0.2px rgba(0, 0, 0, 0.5)",
              }}
            >
              <th style={{ width: "16%" }}>Qty</th>
              <th style={{ width: "18%" }}>Course Title</th>
              <th></th>
              <th>Course Type</th>
              <th>Cost</th>
              <th>Tax </th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {/* <tr className="line" style={{width:"40%"}}></tr> */}
            <tr>
                <td
                style={{
                  fontSize: "12px",
                  verticalAlign: "top",
                  paddingTop: "10px",
                  paddingBottom: "20px",
                }}
              >
                1
              </td>
              <td
                style={{
                  fontWeight: "700",
                  fontSize: "12px",
                  verticalAlign: "top",
                  paddingTop: "10px",
                  paddingBottom: "20px",
                }}
              >
                {invoiceData.productName}
              </td>
              <td
                style={{
                  paddingTop: "10px",
                  paddingTop: "10px",
                  paddingBottom: "20px",
                }}
              ></td>
            
              <td
                style={{
                  fontSize: "12px",
                  verticalAlign: "top",
                  paddingTop: "10px",
                  paddingBottom: "20px",
                }}
              >
                {invoiceData.productTitle}
              </td>
              <td
                style={{
                  fontSize: "12px",
                  verticalAlign: "top",
                  paddingTop: "10px",
                  paddingBottom: "20px",
                }}
              >
                {invoiceData.productPrice}
              </td>
              <td></td>
            </tr>
            <tr>
              <td></td>
              <td
                style={{
                  fontSize: "14px",
                  fontStyle: "initial",
                  paddingTop: "0px",
                  paddingBottom: "20px",
                }}
              >
                18.00% GST
              </td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
            <tr>
              <td></td>
              <td></td>
              <td style={{ fontSize: "12px" }}>Price Off</td>
              <td></td>
              <td style={{ fontSize: "12px" }}>{invoiceData.discount}</td>
              <td></td>
              <td></td>
            </tr>
            <tr>
              <td></td>
              <td></td>
              <td
                style={{
                  fontSize: "12px",
                  paddingTop: "8px",
                  paddingBottom: "8px",
                }}
              >
                Tax Fee
              </td>
              <td></td>
              <td
                style={{
                  fontSize: "12px",
                  paddingTop: "8px",
                  paddingBottom: "8px",
                }}
              >
                {invoiceData.baseAmount}
              </td>
              <td
                style={{
                  fontSize: "12px",
                  paddingTop: "8px",
                  paddingBottom: "8px",
                }}
              >
                {invoiceData.gst}
              </td>
              <td
                style={{
                  fontSize: "12px",
                  paddingTop: "8px",
                  paddingBottom: "8px",
                }}
              >
                {(invoiceData.baseAmount + invoiceData.gst).toFixed(2)}
              </td>
            </tr>
            <tr>
              <td></td>
              <td></td>
              <td style={{ fontSize: "12px" }}>Plateform Fee</td>
              <td></td>
              <td style={{ fontSize: "12px" }}>
                {invoiceData.shippingCharge1}
              </td>
              <td style={{ fontSize: "12px" }}>
                {invoiceData.shippingCharge2}
              </td>
              <td style={{ fontSize: "12px" }}>
                {invoiceData.shippingCharges}
              </td>
            </tr>
          </tbody>
        </table>
        {/* <div className="line mt-2 mb-2 ms-auto" style={{ width: "85%" }}></div> */}
        <table>
          <thead>
            <tr>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={{ width: "16%" }}></td>
              <td style={{ width: "18%" }}></td>
              {/* <td
                style={{
                  fontWeight: "600",
                  paddingTop: "7px",
                  paddingBottom: "6px",
                }}
              >
                Total
              </td>
              <td
                style={{
                  fontWeight: "600",
                  paddingTop: "7px",
                  paddingBottom: "6px",
                }}
              >
                1
              </td> */}
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td
                style={{
                  fontWeight: "400",
                  paddingTop: "7px",
                  paddingBottom: "6px",
                }}
              >
                {(invoiceData.gst + invoiceData.shippingCharge2).toFixed(2)}
              </td>
              <td>{invoiceData.paidAmount.toFixed(2)}</td>
            </tr>
          </tbody>
        </table>
        <div className="line"></div>
        <table>
          <thead>
            <tr>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody style={{ backgroundColor:"#f0dcc1" }}>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td
                style={{
                  fontWeight: "600",
                  fontSize: "19px",
                  paddingTop: "13px",
                  paddingBottom: "10px",
                }}
              >
                Total Amount
              </td>
              <td
                style={{
                  fontWeight: "600",
                  fontSize: "19px",
                  paddingTop: "13px",
                  paddingBottom: "10px",
                }}
              >
                (₹)
              </td>
              <td
                style={{
                  fontWeight: "600",
                  fontSize: "19px",
                  paddingTop: "13px",
                  paddingBottom: "10px",
                }}
              >
                {invoiceData.paidAmount.toFixed(2)}
              </td>
            </tr>
          </tbody>
        </table>
        <div className="line"></div>
        <div
          className="text-center mt-1"
          style={{ fontSize: "10px", fontStyle: "italic" }}
        >
          This is a computer generated invoice. No signature required.
        </div>

 <div className="row order-details flex mb-4 mt-4">
  <div className="col-12 customer-details mt-1">
    <span >
      Direct Deposit / Bank Wire Transfer:<br />
      <span style={{ marginLeft: '', display: 'inline-block' }}>
        Deposit the amount at your nearest JANA SMALL FINANCE BANK in our accounts in favour of KASHIRALABS INDIA PVT LTD.
      </span>
    </span>
  </div>

  <div className="col-12 customer-details mt-1">
    <span >
      Transfer using account:<br />
      <span style={{ marginLeft: '', display: 'inline-block' }}>
        Jana Small Finance Bank A/C No:  4759020001219416 <br></br> IFSC-JSFB0004759
      </span>
    </span>
  </div>
  <div className="col-12 customer-details mt-1">
    <span >
        <br />
     <span style={{ marginLeft: '', display: 'inline-block' }}>
  Send confirmation email to <a href="mailto:support@xuwi.in">support@xuwi.in</a>
</span>

    </span>
  </div>

  <div className="col-12 customer-details mt-3">
   <span>
  For Full Details Visit Our Website: <a href="https://xuwi.co.in" target="_blank" rel="noopener noreferrer">xuwi.co.in</a><br />
</span>

  </div>
</div>



        <div
          style={{
            marginTop: "25%",
            textAlign: "center",
            fontSize: "16px",
            fontWeight: "600",
          }}
        >
      2ND FLOOR
SHOP-79 B WING,
EXPRESS ZONE MALL
W EXPRESS HIGHWAY
W EXPRESS HIGHWAY
PATEL VANILLA GOREGAON (E)
Mumbai,Mumbai Suburban,
Maharashtra,
400063
        </div>
      </div>
    </div>
  );
};
function InvoiceRishiFormat() {
  const auth = localStorage.getItem("user");
  const location = useLocation(); // Get the location object
  const { item, module } = location.state || {}; // Access the object passed via state
  const downloadPDF = async () => {
    const input = document.getElementById("invoice"); // Select the invoice container
    const formData = new FormData();
    formData.append("orderNo", item.orderNo);
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG"); // Convert canvas to image
      const pdf = new jsPDF("p", "mm", "a4"); // Create a jsPDF document
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight); // Add image to PDF
      pdf.save(`${item.orderNo}` + ".pdf"); // Save PDF
    });
    const config = {
      headers: {
        "Content-type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${auth}`,
      },
    };
    if (module !== "/Invoice/Downloaded") {
      await axios.post(
        `${baseUrl}/changeStatusDownloadedInvoice`,
        formData,
        config
      );
    }
  };
  return (
    <div>
      <div className="row m-0 p-0">
        <div className="col-6">
          <Link to={`${module}`}>
            <button
              style={{
                backgroundColor: "#ff9707",
                color: "#fff",
                width: "80px",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "16px",
                marginTop: "20px",
                padding: "4px 5px",
              }}
              // onClick={downloadPDF}
            >
              Back
            </button>
          </Link>
        </div>
        <div className="col-5 offset-1">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width: "80px",
              padding: "4px 5px",
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
      <InvoiceDetails invoiceData={item} />
    </div>
  );
}
export default InvoiceRishiFormat;


