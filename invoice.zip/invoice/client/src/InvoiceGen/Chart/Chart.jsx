// npm install react-apexcharts apexcharts
import React, { useEffect, useState } from "react";
import ReactApexChart from "react-apexcharts";
import axios from "axios";
import baseUrl from "../config/baseUrl";
export const ApexChart = () => {
  const auth = localStorage.getItem("user");
  const [data, setData] = useState({});
  const [state, setState] = useState({
    series: [],
    options: {
      chart: {
        type: "bar",
        height: 350,
        toolbar: {
          show: false, // Disable the toolbar completely
        },
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "55%",
          borderRadius: 5,
          borderRadiusApplication: "end",
        },
      },
      dataLabels: {
        enabled: false,
      },
      stroke: {
        show: true,
        width: 2,
        colors: ["transparent"],
      },
      xaxis: {
        categories: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], // 7 categories
      },
      yaxis: {
        title: {
          text: "Invoices",
        },
      },
      fill: {
        opacity: 1,
      },
      tooltip: {
        y: {
          formatter: function (val) {
            return val + " invoices";
          },
        },
      },
    },
  });
  const fetchData = async () => {
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      const result = await axios.post(`${baseUrl}/DashboardByDay`, {}, config);
      const apiData = result.data;
      // Prepare series data
      const dotoneData = [];
      const yeppeData = [];
      const days = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
      ];

      days.forEach((day) => {
        dotoneData.push(apiData[day]?.dotone || 0);
        yeppeData.push(apiData[day]?.yeppe || 0);
      });

      setState((prevState) => ({
        ...prevState,
        series: [
          { name: "dotone", data: dotoneData },
          { name: "yeppe", data: yeppeData },
        ],
      }));
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div>
      <div id="chart">
        <ReactApexChart
          options={state.options}
          series={state.series}
          type="bar"
          height={350}
        />
      </div>
    </div>
  );
};
