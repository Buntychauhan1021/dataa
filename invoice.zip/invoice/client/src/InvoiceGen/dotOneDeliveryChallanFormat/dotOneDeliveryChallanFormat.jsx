import React from "react";
import "./dotOneDeliveryChallanFormat.css";
import dotOneLogo from "../InvoiceDotOneForamat/image.png";
import CompanySignature from "./dotOneCompanySignature.jpeg"
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import axios from "axios";
import baseUrl from "../config/baseUrl";
import { Link,useLocation } from 'react-router-dom';
const InvoiceDotOneFormat = () => {
    const auth = localStorage.getItem("user")
    const location = useLocation(); // Get the location object
    const { item,module } = location.state || {}; // Access the object passed via state
    let fullNameStartLetter = item.fullName ? item.fullName.split("")[0] : ""
  const downloadPDF = async() => {
    const input = document.getElementById("deliveryChallan"); // Select the invoice container
    const formData = new FormData();
    formData.append("orderNo",item.orderNo)
    const options = {
      useCORS: true,  // Enable CORS to load external images
      logging: true,  // Enable logging for debugging
      allowTaint: false,  // Prevent canvas tainting
      scrollX: 0,
      scrollY: -window.scrollY,  // Handle scrolling if needed
    };
    html2canvas(input,options).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG"); // Convert canvas to image
      const pdf = new jsPDF("p", "mm", "a4"); // Create a jsPDF document
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight); // Add image to PDF
      pdf.save("dc_"+`${item.orderNo}`+".pdf"); // Save PDF
    });
    const config = {
      headers: {
          "Content-type": "application/json",
          Accept: "application/json",
           Authorization: `Bearer ${auth}`,
      },
  };
  if (module !== "/invoice/DownloadedChalaan") {
    const response = await axios.post(`${baseUrl}/changeStatusDeliveryChallan`,formData,config)
  }
  };
  return (
    <div>
      <div className="row ms-4 me-4">
      <div className="col-6">
          <Link to={`${module}`}>
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              width:"80px",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              padding:"4px 5px"
            }}
            // onClick={downloadPDF}
          >
            Back
          </button>                                     
          </Link>
        </div>
        <div className="col-6 text-end">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width:"80px",
              padding:"4px 5px"
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
<div className='delivery-chalaan-container mt-4 mb-4 me-3 p-4' id="deliveryChallan">
<div className="row" id="dot-one-format-container">
      <div className="row m-0 p-0 col-border row-color text-white text-center">
        <h3>Delivery Challan</h3>
      </div>
      <div className="row m-0 p-0 line-gap">
        <div className="col-6 col-border p-3">
          <div className="row">
            <div className="col-12 company-name">DOTONE INFOTECH PRIVATE LIMITED</div>
          </div>
          <div className="row mt-3">
          <div className="col-2 left-head">
             Address:
            </div>
            <div className="col-6 right-text">
            G-2008, Raj Nagar Extension, Ghaziabad,
            Ghaziabad, Ghaziabad, Uttar Pradesh-201017
            </div>
          </div>
          <div className="row">
            <div className="col-2 left-head">Phone No:</div>
            <div className="col-6 text-start right-text">+91 7065424993</div>
          </div>
          <div className="row">
            <div className="col-2 left-head">Email :</div>
            <div className="col-6 right-text">support@limezo.in</div>
          </div>
          <div className="row">
            <div className="col-2 left-head">GSTIN :</div>
            <div className="col-6 right-text">09AAJCD9084F128</div>
          </div>
        </div>
        <div className="col-6 text-center col-border p-3">
          <img src={dotOneLogo} alt="image" />
        </div>
      </div>
      <div className="row m-0 p-0 col-border row-color text-white text-center">
        <div className="col-6 table-column">DELIVERY CHALLAN FOR</div>
        <div className="col-6 table-column">SHIP TO</div>
      </div>
      <div className="row m-0 p-0">
        <div className="col-6 col-border line-gap p-3">
          <div className="row">
          <div className="col-3 left-head">Party Name:</div>
            <div className="col-9 right-text">{item.fullName}</div>
          </div>
          <div className="row">
          <div className="col-3 left-head">
              Billing Address:
            </div>
            <div className="col-9 right-text">
             {item.billingAddress}
            </div>
          </div>
          {/* <div className="row">
            <div className="col-3 left-head">Pin :</div>
            <div className="col-9 right-text">908765</div>
          </div> */}
          <div className="row">
            <div className="col-3 left-head">Phone :</div>
            <div className="col-9 right-text">{item.mobileNo}</div>
          </div>
          <div className="row">
            <div className="col-3 left-head">Email:</div>
            <div className="col-9 right-text">{item.Email}</div>
          </div>
          <div className="row">
            <div className="col-3 left-head">GSTIN:</div>
            <div className="col-9 right-text">--</div>
          </div>
          <div className="row">
            <div className="col-3 left-head">Challan No:</div>
            <div className="col-9 right-text">{item.orderNo}</div>
          </div>
          <div className="row">
            <div className="col-3 left-head">Challan Date:</div>
            <div className="col-9 right-text">{item.transactionInvoiceCreatedOn ? (item.transactionInvoiceCreatedOn).split(" ")[0] : "" }</div>
          </div>
          {/* <div className="row">
            <div className="col-3 left-head">Place of Supply :</div>
            <div className="col-9"></div>
          </div> */}
        </div>
        <div className="col-6 col-border line-gap p-3">
          <div className="row">
          <div className="col-3 left-head">Shipping Name:</div>
            <div className="col-9 right-text">{item.fullName}</div>
          </div>
          <div className="row">
          <div className="col-3 left-head">
             Shipping Address:
            </div>
            <div className="col-9 right-text">
            {item.billingAddress}
            </div>
          </div>
          <div className="row">
            <div className="col-3 left-head">Phone No:</div>
            <div className="col-9 right-text">{item.mobileNo}</div>
          </div>
          <div className="row">
            <div className="col-3 left-head">Email:</div>
            <div className="col-9 right-text">{item.Email}</div>
          </div>
          <div className="row">
            <div className="col-3 left-head">GSTIN:</div>
            <div className="col-9 right-text">--</div>
          </div>
          <div className="row">
            <div className="col-3 left-head">Delivery Time:</div>
            <div className="col-9 right-text">{item.deliveryTime}</div>
          </div>
        </div>
      </div>
      <div className="row m-0 p-0 col-border row-color text-white text-center">
        <div className="col-2 table-column">SL NO.</div>
        <div className="col-3 table-column">Product</div>
        <div className="col-2 table-column">Category</div>
        <div className="col-3 table-column">Quantity</div>
        {/* <div className="col-2">Tax Per Unit</div> */}
        <div className="col-2 table-column">Amount</div>
      </div>
      <div className="row m-0 p-0">
        <div className="col-2 text-center col-border right-text p-4">1</div>
        <div className="col-3 text-center col-border right-text p-4 fw-bold">
        {item.productName}
        </div>
        {/* <div className="col-3 text-center col-border right-text p-4 fw-bold">
    {item.productName}
</div> */}
        <div className="col-2 text-center col-border right-text p-4">{item.productTitle}</div>
        <div className="col-3 text-center col-border right-text p-4">1</div>
        {/* <div className="col-2">Tax Per Unit</div> */}
        <div className="col-2 text-center col-border right-text p-4">{item.paidAmount} /-</div>
      </div>
      <div className="row m-0 p-0 col-border row-color text-white text-center">
        <div className="col-8 table-column text-end">Total</div>
        <div className="col-2 table-column">=</div>
        <div className="col-2 table-column">{item.paidAmount} /-</div>
      </div>
      <div className="row m-0 p-0">
       <div className="col-6 col-border p-3">
       <div className="row">
        <div className="col-12 right-text">Terms And Conditions</div>
       </div>
       <div className="row">
        <div className="col-12 right-text">1. Amount can not be Refunded</div>
       </div>
       <div className="row">
        <div className="col-12 right-text">2. if any damage or package broken,exchange is available. </div>
       </div>
       </div>
       <div className="col-6 col-border p-3">
       <div className="row m-0 p-0 text-center">
        <div className="col-12">
          For Company Signature
        </div>
       </div>
       <div className="row m-0 p-3 text-center">
        <div className="col-12">
        <img src={CompanySignature} alt="image" style={{height:"87px",width:"192px",transform:"scale(1.2)",transformOrigin:"center"}}/>
        </div>
       </div>
       <div className="row m-0 p-0 text-center">
        <div className="col-12">
          Authorize Signature
        </div>
       </div>
        </div>
      </div>
      <div className="row m-0 p-0 col-border row-color text-center" style={{opacity:"1",color:"rgb(167 56 56)"}}>
        .
      </div>
      <div className="row m-0 p-0 col-border line-gap">
       <div className="col-6 col-border p-3">
       <div className="row">
        <div className="col-12 left-head">Received By:</div>
       </div>
       <div className="row">
        <div className="col-2 left-head">Name:</div>
        <div className="col-6 right-text">{item.fullName}</div>
       </div>
       <div className="row">
        <div className="col-2 left-head">Comment:</div>
        {/* <div className="col-6">Dushyant</div> */}
       </div>
       <div className="row">
        <div className="col-2 left-head">Date:</div>
        <div className="col-6 right-text">{item.deliveryDate}</div>
       </div>
       <div className="row">
        <div className="col-2 left-head">Signature:</div>
        {/* <div className="col-6">07-02-2025</div> */}
       </div>
       </div>
       <div className="col-6">
       <div className="row">
        <div className="col-12 p-3">
        <img
          src={`${baseUrl}/${fullNameStartLetter}/${item.signatureImageName}`}
          alt="buyer Sign"
          style={{minWidth:"400px",height:"130px"}}
        />
        </div>
       </div>
        </div>
      </div>
    </div>
</div>
    </div>

  );
};

export default InvoiceDotOneFormat;