

import React, { useEffect, useState } from "react";
import axios from "axios";
import baseUrl from "../config/baseUrl";
import "../../App.css";
import "../ForDownload/forDownload.css"
import Paginations from "..//CommonComponentInvoice/Pagination/Pagination";
import { Table, TableCell, TableBody, TableContainer, TableHead, TableRow } from "@mui/material";
import ViewIcon from '@mui/icons-material/Visibility';
import { Link, useNavigate } from "react-router-dom";
import * as XLSX from "xlsx";
import Search from "../CommonComponentInvoice/Search/Search";


function DownloadedChallan() {
    const auth = localStorage.getItem('user')
    const [data, setData] = useState([]);
    const [searchItem, setSearchItem] = useState("");
    const [page, setPage] = useState(1);
    const [totalPage, setTotalPage] = useState(0);
    const [message, setMessage] = useState("");
    const navigate = useNavigate();
    const fetchInvoices = async () => {
        try {
            let formData = new FormData();
            formData.append("searchItem", searchItem);
            formData.append("page", page);
            const config = {
                headers: {
                    "Content-type": "application/json",
                    Accept: "application/json",
                    Authorization: `Bearer ${auth}`,
                },
            };
            let result = await axios.post(`${baseUrl}/fetchDownloadedChallan`, formData, config);
            setData(result.data.result);
            setTotalPage(result.data.totalPage)
            setMessage(result.data.message)
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    const handleNavigate = (e, item) => {
        e.preventDefault();
        if (item.InvoiceType == 'yeppe') {
            navigate(`/invoice/DeliveryChalaanFormat/${item.orderNo}`, {
                state: { item: item, module: "/invoice/DownloadedChalaan" } // Passing the item object as state
            });
        } else if (item.InvoiceType == 'elvyn') {
            navigate(`/invoice/ElvynDeliveryChalaanFormat`, {
                state: { item: item, module: "/invoice/DownloadedChalaan" } // Passing the item object as state
            });
        }else if (item.InvoiceType == 'zenvy') {
            navigate(`/invoice/VelixaDeliveryChalaan`, {
                state: { item: item, module: "/invoice/DownloadedChalaan" } // Passing the item object as state
            });
        }else if (item.InvoiceType == 'streakzen') {
            navigate(`/invoice/StreakZenDeliveryChalaan`, {
                state: { item: item, module: "/invoice/DownloadedChalaan" } // Passing the item object as state
            });
        } else {
            navigate(`/invoice/DotOneDeliveryChallanFormat`, {
                state: { item: item, module: "/invoice/DownloadedChalaan" } // Passing the item object as state
            });
        }
    };
    useEffect(() => {
        fetchInvoices();
    }, [page, searchItem]);
    return (
        <div className="for-download-container mt-4 me-4">
            <div className="row">
                <div className="col-12 ms-2 ms-md-0"><h5 style={{ fontWeight: '700' }}>Downloaded Challan</h5></div>
            </div>
            <div className="row mt-2">
                <div className="row search-container ms-1">
                    <div className="col-6 col-md-3">
                        <Search serchItem={searchItem} setSearchItem={setSearchItem} />
                    </div>
                    {/* <div className="col-6 col-md-9 text-end">
                        <button className="btn btn-primary ms-2" onClick={downloadExl}>Download</button>
                    </div> */}
                </div>
            </div>
            <div className="row">
                <TableContainer className="tablecontainer2 mt-2">
                    <Table sx={{ minWidth: 650 }} className="table-striped table-hover" aria-label="simple table">
                        <TableHead>
                            <TableRow >
                                <TableCell className="tablefont-align" align="center">Order No.</TableCell>
                                <TableCell className="tablefont-align" align="center">Full Name</TableCell>
                                <TableCell className="tablefont-align" align="center">Invoice Type</TableCell>
                                <TableCell className="tablefont-align" align="center">View</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data.map((item, index) => (
                                <TableRow
                                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                                    key={index}
                                >
                                    <TableCell align="center">{item.orderNo}</TableCell>
                                    <TableCell align="center">{item.fullName}</TableCell>
                                    <TableCell align="center">{item.InvoiceType}</TableCell>
                                    {/* <TableCell align="center"><button type="button" style={{backgroundColor: "#e5790a",color:"white",border:"none",padding:"5px 10px",borderRadius:"10px"}}><ViewIcon /></button></TableCell> */}
                                    <TableCell align="center">
                                        {/* <Link  to={{
        pathname: `/Invoice/Download/${item.orderNo}`,
        state:  item , 
      }}> */}
                                        <button type="button" style={{ backgroundColor: "#9c27b0", color: "white", border: "none", padding: "5px 10px", borderRadius: "10px" }} onClick={(e) => { handleNavigate(e, item) }}><ViewIcon /></button>
                                        {/* </Link> */}
                                    </TableCell>
                                </TableRow>
                            ))}

                        </TableBody>
                    </Table>
                </TableContainer>
            </div>
            <div className="row">
                <Paginations page={page} setPage={setPage} totalPage={totalPage} message={message} />
            </div>
        </div>
    );
}
export default DownloadedChallan;