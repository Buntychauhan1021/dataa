import React from 'react';
import "../../App.css"
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import axios from "axios";
import baseUrl from "../config/baseUrl";
import { Link,useLocation } from 'react-router-dom';
import companySignature from "./company-signature.png"
import yeppeLogo from "./yeppe.png"
const DeliveryChalaanFormat = () => {
    const auth = localStorage.getItem("user")
    const location = useLocation(); // Get the location object
    const { item,module } = location.state || {}; // Access the object passed via state
    let fullNameStartLetter = item.fullName ? item.fullName.split("")[0] : ""
  const downloadPDF = async() => {
    const input = document.getElementById("deliveryChallan"); // Select the invoice container
    const formData = new FormData();
    formData.append("orderNo",item.orderNo)
    const options = {
      useCORS: true,  // Enable CORS to load external images
      logging: true,  // Enable logging for debugging
      allowTaint: false,  // Prevent canvas tainting
      scrollX: 0,
      scrollY: -window.scrollY,  // Handle scrolling if needed
    };
    html2canvas(input,options).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG"); // Convert canvas to image
      const pdf = new jsPDF("p", "mm", "a4"); // Create a jsPDF document
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight); // Add image to PDF
      pdf.save("dc_"+`${item.orderNo}`+".pdf"); // Save PDF
    });
    const config = {
      headers: {
          "Content-type": "application/json",
          Accept: "application/json",
           Authorization: `Bearer ${auth}`,
      },
  };
  if (module !== "/invoice/DownloadedChalaan") {
    const response = await axios.post(`${baseUrl}/changeStatusDeliveryChallan`,formData,config)
  }
  };
  return (
    <div>
      <div className="row ms-4 me-4">
      <div className="col-6">
          <Link to={`${module}`}>
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              width:"80px",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              padding:"4px 5px"
            }}
            // onClick={downloadPDF}
          >
            Back
          </button>                                     
          </Link>
        </div>
        <div className="col-6 text-end">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width:"80px",
              padding:"4px 5px"
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
<div className='delivery-chalaan-container mt-4 mb-4 me-3 p-4' id="deliveryChallan">
  <table style={{ width: '100%',border:"1px solid black",borderCollapse: "collapse" }}>
    <tr>
      <td colspan="5" style={{ borderBottom: 'none' }} className='text-center'>
      <u>Delivery Challan</u>
      </td>
    </tr>
    <tr>
      <td colspan="3" style={{ borderTop: 'none',paddingLeft:"7px" }}>
        <br />
        Company Name: <b>Hariox Unit Management Pvt Ltd</b>
      </td>
      <td colspan="5" rowspan="5" style={{ borderTop: 'none',paddingLeft:"7px",textAlign:"center" }}>
        <img src={yeppeLogo} alt="yeppeLogo" style={{height:'80%',width:"80%"}}/>
      </td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Address:</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>
        B-35 3RD FLOOR, BACK SIDE VISHWAS PARK,
        <br />
        UTTAM NAGAR DELHI, West Delhi DL 110059 IN
      </td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Phone No:</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>+91 8700975707</td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Email:</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>
        <a href="mailto:support@yeppe.in">support@yeppe.in</a>
      </td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>GST No:</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>09AAECH8940F1ZE</td>
    </tr>
    <tr>
      <td colspan="5" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>
        <br />
      </td>
    </tr>
    <tr>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Delivery Challan For:</td>
      <td colspan="3" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Shipping to:</td>
    </tr>
    <tr>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Party Name: {item.fullName}</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Shipping Name: </td>
      <td colspan="1" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.fullName}</td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Address:</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.billingAddress}</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Address:</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.billingAddress}</td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Phone No:</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.mobileNo}</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Phone No:</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.mobileNo}</td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Email:</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.Email}</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Email:</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.Email}</td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>GSTIN:</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}></td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>GSTIN:</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}></td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Challan No:</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.orderNo}</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Delivery time:</td>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.deliveryTime}</td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Date:</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.transactionInvoiceCreatedOn ? (item.transactionInvoiceCreatedOn).split(" ")[0] : "" }</td>
      <td colspan="3" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}></td>
    </tr>
    <tr>
      <td style={{ border: 'none',border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>SL NO.</td>
      <td style={{ border: 'none',border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Product</td>
      <td style={{ border: 'none',border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Category</td>
      <td style={{ border: 'none',border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Quantity</td>
      <td style={{ border: 'none',border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Price</td>
    </tr>
    <tr>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>1</td>
      <td style={{paddingLeft:"7px"}}>
       {item.productName}
      </td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.productTitle}</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>1</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.paidAmount}</td>
    </tr>
    <tr>
      <td colspan="3" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>Total</td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}></td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>{item.paidAmount}</td>
    </tr>
    <tr>
      <td colspan="2" style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>
        <br />
        Terms and Conditions:
        <br />
        1. Amount cannot be Refunded.
        <br />
        2. If any damage or package broken,
        <br />
        exchange is available.
        <br />
        <br />
        <br />
      </td>
      <td style={{ border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}></td>
      <td colspan="2" style={{paddingLeft:"7px",textAlign:"center"}}>
        <br />
        <br />
        For, Company Name
        <br />
        <br />
        <img
          src={companySignature}
          alt="company Authorized"
        />
        <br />
        <b>Authorized Signature</b>
        <br />
        <br />
        <br />
      </td>
    </tr>
    <tr>
      <td colspan="2" style={{ border: 'none',border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>
        <br />
        Received By:
        <br />
        Name: {item.fullName}
        <br />
        Comment:
        <br />  
        Date: {item.deliveryDate}
        <br />
        Signature:
        <br />
        <br />
      </td>

      <td colspan="3" style={{ border: 'none',border:"1px solid black",borderCollapse: "collapse",paddingLeft:"7px" }}>
        
        <img
          src={`${baseUrl}/${fullNameStartLetter}/${item.signatureImageName}`}
          alt="buyer Sign"
          style={{minWidth:"400px",height:"130px"}}
        />
      </td>
    </tr>
  </table>
</div>
    </div>

  );
};

export default DeliveryChalaanFormat;
