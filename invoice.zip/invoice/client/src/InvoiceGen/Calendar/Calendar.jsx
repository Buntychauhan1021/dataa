import React, { useState, useEffect } from "react";
import "./Calendar.css";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import baseUrl from "../config/baseUrl";
import axios from "axios";
import Loader from "../Loader/Loader"; // Ensure this is your loader component
import CheckCircleOutlinedIcon from '@mui/icons-material/CheckCircleOutlined';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
const CalendarApp = () => {
  const auth = localStorage.getItem("user");
  const [nav, setNav] = useState(0);
  const [currentMonth, setCurrentMonth] = useState("");
  const [days, setDays] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [datas, setDatas] = useState([]);
  const [loading, setLoading] = useState(true); // Loading state
  // Fetch data function
  const allFetchData = async () => {
    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${auth}`,
        },
      };
      setLoading(true); // Start loading
      const response = await axios.post(
        `${baseUrl}/todayUploadedOrNot`,
        {},
        config
      );
      let uploadedDates = (response.data.result).map((item) => {
        // Split the date into components: MM-DD-YYYY
        let parts = item.created_on.split('-');
        // Ensure the split worked correctly and all parts are valid numbers
        if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
          // Reformat to YYYY-MM-DD, swapping MM and DD to correct the format
          let formattedDate = `${parts[2]}-${parts[1]}-${parts[0]}`;
          let dateObj = new Date(formattedDate);
          // Check if the date is valid
          if (dateObj instanceof Date && !isNaN(dateObj)) {
            return dateObj.toLocaleDateString();
          } else {
            console.error("Invalid Date Object: ", formattedDate);
            return "Invalid Date"; // Return fallback if invalid date
          }
        } else {
          console.error("Invalid date format:", item.created_on);
          return "Invalid Date"; // Return fallback if invalid date format
        }
      });
      console.log("uploaded",uploadedDates)
      setDatas(uploadedDates);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false); // End loading after fetch
    }
  };
  // Fetch data on mount
  useEffect(() => {
    allFetchData();
  }, []);
  // Weekday names
  const weekdays = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];
  // Load the calendar days
  const loadCalendar = () => {
    const dt = new Date();
    if (nav !== 0) {
      dt.setMonth(new Date().getMonth() + nav);
    }
    const year = dt.getFullYear();
    const month = dt.getMonth();
    const monthString = dt.toLocaleDateString("en-US", { month: "long" });
    setCurrentMonth(`${monthString.substring(0, 3)} ${year}`);
    const firstDayOfMonth = new Date(year, month, 1);
    const paddingDays = weekdays.indexOf(
      firstDayOfMonth.toLocaleDateString("en-US", { weekday: "long" })
    );
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    // Calculate the previous month's last day and the number of days to display from the previous month
    const prevMonthDaysInPreviousMonth = new Date(year, month, 0).getDate();
    const prevMonthStartDate = prevMonthDaysInPreviousMonth - paddingDays + 1;
    const calendarDays = [];
    // Add days from the previous month (for padding)
    for (let i = prevMonthStartDate; i <= prevMonthDaysInPreviousMonth; i++) {
      calendarDays.push({
        isCurrentDay: false,
        isFromPrevMonth: true,
      });
    }
    // Add days from the current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dates = `${month + 1}/${i}/${year}`;
      console.log("my dates",dates)
      calendarDays.push({
        day: i,
        date: `${month + 1}/${i}/${year}`,
        isCurrentDay: i === dt.getDate() && nav === 0,
        isFromPrevMonth: false,
        isUploaded: datas.includes(dates)
      });
    }
    // If the calendar ends before Saturday (i.e., not enough days to fill the calendar)
    const remainingDays = 42 - calendarDays.length; // Make sure the calendar is always 6 rows of 7 days
    for (let i = 1; i <= remainingDays; i++) {
      calendarDays.push({
        isCurrentDay: false,
        isFromPrevMonth: true,
      });
    }
    setDays(calendarDays);
  };
  useEffect(() => {
    if (!loading) {
      loadCalendar();
    }
  }, [nav, loading]); // Only load the calendar once loading is done
  const handlePreviousMonth = () => setNav((prev) => prev - 1);
  const handleNextMonth = () => setNav((prev) => prev + 1);
  const handleDayClick = (day) => {
    if (day) {
      setSelectedDate(day.date); // Set selected date to the clicked day
    }
  };
  return (
    <div id="content">
      <div id="container">
        <div id="header">
          <div id="monthDisplay">
            <span onClick={handlePreviousMonth}>
              <ArrowBackIosIcon />
            </span>
            {currentMonth}
            <span onClick={handleNextMonth}>
              <ArrowForwardIosIcon />
            </span>
          </div>
        </div>
        {loading ? (
          <Loader /> // Show loader while data is being fetched
        ) : (
          <>
            <div id="weekdays">
              {weekdays.map((day, index) => (
                <div key={index}>{day.substring(0, 3)}</div>
              ))}
            </div>
            <div id="calendar">
              {days.map((day, index) => (
                <div
                  key={index}
                  className={`day ${day.isCurrentDay ? "currentDay" : ""} ${day.date === selectedDate ? "selectedDay" : ""
                    }`}
                  onClick={() => handleDayClick(day)}
                >
                  {day.day || ""}
                  {day.isUploaded ? <div className="d-flex gap-2"><span style={{ backgroundColor: "green", color: "white", borderRadius: '5px',marginLeft:"auto" }}><CheckCircleOutlinedIcon /></span><span style={{ fontWeight: "500" }}>uploaded</span></div> : ""}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
export default CalendarApp;









