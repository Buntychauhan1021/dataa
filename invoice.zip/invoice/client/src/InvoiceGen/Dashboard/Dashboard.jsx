import React, { useEffect, useState } from "react";
import "./dashboard.css";
import PeopleIcon from "@mui/icons-material/People";
import { Link } from "react-router-dom";
import { ApexChart } from "../Chart/Chart";
// import ApexCharts from 'apexcharts';
import axios from "axios";
import baseUrl from "../config/baseUrl";
const Dashboard = () => {
  const auth = localStorage.getItem("user");
const [allInvoice,setallInvoice]=useState("")
const [DownloadedInvoices,setDownloadedInvoices]=useState("")
const [Chalaan,setChalaan]=useState("")
const [DownloadedChalaan,setDownloadedChalaan]=useState("")

  const fetchdata = async () => {
    try {
       
        const config = {
            headers: {
                "Content-type": "application/json",
                Accept: "application/json",
                 Authorization: `Bearer ${auth}`,
            },
        };
        let result = await axios.post(`${baseUrl}/countInvoice`, {}, config);
        setallInvoice(result.data.allInvoices)
        setDownloadedInvoices(result.data.downloadedInvoice)
        setChalaan(result.data.allDeliveryChallan)
        setDownloadedChalaan(result.data.downloadedDeliveryChallan)
     
    } catch (error) {
        console.error("Error fetching data:", error);
    }
};

useEffect(()=>{
  fetchdata()
},[])

  return (
    <div className="container-fluid">
      <div className="page-inner">
        <div className="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4">
          <div>
            <h3 className="fw-bold mb-3">Dashboard</h3>
            {/* <h6 className="op-7 mb-2">Free Bootstrap 5 Admin Dashboard</h6> */}
          </div>
          {/* <div className="ms-md-auto py-2 py-md-0">
            <Link to="/" className="btn btn-label-info btn-round me-2">
              Manage
            </Link>
            <Link to="/" className="btn btn-primary btn-round">
              Add Customer
            </Link>
          </div> */}
        </div>
        <div className="row">
          <div className="col-sm-6 col-md-3">
            <div className="card card-stats card-round">
              <div className="card-body">
                <div className="row align-items-center">
                  <div className="col-icon">
                    <div className="icon-big text-center icon-primary bubble-shadow-small">
                      <PeopleIcon className="text-white card-icons fs-2" />
                    </div>
                  </div>
                  <div className="col col-stats ms-3 ms-sm-0">
                    <div className="numbers">
                      <p className="card-category"><b>Total Invoices</b></p>
                      <h4 className="card-title">{allInvoice}</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-6 col-md-3">
            <div className="card card-stats card-round">
              <div className="card-body">
                <div className="row align-items-center">
                  <div className="col-icon">
                    <div className="icon-big text-center icon-info bubble-shadow-small">
                      <PeopleIcon className="text-white fs-2" />
                    </div>
                  </div>
                  <div className="col col-stats ms-3 ms-sm-0">
                    <div className="numbers">
                      <p className="card-category"><b>Downloaded Invoices</b></p>
                      <h4 className="card-title">{DownloadedInvoices}</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-6 col-md-3">
            <div className="card card-stats card-round">
              <div className="card-body">
                <div className="row align-items-center">
                  <div className="col-icon">
                    <div className="icon-big text-center icon-success bubble-shadow-small">
                      <PeopleIcon className="text-white fs-2" />
                    </div>
                  </div>
                  <div className="col col-stats ms-3 ms-sm-0">
                    <div className="numbers">
                      <p className="card-category"><b>Chalaan</b></p>
                      <h4 className="card-title">{Chalaan}</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-6 col-md-3">
            <div className="card card-stats card-round">
              <div className="card-body">
                <div className="row align-items-center">
                  <div className="col-icon">
                    <div className="icon-big text-center icon-secondary bubble-shadow-small">
                      <PeopleIcon className="text-white fs-2" />
                    </div>
                  </div>
                  <div className="col col-stats ms-3 ms-sm-0">
                    <div className="numbers">
                      <p className="card-category"><b>Downloaded Chalaan</b></p>
                      <h4 className="card-title">{DownloadedChalaan}</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row">
       <div className="col-12 pt-3">
       <ApexChart/>
       </div>
      </div>
    </div>
  );
};

export default Dashboard;
