
import React from "react";
import { jsPDF } from "jspdf";
import "./InvoiceZenvyFormat.css";
import html2canvas from "html2canvas";
import zenvy from "./zenvy.jpeg"
import { Link, useLocation } from "react-router-dom";
import {
  FaMapMarkerAlt,
  FaTruck,
  FaCalendarAlt,
} from "react-icons/fa";
import axios from "axios";
import baseUrl from "../config/baseUrl";
const InvoiceDetails = ({ invoiceData }) => {
  return (
    <div
      style={{
        width: "800px",
        marginLeft: "10px",
        marginTop: "30px",
        marginBottom: "30px",
      }}
    >
      <div id="invoice" style={{ background: "#fff", padding: "10px", marginLeft: "5px" }}>

        <div className="container" style={{ maxWidth: 900, minHeight: '100vh', padding: '32px 0' }}>
          <div className="rounded-3 shadow-lg p-3 mb-3" style={{ background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)', }}>
            <div className="d-flex flex-wrap justify-content-between align-items-center">
              <div className="d-flex align-items-center">
                <img src={zenvy} alt="Zenvy Logo" style={{ height: '60px', marginRight: '18px' }} />
                <div>
                  <h4 className="fw-bold mb-0" style={{ letterSpacing: 1, color: '#6a82fb' }}>OPEN BRACKET CLOUD SOLUTIONS PRIVATE LIMITED</h4>
                  <p className="mb-0" style={{ fontSize: '0.95rem' }}>GST NO:27AACCO3584C1ZJ</p>
                  <small className="text-muted fst-italic">* Keep this invoice for warranty purposes</small>
                </div>
              </div>
            </div>
          </div>
         <div className="row g-3 mb-2">
  {[
    {
      title: '🧾 Order Info',
      color: '#6a82fb',
      details: [
        `Order ID: ${invoiceData.orderNo}`,
        `Order Date: ${invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}`,
        `Invoice Date: ${invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}`
      ]
    },
    {
      title: '📍 Billing Address',
      color: '#fc5c7d',
      details: [
        `${invoiceData.fullName
          .split(" ")
          .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
          .join(" ")}`,
        invoiceData.billingAddress,
        invoiceData.mobileNo
      ]
    }
  ].map((card, idx) => (
    <div key={idx} className="col-6">
      <div className="rounded-3 shadow-sm h-100 p-3" style={{ background: '#fff', borderLeft: `6px solid ${card.color}` }}>
        <h6 className="fw-bold mb-2" style={{ color: card.color }}>{card.title}</h6>
        {card.details.map((line, i) => (
          <p key={i} className="mb-1 text-secondary">{line}</p>
        ))}
      </div>
    </div>
  ))}
</div>

          <div className="rounded-3 shadow-lg bg-white p-0 mb-2 overflow-hidden" style={{ borderLeft: '5px solid #11998e' }}>
            <table className="table table-borderless align-middle text-center mb-0">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Title</th>
                  <th>Qty</th>
                  <th>Price (₹)</th>
                  <th>Tax (₹)</th>
                  <th>Total (₹)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{invoiceData.productName}</td>
                  <td>{invoiceData.productTitle}</td>
                  <td>1</td>
                  <td>{invoiceData.productPrice}</td>
                  <td>-</td>
                  <td>-</td>
                </tr>
                <tr style={{ background: '#fcf1f4' }}>
                  <td colSpan="4" className="text-end fw-semibold">Discount</td>
                  <td colSpan="2" className="text-danger fw-bold">₹{invoiceData.discount}</td>
                </tr>
                <tr>
                  <td colSpan="3" className="text-end fw-semibold">Taxable Value</td>
                  <td>{invoiceData.baseAmount}</td>
                  <td>{invoiceData.gst}</td>
                  <td>{(invoiceData.baseAmount + invoiceData.gst).toFixed(2)}</td>
                </tr>
                <tr>
                  <td colSpan="3" className="text-end fw-semibold">PlateForm Fee</td>
                  <td>{invoiceData.shippingCharge1}</td>
                  <td>{invoiceData.shippingCharge2}</td>
                  <td>{invoiceData.shippingCharges}</td>
                </tr>
                <tr style={{ background: '#e0f7fa', fontWeight: 700 }}>
                  <td colSpan="3" className="text-end">Total</td>
                  <td></td>
                  <td>{(invoiceData.gst + invoiceData.shippingCharge2).toFixed(2)}</td>
                  <td>{invoiceData.paidAmount.toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="d-flex justify-content-end mb-2">
            <div className="rounded-3 shadow-lg px-2 py-2 d-flex align-items-center" style={{ borderLeft: '6px solid #11998e', borderRight: '6px solid #11998e' }}>
              <div className="fw-bold text-dark" style={{ fontSize: '1rem' }}>Grand Total: ₹{invoiceData.paidAmount.toFixed(2)}</div>
            </div>
          </div>
          <div className="rounded-3 shadow-lg p-3 mb-4" style={{ borderRight: '6px solid #fc5c7d' }}>
            <h6 className="fw-bold mb-2 text-primary">🏛️Direct Deposit / Bank Wire Transfer</h6>
            <p className="mb-1">Deposit the amount at your nearest <strong>UNION BANK OF INDIA</strong> in our accounts in favour of:</p>
            <p className="mb-3"><strong>OPEN BRACKET CLOUD SOLUTIONS PRIVATE LIMITED</strong></p>
            <div className="row">
              <div className="col-12 col-sm-6">
                <h6 className="fw-bold mb-2 text-primary">💳Transfer Using Account</h6>
                <ul className="list-unstyled mb-3">
                  <li><strong>Bank:</strong> UNION BANK OF INDIA</li>
                  <li><strong>A/C No:</strong> 012021010000124</li>
                  <li><strong>IFSC Code:</strong> UBIN0901202</li>
                </ul>
              </div>
              <div className="col-6">
                <p className="mb-1"><strong>Confirmation:</strong><br />Send payment confirmation to: <a href="mailto:support@zenvvy.co.in" style={{ textDecoration: 'underline' }}>support@zenvvy.co.in</a></p>
                <p className="mb-0"><strong>More Info:</strong><br /><a href="https://zenvvy.co.in/" target="_blank" rel="noreferrer" style={{ textDecoration: 'underline' }}>https://zenvvy.co.in/</a></p>
              </div>
            </div>
            <div className="text-center mt-2">
              <small className="w-100">
                OFFICE NO 1, NAJAF APARTMENT, Chapel Road, Bandra
West, Mumbai, Mumbai Suburban, Maharashtra, 400050
              </small>
              <br/>
              <small className="w-100 fst-italic">
                This is a computer-generated invoice. No signature required.
              </small>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
function InvoiceElyvnFormat() {
  const auth = localStorage.getItem("user");
  const location = useLocation();
  const { item, module } = location.state || {};
  const downloadPDF = async () => {
    const input = document.getElementById("invoice");
    const formData = new FormData();
    formData.append("orderNo", item.orderNo);
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG");
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${item.orderNo}` + ".pdf");
    });
    const config = {
      headers: {
        "Content-type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${auth}`,
      },
    };
    if (module !== "/Invoice/Downloaded") {
      await axios.post(
        `${baseUrl}/changeStatusDownloadedInvoice`,
        formData,
        config
      );
    }
  };
  return (
    <div>
      <div className="row m-0 p-0">
        <div className="col-6">
          <Link to={`${module}`}>
            <button
              style={{
                backgroundColor: "#ff9707",
                color: "#fff",
                width: "80px",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "16px",
                marginTop: "20px",
                padding: "4px 5px",
              }}
            // onClick={downloadPDF}
            >
              Back
            </button>
          </Link>
        </div>
        <div className="col-5 offset-1">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width: "80px",
              padding: "4px 5px",
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
      <InvoiceDetails invoiceData={item} />
    </div>
  );
}
export default InvoiceElyvnFormat;





