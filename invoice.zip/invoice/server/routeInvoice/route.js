const route = require("express").Router();
const path = require("path");
const multer = require("multer");

// Token Verification Controller
const authMiddleware = require('../middleware/authMiddleware.js')

// Login Controller
const loginController = require("../InvoiceController/loginController.js");

// Dashboard Controller
const dashboardController=require("../InvoiceController/dashboardController.js")

// Upload Invoice Controller
const uploadInvoiceController = require('../InvoiceController/uploadExcelController.js')

// Download Invoice Controller
const forDownloadController = require("../InvoiceController/forDownloadController.js")

// Downloaded Invoice Controller
const downloadedController = require("../InvoiceController/downloadedController.js")

// Download Delivry Challan Controller
const deliveryChallanController = require("../InvoiceController/deliveryChallaan.js")

// Downloaded Delivery challan Controller
const downloadedChallanController = require('../InvoiceController/DownloadedChallan.js')

// tracking order controller
const trackingController = require("../InvoiceController/trackingOrderStatusController.js")

//EXCEL File Upload Code
const filePath = path.join(__dirname,"../Public/img")
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, filePath)
},
filename: function (req, file, cb) {
    cb(null,file.fieldname+Date.now()+".xlsx")
}
});
const uploads = multer({ storage: storage });

// lOGIN API ROUTE
route.post("/login",uploads.none(),loginController.login)

// DASHBOARD API ROUTE
route.post("/DashboardByDay",uploads.none(),authMiddleware,dashboardController.DashboardByDay)
route.post("/countInvoice",uploads.none(),authMiddleware,dashboardController.countInvoice)

// UPLOAD EXCEL FILE API ROUTE
route.post("/uploadInvoiceExcel",uploads.single('docxfileupload'),authMiddleware,uploadInvoiceController.uploadInvoiceExcel)
route.post("/todayUploadedOrNot",uploads.none(),authMiddleware,uploadInvoiceController.todayUploadedOrNot)

// DOWNLOAD INVOICE API ROUTE
route.post("/fetchInvoices",uploads.none(),authMiddleware,forDownloadController.fetchInvoices)
route.post("/changeStatusDownloadedInvoice",uploads.none(),authMiddleware,forDownloadController.changeStatusDownloadedInvoice)

//DOWNLOADED INVOICE API ROUTE
route.post("/fetchDownloadedInvoices",uploads.none(),authMiddleware,downloadedController.fetchDownloadedInvoices)

// DOWNLOAD DELIVERY CHALLAN API ROUTE
route.post("/fetchDelivryChallan",uploads.none(),authMiddleware,deliveryChallanController.fetchDelivryChallan)
route.post("/changeStatusDeliveryChallan",uploads.none(),authMiddleware,deliveryChallanController.changeStatusDeliveryChallan)

// DOWNLOADED DELIVERY CHALLAN API ROUTE
route.post("/fetchDownloadedChallan",uploads.none(),authMiddleware,downloadedChallanController.fetchDownloadedChallan)

// tracking status Route
route.post("/trackOrderByAwb",uploads.none(),authMiddleware,trackingController.trackOrderByAwb)
route.post("/changeOrderStatus",uploads.none(),authMiddleware,trackingController.changeOrderStatus)


route.post("/uploadtbl_cron_log",uploads.single('docxfileupload'),uploadInvoiceController.uploadtbl_cron_log)
module.exports = route;

