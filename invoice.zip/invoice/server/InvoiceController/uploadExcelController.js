const mysqlcon = require("../config/db_connection");
const axios = require("axios");
const path = require("path");
const xlsx = require("xlsx");
const fs = require("fs");
const { log } = require("console");


module.exports.uploadInvoiceExcel = async (req, res) => {
  try {
    function convertSerialDate(serialDate) {
      const startDate = new Date(1899, 11, 30);
      const millisecondsPerDay = 86400000;
      const adjustedSerialDate = serialDate;
      const date = new Date(
        startDate.getTime() + adjustedSerialDate * millisecondsPerDay - 540000
      );
      const day = String(date.getDate()).padStart(2, "0");
      const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-indexed
      const year = date.getFullYear();
      const hours = String(date.getHours()).padStart(2, "0");
      const minutes = String(date.getMinutes()).padStart(2, "0");
      return `${day}-${month}-${year} ${hours}:${minutes}`;
    }
    function getRandomTimeBetween8AMand10PM() {
      const startHour = 8;
      const endHour = 22;
      const hours = String(
        Math.floor(Math.random() * (endHour - startHour + 1)) + startHour
      ).padStart(2, "0");
      const minutes = String(Math.floor(Math.random() * 60)).padStart(2, "0");
      const seconds = String(Math.floor(Math.random() * 60)).padStart(2, "0");
      return `${hours}:${minutes}:${seconds}`;
    }
    function getRandomDeliveryDate(serialDate) {
      const baseDate = new Date(serialDate);
      const randomDays = Math.floor(Math.random() * (5 - 4 + 1)) + 4;
      baseDate.setDate(baseDate.getDate() + randomDays);
      const day = String(baseDate.getDate()).padStart(2, "0");
      const month = String(baseDate.getMonth() + 1).padStart(2, "0");
      const year = baseDate.getFullYear();
      return `${day}-${month}-${year}`;
    }
    function generateAWBNumber() {
      const length = Math.floor(Math.random() * (9 - 8 + 1)) + 8;
      const awb_no = Math.floor(Math.random() * Math.pow(10, length - 1)) + Math.pow(10, length - 1);
      return "EL" + awb_no.toString();
    }
    const categoryTitles = {
      1: "Appliances",
      2: "Beauty Toys And More",
      3: "Electronic",
      4: "Fashion",
      5: "Grocery",
      6: "Home And Furniture",
      7: "Mobiles",
      8: "Others",
      9: "Television",
      10: "Kitchen Appliances",
      11: "Cooling Appliances",
      12: "Washing Machine",
      13: "Refrigerators",
      14: "Home Appliances",
      15: "Air Conditioners",
      16: "Food Essentials",
      17: "Personal Care",
      18: "Household Care",
      19: "Home & Kitchen",
      20: "Realme",
      21: "Poco",
      22: "Vivo",
      23: "Samsung",
      24: "Motorola",
      25: "Iphone",
      26: "Oppo",
      27: "Nokia",
      28: "Men's Top Wear",
      29: "Men's Bottom Wear",
      30: "Women Ethnics",
      31: "Women Western",
      32: "Men Footwear",
      33: "Women Footwear",
      34: "Watch And Accessories",
      35: "Bags, Suitcases & Luggage",
      36: "Kids",
      37: "Essentials",
      38: "Winter",
      39: "Audio",
      40: "Camera & Accessories",
      41: "Computer Peripherals",
      42: "Gaming",
      43: "Health & Personal Care",
      44: "Laptop Accessories",
      45: "Mobile Accessories",
      46: "Powerbank",
      47: "Smart Home Automation",
      48: "Storage",
      49: "Tablets",
      50: "Fairness Cream",
      51: "Plastic Chair",
      52: "Delhi",
    };
    let NotFoundSutaibleProductPrice = [];

    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: "No file uploaded" });
    }
    const filePath = path.join(__dirname, "../Public/img", `${file.filename}`);
    try {
      await fs.promises.access(filePath, fs.constants.F_OK);
    } catch (err) {
      console.log(err);
      return res.status(404).json({ error: "File not found" });
    }
    const data = fs.readFileSync(filePath);
    const workbook = xlsx.read(data, { type: "buffer" });
    const sheetName = workbook.SheetNames[1];
    const sheet = workbook.Sheets[sheetName];
    const jsonData = xlsx.utils.sheet_to_json(sheet);
    const headers = [
      "Order No",
      "Invoice ID",
      "Paid Amount",
      "Full Name",
      "Created On",
      "Mobile No",
      "Billing Address",
      "Email",
      "I-Type",
      "City"
    ];
    let result = jsonData
      .map((row) => {
        let obj = {};
        headers.forEach((header) => {
          obj[header] = row[header] || null;
        });
        return obj;
      })
      .filter(Boolean);
    let currentIndex = 0;
    for (const entry of result) {
      let response;
      //new changes
      if (entry["I-Type"] == 'rishi') {
        response = await axios.get("https://api.xuwi.co.in/getServices");
      } else if (entry["I-Type"] == 'oryko') {
        response = await axios.get("https://api.oryko.in/course");
      } else if (entry["I-Type"] == 'velixa') {
        response = await axios.get("https://api.velixa.co.in/getallproducts");
      } else if (entry["I-Type"] == 'elvyn') {
        response = await axios.get("https://api.elvyn.co.in/getallproducts");
      } else if (entry["I-Type"] == 'streakzen') {
        response = await axios.get("https://streakwears.com/get/product/list");
        // response = await axios.post("https://yeppe.co.in/product-list");
      }
      else if (entry["I-Type"] === 'zenvy') {
        response = await axios.get("https://api.zenvvy.co.in/getServices");
      } else {
        response = await axios.post("https://yeppe.co.in/product-list");
      }
      // if (!response.data || !Array.isArray(response.data)) {
      //   return res.status(400).json({ error: "Invalid data format received" });
      // }
      let products = [];
      let firstCategoryId;

      if (entry["I-Type"] == 'rishi') {
       
        products = response.data.map((item) => {
          firstCategoryId = item.category.split(",")[0].trim();
          return {
            productPrice: item.price,
            productname: item.category || "Unknown Product",
            productTitle: item.title || "Unknown Title",
          };
        });
      } else if (entry["I-Type"] == 'elvyn') {

        products = response.data.data.map((item) => {
          firstCategoryId = item.subcategory_name.split(",")[0].trim();
          return {
            productPrice: parseFloat(item.rate),
            productname: item.subcategory_name || "Unknown Product",
            productTitle: item.product_name || "Unknown Title",
          };
        });
      } else if (entry["I-Type"] === 'oryko') {
        response.data.data.forEach((item) => {
          item.products.forEach((course) => {
            const priceArray = JSON.parse(course.price);
            const productPrice = parseFloat(priceArray[0]?.price || 0);
            products.push({
              productPrice: productPrice,
              productname: course.product_name || "Unknown Product",
              productTitle: course.category_name || "Unknown Title",
            });
          });
        })
      }
      else if (entry["I-Type"] === 'velixa') {
        response.data.data.forEach((item) => {
          const priceArray = JSON.parse(item.price);
          const productPrice = parseFloat(priceArray[0]?.price || 0);
          products.push({
            productPrice: productPrice,
            productname: item.product_name || "Unknown Product",
            productTitle: item.category_name || "Unknown Title",
          });

        })
      } else if (entry["I-Type"] === 'streakzen') {
        response.data.data.map((item) => {
          const firstCategory = item.categories?.[0]?.name || "Others";

          products.push({
            productPrice: item.original_price,
            productname: item.name || "Unknown Product",
            productTitle: firstCategory,
          });
        });


        // products = response.data.map((item) => {
        //   firstCategoryId = item.category.split(",")[0].trim();
        //   return {
        //     productPrice: item.selling_price,
        //     productname: item.name || "Unknown Product",
        //     productTitle: categoryTitles[firstCategoryId] || "Others",
        //   };
        // });
      }
      else if (entry["I-Type"] === 'zenvy') {
        response.data.forEach(category => {
          category.products.forEach(product => {
            const priceArray = JSON.parse(product.price); // parse the price string
            products.push({
              productTitle: category.categoryName,
              productname: product.product_name,
              productPrice: priceArray[0]?.price // fetch only the first price value
            });
          });
        });
        //console.log(products);

      }
      else {
        // Otherwise, use the second map logic
        products = response.data.map((item) => {
          firstCategoryId = item.category.split(",")[0].trim();
          return {
            productPrice: item.selling_price,
            productname: item.name || "Unknown Product",
            productTitle: categoryTitles[firstCategoryId] || "Others",
          };
        });
      }




      const paidAmount = parseFloat(entry["Paid Amount"] || 0);
      let selectedProduct = null;
      let attempts = 0;
      let foundProduct = false;
      while (attempts < 5) {
        for (let i = currentIndex; i < products.length; i++) {
          const product = products[i];
          if (
            (product.productPrice > 20000 &&
              product.productPrice - paidAmount > 500 &&
              product.productPrice - paidAmount < 5000) ||
            (product.productPrice <= 20000 &&
              product.productPrice > 8000 &&
              product.productPrice - paidAmount > 500 &&
              product.productPrice - paidAmount < 1500) ||
            (product.productPrice <= 8000 &&
              product.productPrice > 3000 &&
              product.productPrice - paidAmount > 250 &&
              product.productPrice - paidAmount < 1000) ||
            (product.productPrice <= 3000 &&
              product.productPrice > 1500 &&
              product.productPrice - paidAmount > 10 &&
              product.productPrice - paidAmount <= 200) ||
            (product.productPrice <= 1500 &&
              product.productPrice - paidAmount > 10 &&
              product.productPrice - paidAmount < 250)
          ) {
            selectedProduct = product;
            currentIndex = (i + 1) % products.length;
            foundProduct = true;
            break;
          }
        }
        if (foundProduct) {
          break;
        }
        if (attempts == 4) {
          NotFoundSutaibleProductPrice.push(entry["Order No"]);
        }
        attempts++;
        currentIndex = 0;
      }
      let a = 1;
      if (!selectedProduct) {
        a = 0
        let twoProductAttempts = 0;
        while (twoProductAttempts < 4) {
          outerLoop:
          for (let i = 0; i < products.length; i++) {
            for (let j = i + 1; j < products.length; j++) {
              const combinedPrice = parseFloat(products[i].productPrice) + parseFloat(products[j].productPrice);


              const priceDiff = combinedPrice - paidAmount;

              if (
                combinedPrice > 20000 && priceDiff > 500 && priceDiff < 5000 ||
                (combinedPrice <= 20000 && combinedPrice > 8000 && priceDiff > 500 && priceDiff < 1500) ||
                (combinedPrice <= 8000 && combinedPrice > 3000 && priceDiff > 250 && priceDiff < 1000) ||
                (combinedPrice <= 3000 && combinedPrice > 1500 && priceDiff > 10 && priceDiff <= 200) ||
                (combinedPrice <= 1500 && priceDiff > 10 && priceDiff < 250)
              ) {
                selectedProduct = {
                  combined: true,
                  products: [products[i], products[j]],
                  productPrice: combinedPrice
                };
                // console.log(selectedProduct);



                foundProduct = true;
                break outerLoop;
              }
            }
          }
          if (foundProduct) break;
          twoProductAttempts++;
        }

        if (!foundProduct) {
          NotFoundSutaibleProductPrice.push(entry["Order No"]);
        }
      }

      if (!selectedProduct) {
        a = 0;
        let multiProductAttempts = 0;

        while (multiProductAttempts < 4) {
          let productCount = products.length;

          outerLoop:
          for (let i = 0; i < productCount; i++) {
            for (let j = i + 1; j < productCount; j++) {
              for (let k = j + 1; k < productCount; k++) {
                const combinedPrice =
                  parseFloat(products[i].productPrice) +
                  parseFloat(products[j].productPrice) +
                  parseFloat(products[k].productPrice);

                const priceDiff = combinedPrice - paidAmount;

                if (
                  (combinedPrice > 20000 && priceDiff > 500 && priceDiff < 5000) ||
                  (combinedPrice <= 20000 && combinedPrice > 8000 && priceDiff > 500 && priceDiff < 1500) ||
                  (combinedPrice <= 8000 && combinedPrice > 3000 && priceDiff > 250 && priceDiff < 1000) ||
                  (combinedPrice <= 3000 && combinedPrice > 1500 && priceDiff > 10 && priceDiff <= 200) ||
                  (combinedPrice <= 1500 && priceDiff > 10 && priceDiff < 250)
                ) {
                  selectedProduct = {
                    combined: true,
                    products: [products[i], products[j], products[k]],
                    productPrice: combinedPrice
                  };

                  foundProduct = true;
                  break outerLoop;
                }
              }
            }
          }

          if (foundProduct) break;
          multiProductAttempts++;
        }

        if (!foundProduct) {
          NotFoundSutaibleProductPrice.push(entry["Order No"]);
        }
      }



      // console.log("lllllllllllll", selectedProduct);


      if (selectedProduct) {


        let shippingCharge1;
        if (selectedProduct.productPrice <= 1000 && selectedProduct.productPrice >= 302) {
          //  shippingCharge = Math.floor(Math.random() * (100 - 90 + 1)) + 90;
          shippingCharge1 = Math.floor(Math.random() * (100 - 90 + 1)) + 90;
        } else if (selectedProduct.productPrice < 301) {


          shippingCharge1 = Math.floor(Math.random() * (30 - 20 + 1)) + 20;
        }
        else {
          shippingCharge1 = Math.floor(Math.random() * (200 - 217 + 1)) + 217;
        }
        const shippingCharge2 = (shippingCharge1 * 18) / 100;
        // const shippingCharge2 = shippingCharge-shippingCharge1
        let shippingCharge = shippingCharge1 + shippingCharge2;
        const baseAmount = (paidAmount - shippingCharge) / 1.18;
        const gst = baseAmount * 0.18;
        const discount = selectedProduct.productPrice - baseAmount;
        if (a == 0) {
          entry.productname = (selectedProduct?.products || [])
            .slice(0, 4) // max 4 products
            .map(p => p?.productname || "")
            .join("&&&");

          entry.productTitle = (selectedProduct?.products || [])
            .slice(0, 4) // max 4 products
            .map(p => p?.productTitle || "")
            .join("&&&");
          // console.log(entry.productTitle);

          entry.productPrice = (selectedProduct?.products || [])
            .slice(0, 4) // max 4 products
            .map(p => p?.productPrice || "")
            .join("&&&");
          // console.log(entry.productPrice);
        }
        else {
          entry.productname = selectedProduct.productname
          entry.productTitle = selectedProduct.productTitle;
          entry.productPrice = selectedProduct.productPrice;
        }
        // entry.productname = selectedProduct.products[0].productname + selectedProduct.products[1].productname;


        entry.BaseAmount = baseAmount.toFixed(2);
        entry.GST = gst.toFixed(2);
        entry.ShippingCharge = shippingCharge.toFixed(2);
        entry.shippingCharge1 = shippingCharge1;
        entry.shippingCharge2 = shippingCharge2.toFixed(2);
        entry.Discount = discount.toFixed(2);
        entry.TotalAmount = paidAmount.toFixed(2);
      }
      let serialDate = convertSerialDate(entry["Created On"]);
      let deliveryDate = getRandomDeliveryDate(
        serialDate.split(" ")[0].split("-").reverse().join("-")
      );
      let deliveryTime = getRandomTimeBetween8AMand10PM();
      const awb_no = generateAWBNumber();
      const details = {
        orderNo: entry["Order No"],
        invoiceId: entry["Invoice ID"],
        paidAmount: entry["Paid Amount"],
        fullName: entry["Full Name"],
        transactionInvoiceCreatedOn: serialDate,
        mobileNo: entry["Mobile No"],
        Email: entry["Email"],
        billingAddress: entry["Billing Address"],
        InvoiceType: entry["I-Type"],
        city: entry["City"],
        productName: entry.productname,
        productTitle: entry.productTitle,
        awbNumber: awb_no,
        productPrice: entry.productPrice,
        baseAmount: entry.BaseAmount,
        gst: entry.GST,
        deliveryTime: deliveryTime,
        deliveryDate: deliveryDate,
        shippingCharges: entry.ShippingCharge,
        shippingCharge1: entry.shippingCharge1,
        shippingCharge2: entry.shippingCharge2,
        discount: entry.Discount,
        totalAmount: entry.TotalAmount,
      };
      let sqlll = "SELECT orderNo FROM tbl_invoicedata";
      let data = await mysqlcon(sqlll);
      let dataa = data.filter((item) => item.orderNo == entry["Order No"]);
      if (dataa.length == 0) {
        if (details.productName) {

          //  let orderNo = entry["Order No"]
          // const detailForTrackStatus = {
          //   awb_no,
          //   orderNo
          // }
          //  const sqlForTrack = "INSERT INTO  tracking_order SET ?";
          const sql = "INSERT INTO tbl_invoicedata SET ?";
          try {
            //   await mysqlcon(sqlForTrack, [detailForTrackStatus])
            await mysqlcon(sql, [details]);
          } catch (err) {
            console.error("Error inserting data into MySQL", err);
          }
        }
      }
    }
    //return res.json(NotFoundSutaibleProductPrice);
    return res.status(200).json({
      result: "Invoice Created Successfully",
      NotFoundSutaibleProductPrice: NotFoundSutaibleProductPrice,
    });
  } catch (error) {
    console.error("Internal server error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};


// module.exports.uploadInvoiceExcel = async (req, res) => {
//   try {
//     function convertSerialDate(serialDate) {
//       const startDate = new Date(1899, 11, 30);
//       const millisecondsPerDay = 86400000;
//       const adjustedSerialDate = serialDate;
//       const date = new Date(
//         startDate.getTime() + adjustedSerialDate * millisecondsPerDay - 540000
//       );
//       const day = String(date.getDate()).padStart(2, "0");
//       const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-indexed
//       const year = date.getFullYear();
//       const hours = String(date.getHours()).padStart(2, "0");
//       const minutes = String(date.getMinutes()).padStart(2, "0");
//       return `${day}-${month}-${year} ${hours}:${minutes}`;
//     }
//     function getRandomTimeBetween8AMand10PM() {
//       const startHour = 8;
//       const endHour = 22;
//       const hours = String(
//         Math.floor(Math.random() * (endHour - startHour + 1)) + startHour
//       ).padStart(2, "0");
//       const minutes = String(Math.floor(Math.random() * 60)).padStart(2, "0");
//       const seconds = String(Math.floor(Math.random() * 60)).padStart(2, "0");
//       return `${hours}:${minutes}:${seconds}`;
//     }
//     function getRandomDeliveryDate(serialDate) {
//       const baseDate = new Date(serialDate);
//       const randomDays = Math.floor(Math.random() * (5 - 4 + 1)) + 4;
//       baseDate.setDate(baseDate.getDate() + randomDays);
//       const day = String(baseDate.getDate()).padStart(2, "0");
//       const month = String(baseDate.getMonth() + 1).padStart(2, "0");
//       const year = baseDate.getFullYear();
//       return `${day}-${month}-${year}`;
//     }
//     function generateAWBNumber() {
//       const length = Math.floor(Math.random() * (9 - 8 + 1)) + 8;
//       const awb_no = Math.floor(Math.random() * Math.pow(10, length - 1)) + Math.pow(10, length - 1);
//       return "EL" + awb_no.toString();
//     }
//     const categoryTitles = {
//       1: "Appliances",
//       2: "Beauty Toys And More",
//       3: "Electronic",
//       4: "Fashion",
//       5: "Grocery",
//       6: "Home And Furniture",
//       7: "Mobiles",
//       8: "Others",
//       9: "Television",
//       10: "Kitchen Appliances",
//       11: "Cooling Appliances",
//       12: "Washing Machine",
//       13: "Refrigerators",
//       14: "Home Appliances",
//       15: "Air Conditioners",
//       16: "Food Essentials",
//       17: "Personal Care",
//       18: "Household Care",
//       19: "Home & Kitchen",
//       20: "Realme",
//       21: "Poco",
//       22: "Vivo",
//       23: "Samsung",
//       24: "Motorola",
//       25: "Iphone",
//       26: "Oppo",
//       27: "Nokia",
//       28: "Men's Top Wear",
//       29: "Men's Bottom Wear",
//       30: "Women Ethnics",
//       31: "Women Western",
//       32: "Men Footwear",
//       33: "Women Footwear",
//       34: "Watch And Accessories",
//       35: "Bags, Suitcases & Luggage",
//       36: "Kids",
//       37: "Essentials",
//       38: "Winter",
//       39: "Audio",
//       40: "Camera & Accessories",
//       41: "Computer Peripherals",
//       42: "Gaming",
//       43: "Health & Personal Care",
//       44: "Laptop Accessories",
//       45: "Mobile Accessories",
//       46: "Powerbank",
//       47: "Smart Home Automation",
//       48: "Storage",
//       49: "Tablets",
//       50: "Fairness Cream",
//       51: "Plastic Chair",
//       52: "Delhi",
//     };
//     let NotFoundSutaibleProductPrice = [];

//     const file = req.file;
//     if (!file) {
//       return res.status(400).json({ error: "No file uploaded" });
//     }
//     const filePath = path.join(__dirname, "../Public/img", `${file.filename}`);
//     try {
//       await fs.promises.access(filePath, fs.constants.F_OK);
//     } catch (err) {
//       console.log(err);
//       return res.status(404).json({ error: "File not found" });
//     }
//     const data = fs.readFileSync(filePath);
//     const workbook = xlsx.read(data, { type: "buffer" });
//     const sheetName = workbook.SheetNames[1];
//     const sheet = workbook.Sheets[sheetName];
//     const jsonData = xlsx.utils.sheet_to_json(sheet);
//     const headers = [
//       "Order No",
//       "Invoice ID",
//       "Paid Amount",
//       "Full Name",
//       "Created On",
//       "Mobile No",
//       "Billing Address",
//       "Email",
//       "I-Type",
//       "City"
//     ];
//     let result = jsonData
//       .map((row) => {
//         let obj = {};
//         headers.forEach((header) => {
//           obj[header] = row[header] || null;
//         });
//         return obj;
//       })
//       .filter(Boolean);
//     let currentIndex = 0;
//     for (const entry of result) {
//       let response;
//       //new changes
//       if (entry["I-Type"] == 'rishi') {
//         response = await axios.get("https://api.xuwi.co.in/getServices");
//       } else if (entry["I-Type"] == 'oryko') {
//         response = await axios.get("https://api.oryko.in/course");
//       } else if (entry["I-Type"] == 'velixa') {
//         response = await axios.get("https://api.velixa.co.in/getallproducts");
//       } else if (entry["I-Type"] == 'elvyn') {
//         response = await axios.get("https://api.elvyn.co.in/getallproducts");
//       } else if (entry["I-Type"] == 'streakzen') {
//         response = await axios.post("https://yeppe.co.in/product-list");
//       }
//       else if (entry["I-Type"] === 'zenvy') {

//         response = await axios.get("https://api.zenvvy.co.in/getServices");

//       } else {
//         response = await axios.post("https://yeppe.co.in/product-list");
//       }


//       // if (!response.data || !Array.isArray(response.data)) {
//       //   return res.status(400).json({ error: "Invalid data format received" });
//       // }
//       // console.log("hjbkn");
//       // console.log("hbjnkl");

//       let products = [];
//       let firstCategoryId;

//       if (entry["I-Type"] == 'rishi') {
//         // If the type is 'rishi', use the first map logic
//         products = response.data.map((item) => {
//           firstCategoryId = item.category.split(",")[0].trim();
//           return {
//             productPrice: item.price,
//             productname: item.category || "Unknown Product",
//             productTitle: item.title || "Unknown Title",
//           };
//         });
//       } else if (entry["I-Type"] == 'elvyn') {

//         products = response.data.data.map((item) => {
//           firstCategoryId = item.subcategory_name.split(",")[0].trim();
//           return {
//             productPrice: parseFloat(item.rate),
//             productname: item.subcategory_name || "Unknown Product",
//             productTitle: item.product_name || "Unknown Title",
//           };
//         });
//       } else if (entry["I-Type"] === 'oryko') {
//         response.data.data.forEach((item) => {
//           item.products.forEach((course) => {
//             const priceArray = JSON.parse(course.price);
//             const productPrice = parseFloat(priceArray[0]?.price || 0);
//             products.push({
//               productPrice: productPrice,
//               productname: course.product_name || "Unknown Product",
//               productTitle: course.category_name || "Unknown Title",
//             });
//           });
//         })
//       }
//       else if (entry["I-Type"] === 'velixa') {
//         response.data.data.forEach((item) => {
//           const priceArray = JSON.parse(item.price);
//           const productPrice = parseFloat(priceArray[0]?.price || 0);
//           products.push({
//             productPrice: productPrice,
//             productname: item.product_name || "Unknown Product",
//             productTitle: item.category_name || "Unknown Title",
//           });

//         })
//       } else if (entry["I-Type"] === 'streakzen') {
//         products = response.data.map((item) => {
//           firstCategoryId = item.category.split(",")[0].trim();
//           return {
//             productPrice: item.selling_price,
//             productname: item.name || "Unknown Product",
//             productTitle: categoryTitles[firstCategoryId] || "Others",
//           };
//         });
//       }
//       else if (entry["I-Type"] === 'zenvy') {
//         response.data.forEach(category => {
//           category.products.forEach(product => {
//             const priceArray = JSON.parse(product.price); // parse the price string
//             products.push({
//               productTitle: category.categoryName,
//               productname: product.product_name,
//               productPrice: priceArray[0]?.price // fetch only the first price value
//             });
//           });
//         });
//         //console.log(products);

//       }
//       else {
//         // Otherwise, use the second map logic
//         products = response.data.map((item) => {
//           firstCategoryId = item.category.split(",")[0].trim();
//           return {
//             productPrice: item.selling_price,
//             productname: item.name || "Unknown Product",
//             productTitle: categoryTitles[firstCategoryId] || "Others",
//           };
//         });
//       }




//       const paidAmount = parseFloat(entry["Paid Amount"] || 0);
//       let selectedProduct = null;
//       let attempts = 0;
//       let foundProduct = false;
//       while (attempts < 5) {
//         for (let i = currentIndex; i < products.length; i++) {
//           const product = products[i];
//           if (
//             (product.productPrice > 20000 &&
//               product.productPrice - paidAmount > 500 &&
//               product.productPrice - paidAmount < 6000) ||
//             (product.productPrice <= 20000 &&
//               product.productPrice > 8000 &&
//               product.productPrice - paidAmount > 500 &&
//               product.productPrice - paidAmount < 1500) ||
//             (product.productPrice <= 8000 &&
//               product.productPrice > 3000 &&
//               product.productPrice - paidAmount > 250 &&
//               product.productPrice - paidAmount < 1000) ||
//             (product.productPrice <= 3000 &&
//               product.productPrice > 1500 &&
//               product.productPrice - paidAmount > 10 &&
//               product.productPrice - paidAmount <= 200) ||
//             (product.productPrice <= 1500 &&
//               product.productPrice - paidAmount > 10 &&
//               product.productPrice - paidAmount < 500)
//           ) {
//             selectedProduct = product;
//             currentIndex = (i + 1) % products.length;
//             foundProduct = true;
//             break;
//           }
//         }
//         if (foundProduct) {
//           break;
//         }
//         if (attempts == 4) {
//           NotFoundSutaibleProductPrice.push(entry["Order No"]);
//         }
//         attempts++;
//         currentIndex = 0;
//       }
//       if (selectedProduct) {
//          console.log(selectedProduct);

//         let shippingCharge1;
//         if (selectedProduct.productPrice <= 1000 && selectedProduct.productPrice >= 300) {
//           //  shippingCharge = Math.floor(Math.random() * (100 - 90 + 1)) + 90;
//           shippingCharge1 = Math.floor(Math.random() * (100 - 90 + 1)) + 90;
//         } else if (selectedProduct.productPrice < 300) {
//           shippingCharge1 = Math.floor(Math.random() * (30 - 20 + 1)) + 20;
//         }
//         else {
//           shippingCharge1 = Math.floor(Math.random() * (200 - 217 + 1)) + 217;
//         }
//         const shippingCharge2 = (shippingCharge1 * 18) / 100;
//         // const shippingCharge2 = shippingCharge-shippingCharge1
//         let shippingCharge = shippingCharge1 + shippingCharge2;
//         const baseAmount = (paidAmount - shippingCharge) / 1.18;
//         const gst = baseAmount * 0.18;
//         const discount = selectedProduct.productPrice - baseAmount;
//         entry.productname = selectedProduct.productname;
//         entry.productTitle = selectedProduct.productTitle;
//         entry.productPrice = selectedProduct.productPrice;
//         entry.BaseAmount = baseAmount.toFixed(2);
//         entry.GST = gst.toFixed(2);
//         entry.ShippingCharge = shippingCharge.toFixed(2);
//         entry.shippingCharge1 = shippingCharge1;
//         entry.shippingCharge2 = shippingCharge2.toFixed(2);
//         entry.Discount = discount.toFixed(2);
//         entry.TotalAmount = paidAmount.toFixed(2);
//       }
//       let serialDate = convertSerialDate(entry["Created On"]);
//       let deliveryDate = getRandomDeliveryDate(
//         serialDate.split(" ")[0].split("-").reverse().join("-")
//       );
//       let deliveryTime = getRandomTimeBetween8AMand10PM();
//       const awb_no = generateAWBNumber();
//       const details = {
//         orderNo: entry["Order No"],
//         invoiceId: entry["Invoice ID"],
//         paidAmount: entry["Paid Amount"],
//         fullName: entry["Full Name"],
//         transactionInvoiceCreatedOn: serialDate,
//         mobileNo: entry["Mobile No"],
//         Email: entry["Email"],
//         billingAddress: entry["Billing Address"],
//         InvoiceType: entry["I-Type"],
//         city: entry["City"],
//         productName: entry.productname,
//         productTitle: entry.productTitle,
//         awbNumber: awb_no,
//         productPrice: entry.productPrice,
//         baseAmount: entry.BaseAmount,
//         gst: entry.GST,
//         deliveryTime: deliveryTime,
//         deliveryDate: deliveryDate,
//         shippingCharges: entry.ShippingCharge,
//         shippingCharge1: entry.shippingCharge1,
//         shippingCharge2: entry.shippingCharge2,
//         discount: entry.Discount,
//         totalAmount: entry.TotalAmount,
//       };
//       let sqlll = "SELECT orderNo FROM tbl_invoicedata";
//       let data = await mysqlcon(sqlll);
//       let dataa = data.filter((item) => item.orderNo == entry["Order No"]);
//       if (dataa.length == 0) {
//         if (details.productName) {

//           let orderNo = entry["Order No"]
//           // const detailForTrackStatus = {
//           //   awb_no,
//           //   orderNo
//           // }
//           //  const sqlForTrack = "INSERT INTO  tracking_order SET ?";
//           const sql = "INSERT INTO tbl_invoicedata SET ?";
//           try {
//             //   await mysqlcon(sqlForTrack, [detailForTrackStatus])
//             await mysqlcon(sql, [details]);
//           } catch (err) {
//             console.error("Error inserting data into MySQL", err);
//           }
//         }
//       }
//     }
//     //return res.json(NotFoundSutaibleProductPrice);
//     return res.status(200).json({
//       result: "Invoice Created Successfully",
//       NotFoundSutaibleProductPrice: NotFoundSutaibleProductPrice,
//     });
//   } catch (error) {
//     console.error("Internal server error:", error);
//     return res.status(500).json({ error: "Internal server error" });
//   }
// };

module.exports.todayUploadedOrNot = async (req, res) => {
  try {
    const sqlForUpload = "SELECT COUNT(*) AS total,DATE_FORMAT(created_on,'%d-%m-%Y') AS created_on FROM tbl_invoicedata GROUP BY DATE(created_on)";
    const result = await mysqlcon(sqlForUpload);
    return res.status(200).json({
      result,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      err,
      message: "Internal Server Error",
    });
  }
};

module.exports.uploadtbl_cron_log = async (req, res) => {
  try {
    // function convertSerialDate(serialDate) {
    //   const startDate = new Date(1899, 11, 30);
    //   const millisecondsPerDay = 86400000;
    //   const adjustedSerialDate = serialDate;
    //   const date = new Date(
    //     startDate.getTime() + adjustedSerialDate * millisecondsPerDay - 540000
    //   );
    //   const day = String(date.getDate()).padStart(2, "0");
    //   const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-indexed
    //   const year = date.getFullYear();
    //   const hours = String(date.getHours()).padStart(2, "0");
    //   const minutes = String(date.getMinutes()).padStart(2, "0");
    //   const seconds = String(date.getSeconds()).padStart(2, "0");
    //   return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    // }
    function convertSerialDate(serialDate) {
      const startDate = new Date(1899, 11, 30);
      const millisecondsPerDay = 86400000;
      const adjustedSerialDate = serialDate;
      // Adjust for Excel's leap year bug if needed (currently -540000 seems like a manual timezone adjustment)
      const date = new Date(
        startDate.getTime() + adjustedSerialDate * millisecondsPerDay - 540000
      );
      const day = String(date.getDate()).padStart(2, "0");
      const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-indexed
      const year = date.getFullYear();
      const hours = String(date.getHours()).padStart(2, "0");
      const minutes = String(date.getMinutes()).padStart(2, "0");
      const seconds = String(date.getSeconds()).padStart(2, "0");
      // Properly format the string with backticks
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: "No file uploaded" });
    }
    const filePath = path.join(__dirname, "../Public/img", `${file.filename}`);
    try {
      await fs.promises.access(filePath, fs.constants.F_OK);
    } catch (err) {
      console.log(err);
      return res.status(404).json({ error: "File not found" });
    }
    const data = fs.readFileSync(filePath);
    const workbook = xlsx.read(data, { type: "buffer" });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const jsonData = xlsx.utils.sheet_to_json(sheet);
    const headers = [
      "user_id",
      "merchant_emp",
      "txn_id",
      "new_trx",
      "order_no",
      "mer_no",
      "transaction_id",
      "card_4_4",
      "ammount",
      "txn_amount",
      "tax_amt",
      "payin_charges",
      "payment_status",
      "status",
      "refund_chargeb_date",
      "ammount_type",
      "bill_address",
      "sign_info",
      "i_country",
      "i_state",
      "i_city",
      "i_zip",
      "i_ip",
      "i_flname",
      "i_fname",
      "i_lname",
      "i_email",
      "i_number",
      "discription",
      "reference",
      "baggage",
      "gatewayNumber",
      "refund",
      "created_on",
      "updated_on",
      "sales_from",
      "settle_currency_current_price",
      "end_point_url",
      "uuid",
      "redirection_url",
      "merchant_db_response",
      "pending_hit_response_by",
      "settlement_on",
      "settle_amount",
      "rolling_reverse_on",
      "rolling_reverse_amount",
      "fiat_fee_amount",
      "gst_charges",
      "our_bank_charge_gst",
      "our_bank_charge",
      "trx_live_test",
      "curl_request_counter",
      "curl_request_date",
      "cny_bank_response",
      "note",
      "device_id",
      "bearer",
      "retry_count"
    ];
    let result = jsonData
      .map((row) => {
        let obj = {};
        headers.forEach((header) => {
          obj[header] = row[header] || null;
        });
        return obj;
      })
      .filter(Boolean);
    //  console.log(result);
    for (const entry of result) {
      if (entry.length == 0) {
      }
      function formatDateTime(input) {
        if (typeof input !== "string") {
          return null;
        }
        if ((input.match(/:/g) || []).length === 1) {
          input += ":00";
        }
        const [datePart, timePart] = input.split(" ");
        if (!datePart || !timePart) {
          return null;
        }
        const [day, month, year] = datePart.split("-");
        if (!day || !month || !year) {
          return null;
        }
        return `${year}-${month}-${day} ${timePart}`;
      }
      // const formatted = formatDateTime(entry["created_on"]);
      // const formatted = convertSerialDate(entry["created_on"]);
      // const formatted1 = convertSerialDate(entry["updated_on"]);
      // const formatted2 = convertSerialDate(entry["settlement_on"]);
      function autoFormat(input) {
        if (typeof input === "string") {
          return formatDateTime(input);
        } else if (typeof input === "number") {
          return convertSerialDate(input);
        } else {
          return null;
        }
      }
      const formatted = autoFormat(entry["created_on"]);
      const formatted1 = autoFormat(entry["updated_on"]);
      const formatted2 = autoFormat(entry["settlement_on"]);
      const formatted3 = autoFormat(entry['rolling_reverse_on']);
      const details = {
        user_id: entry["user_id"],
        merchant_emp: entry['merchant_emp'] || 0,
        txn_id: entry['txn_id'],
        new_trx: entry['new_trx'],
        order_no: entry['order_no'],
        mer_no: entry['mer_no'],
        transaction_id: entry['transaction_id'],
        card_4_4: entry['card_4_4'],
        ammount: entry['ammount'],
        txn_amount: entry['txn_amount'],
        tax_amt: entry['tax_amt'],
        payin_charges: entry['payin_charges'],
        payment_status: entry['payment_status'],
        status: entry['status'] || 0,
        refund_chargeb_date: entry['refund_chargeb_date'],
        ammount_type: entry['ammount_type'],
        bill_address: entry['bill_address'],
        sign_info: entry['sign_info'],
        i_country: entry['i_country'],
        i_state: entry['i_state'],
        i_city: entry['i_city'],
        i_zip: entry['i_zip'],
        i_ip: entry['i_ip'],
        i_flname: entry['i_flname'],
        i_fname: entry['i_fname'],
        i_lname: entry['i_lname'],
        i_email: entry['i_email'],
        i_number: entry['i_number'],
        discription: entry['discription'],
        reference: entry['reference'],
        baggage: entry['baggage'],
        gatewayNumber: entry['gatewayNumber'],
        refund: entry['refund'] || 0,
        created_on: formatted,
        updated_on: formatted1,
        sales_from: entry['sales_from'],
        settle_currency_current_price: entry['settle_currency_current_price'],
        end_point_url: entry['end_point_url'],
        uuid: entry['uuid'],
        redirection_url: entry['redirection_url'],
        merchant_db_response: entry['merchant_db_response'] || 0,
        pending_hit_response_by: entry['pending_hit_response_by'],
        settlement_on: formatted2,
        settle_amount: entry['settle_amount'],
        rolling_reverse_on: formatted3,
        rolling_reverse_amount: entry['rolling_reverse_amount'] || 0,
        fiat_fee_amount: entry['fiat_fee_amount'] || 0,
        gst_charges: entry['gst_charges'] || 0,
        our_bank_charge_gst: entry['our_bank_charge_gst'] || 0,
        our_bank_charge: entry['our_bank_charge'] || 0,
        trx_live_test: entry['trx_live_test'] || 0,
        curl_request_counter: entry['curl_request_counter'] || 0,
        curl_request_date: entry['curl_request_date'],
        cny_bank_response: entry['cny_bank_response'],
        note: entry['note'],
        device_id: entry['device_id'],
        bearer: entry['bearer'],
        retry_count: entry['retry_count']
      };
      // let sqlll = "SELECT order_no FROM tbl_merchant_transaction";
      // let data = await mysqlcon(sqlll);
      // let dataa = data.filter((item) => item.order_no == entry["order_no"]);
      // if (dataa.length == 0) {
      //   if (details) {
      const sql = "INSERT INTO tbl_merchant_transaction SET ?";
      try {
        await mysqlcon(sql, [details]);
      } catch (err) {
        console.error("Error inserting data into MySQL", err);
      }
      //   }
      // }
    }
    //return res.json(NotFoundSutaibleProductPrice);
    return res.status(200).json({
      result: "Invoice Created Successfully",
      //  NotFoundSutaibleProductPrice: NotFoundSutaibleProductPrice,
    });
  } catch (error) {
    console.error("Internal server error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};