const mysqlcon = require("../config/db_connection");
module.exports.fetchDownloadedInvoices = async (req, res) => {
  let { page, searchItem } = req.body;
  try {
    page = page ? Number(page) : 1;
    let limit = 5;
    let start = page * limit - limit;
    const countInvoiceSql =
      "SELECT COUNT(*) AS Total FROM tbl_invoicedata WHERE status = 1";
    const countSearchItemSql =
      "SELECT COUNT(*) AS Total FROM tbl_invoicedata WHERE status = 1 AND orderNo LIKE ?";
    const result = await mysqlcon(
      searchItem ? countSearchItemSql : countInvoiceSql,
      searchItem ? [`%${searchItem}%`] : ""
    );
    const fetchDefaultInvoiceSql =
      "SELECT  *FROM tbl_invoicedata WHERE status = 1 LIMIT ?,?";
    const fetchSearchItemInvoiceSql =
      "SELECT  *FROM tbl_invoicedata WHERE status = 1 AND orderNo LIKE ? LIMIT ?,?";
    const fetchResult = await mysqlcon(
      searchItem ? fetchSearchItemInvoiceSql : fetchDefaultInvoiceSql,
      searchItem ? [`%${searchItem}%`, start, limit] : [start, limit]
    );
    let total = result[0].Total;
    let numOfPages = Math.ceil(total / limit);
    let startRange = start + 1;
    let endRange = start + fetchResult.length;
    return res.status(200).send({
      message:
        total > 0
          ? `Showing ${startRange} to ${endRange} data from ${total}`
          : "NO DATA",
      Status: "success",
      currentPage: page,
      totalPage: numOfPages,
      result: fetchResult,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      message: "Internal Server Error",
    });
  }
};
