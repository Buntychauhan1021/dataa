const config = require("../config/config");
var md5 = require("md5");
const jwt = require("jsonwebtoken");
const mysqlcon = require("../config/db_connection");
const emailvalidator = require("email-validator");
const loginCont = {
  login: async function (req, res) {
    try {
    let {email, password} = req.body;
    if (!emailvalidator.validate(email)) {
      return res.status(201).json({
        message: `Entered A valid Email`,
      });
    }
    let encryptedPassword = md5(password)
    let dbquery = await mysqlcon(`SELECT * from invoice_login WHERE email = '${email}'`)
    if(dbquery[0] && dbquery[0].length !== 0){
      let id = dbquery[0].id
      let token = jwt.sign({ id: dbquery[0].id }, config.JWT_SECRET_KEY, { expiresIn: config.JWT_EXPIRY_TIME })
      dbquery[0]["token"] = token;
      if(dbquery[0].password === encryptedPassword){
        return res.status(200).json({
          data: dbquery[0],
        });
      } else {
        return res.status(201).json({
          message: "Password Not Matched",
        });
      }
    } else {
      return res.status(201).json({
        message: "User Doesn't Exist!!!",
      });
    }
    
  } catch (error) {
    return res.status(500).json({
      status: false,
      message: "An error occurred during registration.",
      error: error.message,
    });
  }
  }
};
module.exports = loginCont;
