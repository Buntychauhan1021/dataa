const mysqlcon = require("../config/db_connection");

module.exports.trackOrderByAwb = async (req, res) => {
  const { awb_no } = req.body;
  try {
    const sqlForTrack =
      "SELECT * FROM tbl_invoicedata INNER JOIN tracking_order ON tbl_invoicedata.orderNo = tracking_order.orderNo WHERE awb_no = ?";
    const result = await mysqlcon(sqlForTrack, [awb_no]);
    const orderTrackingStatus = result[0].tracking_status;
    let orderStatus = "";
    const orderAddress = result[0].billingAddress;
    if (orderTrackingStatus == 1) {
      orderStatus = "ordered";
    } else if (orderTrackingStatus == 2) {
      orderStatus = "shipped";
    } else if (orderTrackingStatus == 3) {
      orderStatus = "out for delivery";
      return res.status(200).json({
        message: orderStatus,
        status: orderTrackingStatus,
        orderAddress: orderAddress,
      });
    } else if (orderTrackingStatus == 4) {
      orderStatus = "delivered";
      return res.status(200).json({
        message: orderStatus,
        status: orderTrackingStatus,
        orderAddress: orderAddress,
      });
    }
    return res.status(200).json({
      message: orderStatus,
      status: orderTrackingStatus,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

// module.exports.changeOrderStatus = async (req, res) => {
//   const { awb_no } = req.body;
//   try {
//     // Fetch the order details from the database
//     const fetchOrderDate =
//       "SELECT * FROM tbl_invoicedata INNER JOIN tracking_order ON tbl_invoicedata.orderNo = tracking_order.orderNo WHERE awb_no = ?";
//     const result = await mysqlcon(fetchOrderDate, [awb_no]);

//     if (result.length === 0) {
//       return res.status(404).json({ message: "AWB number not found" });
//     }

//     // Parse delivery date and time
//     const [deliveryDay, deliveryMonth, deliveryYear] = result[0].deliveryDate.split("-");

    
//     const deliveryTime = result[0].deliveryTime.split(":");
//     const deliveryDate = new Date(`${deliveryYear}-${deliveryMonth}-${deliveryDay}T${deliveryTime[0]}:00:00`);

//     // Parse order date
//     let orderDate = result[0].transactionInvoiceCreatedOn; // e.g., "20-12-2024 00:00"
//     const [datePart, timePart] = orderDate.split(" ");
//     const [day, month, year] = datePart.split("-");
//     orderDate = new Date(`${year}-${month}-${day}T${timePart || "00:00:00"}`);

//     // Get the current date
//     const currentDate = new Date();

//     // Calculate shipping date (1 day after order date)
//     const shippingDate = new Date(orderDate);
//     shippingDate.setDate(orderDate.getDate() + 1);

//     // Randomly set warehouse date (1 or 2 days after shipping date)
//     const randomGap = Math.floor(Math.random() * 2) + 1; // Random number: 1 or 2
//     const wareHouseDate = new Date(shippingDate);
//     wareHouseDate.setDate(shippingDate.getDate() + randomGap);

//     // Out-for-delivery date (1 day after warehouse date)
//     const outForDeliveryDate = new Date(wareHouseDate);
//     outForDeliveryDate.setDate(wareHouseDate.getDate() + 1);

//     // Logging for debugging
//     console.log("Current Date:", currentDate);
//     console.log("Order Date:", orderDate);
//     console.log("Shipping Date:", shippingDate);
//     console.log("Warehouse Date:", wareHouseDate);
//     console.log("Out-for-Delivery Date:", outForDeliveryDate);

//     // Status update logic
//     if (
//       currentDate.toDateString() === orderDate.toDateString() &&
//       !result[0].ordered_date
//     ) {
//       // Order placed today
//       const sqlForUpdateStatus =
//         "UPDATE tracking_order SET tracking_status = 1, ordered_date = ? WHERE awb_no = ?";
//       await mysqlcon(sqlForUpdateStatus, [orderDate, awb_no]);
//       console.log("Ordered");
//     } else if (
//       currentDate.toDateString() === shippingDate.toDateString() &&
//       !result[0].shipping_date
//     ) {
//       // Shipped (1 day after order date)
//       const sqlForUpdateStatus =
//         "UPDATE tracking_order SET tracking_status = 2, ordered_date = ?, shipping_date = ? WHERE awb_no = ?";
//       await mysqlcon(sqlForUpdateStatus, [orderDate, shippingDate, awb_no]);
//       console.log("Shipped");
//     } else if (
//       currentDate.toDateString() === wareHouseDate.toDateString() &&
//       !result[0].ware_house_date
//     ) {
//       // Reached warehouse
//       const sqlForUpdateStatus =
//         "UPDATE tracking_order SET tracking_status = 3, ordered_date = ?, shipping_date = ?, ware_house_date = ? WHERE awb_no = ?";
//       await mysqlcon(sqlForUpdateStatus, [orderDate, shippingDate, wareHouseDate, awb_no]);
//       console.log("Warehouse Reached");
//     } else if (
//       currentDate.toDateString() === outForDeliveryDate.toDateString() &&
//       !result[0].out_for_delivery
//     ) {
//       // Out for delivery
//       const sqlForUpdateStatus =
//         "UPDATE tracking_order SET tracking_status = 4, ordered_date = ?, shipping_date = ?, ware_house_date = ?, out_for_delivery = ? WHERE awb_no = ?";
//       await mysqlcon(sqlForUpdateStatus, [
//         orderDate,
//         shippingDate,
//         wareHouseDate,
//         outForDeliveryDate,
//         awb_no,
//       ]);
//       console.log("Out for delivery");
//     } else if (currentDate >= deliveryDate && deliveryDate.getHours() >= currentDate.getHours()) {
//       // Delivered
//       const sqlForFindDetails = "SELECT * FROM tracking_order WHERE awb_no = ?";
//       const resultForFind = await mysqlcon(sqlForFindDetails, [awb_no]);
//       const details = {
//         ordered_date: resultForFind[0].ordered_date || orderDate,
//         shipping_date: resultForFind[0].shipping_date || shippingDate,
//         ware_house_date: resultForFind[0].ware_house_date || wareHouseDate.toISOString().split("T")[0],
//         out_for_delivery: resultForFind[0].out_for_delivery || outForDeliveryDate.toISOString().split("T")[0],
//         tracking_status: 5,
//         delivered: deliveryDate.toISOString().split("T")[0],
//       };
//       const sqlForUpdateStatus = "UPDATE tracking_order SET ? WHERE awb_no = ?";
//       await mysqlcon(sqlForUpdateStatus, [details, awb_no]);
//       console.log("Delivered");
//     }

//     // Respond with success message
//     return res.status(200).json({
//       message: "Status updated successfully",
//     });
//   } catch (err) {
//     console.log(err);
//     return res.status(500).json({
//       message: "Internal Server Error",
//     });
//   }
// };







// else if (
//   currentDate >= deliveryDay &&
//   deliveryMonth >= currentMonth + 1 &&
//   deliveryYear >= currentYear &&
//   deliveryHours >= date.getHours()
// ) {
//   // If none of the above, set status to "out for delivery"
//   const sqlForUpdateStatus =
//     "UPDATE tracking_order SET tracking_status = 4,delivered=? WHERE awb_no = ?";
//   await mysqlcon(sqlForUpdateStatus, [date, awb_no]);
//   console.log("delivered", date.getHours());
// }

module.exports.changeOrderStatus = async (req, res) => {
  try {
    //'H-47482e33a7d9db5b2c'
    const { value,type } = req.body 
    let sql,result;
    if(!value || value==undefined)
    {
      return res.status(400).json({
       
      message:"value is must"
      });
    }
    if(type=='Order') {
       sql = "select * from tbl_invoicedata where orderNo=?"
       result = await mysqlcon(sql,[value])
    } else {
       sql = "select * from tbl_invoicedata where	awbNumber=?"
       result = await mysqlcon(sql,[value])
    }


    if(result.length==0) {
      return res.status(201).json({
       message : "Order not Found"
      });
    }
    
    let deliveryDate = result[0].transactionInvoiceCreatedOn;
    const [datePart, timePart] = deliveryDate.split(" ");
    const [day, month, year] = datePart.split("-");
    const targetDate = new Date(`${year}-${month}-${day}T00:00:00`);
    const currentDate = new Date();
    const diffTime = currentDate.getTime() - targetDate.getTime()



    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    let status = "";
    if (diffDays >= 1 && diffDays < 2) {
      status = "Ordered";
    } else if ((diffDays >= 2 || diffDays >= 3) && (diffDays < 3 || diffDays < 4)) {
      status = "Shipped";
    } else if (diffDays >= 4 && diffDays < 5) {
      status = "Warehouse";
    } else if (diffDays >= 5 && diffDays < 6) {
      status = "Out-Delivery";
    } else if (diffDays >= 6) {
      status = "Delivered";
    } else {
      status = "No status available for the given date.";
    }

    if(result.length>0) {
      return res.status(200).json({
        current_date: currentDate.toISOString().split("T")[0],
        status,
        result: result[0]
      });
    } 
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};