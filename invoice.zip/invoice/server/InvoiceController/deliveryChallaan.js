const mysqlcon = require("../config/db_connection");
const path = require('path')
const fs = require('fs')
module.exports.fetchDelivryChallan = async (req, res) => {
  let { page, searchItem } = req.body;
  try {
    page = page ? Number(page) : 1;
    let limit = 5;
    let start = page * limit - limit;
    const sqlForAllResult = "SELECT *FROM tbl_invoicedata"
    const resultForAll = await mysqlcon(sqlForAllResult)
    for(let i=0;i<resultForAll.length;i++){
      const startNameOneLetter = (resultForAll[i].fullName.split('')[0]);
      const folderPath = path.resolve(__dirname, '../Public', 'E-signature', startNameOneLetter);

      if (fs.existsSync(folderPath)) {
        const files = fs.readdirSync(folderPath);
        if (files.length > 0) {
          const randomIndex = Math.floor(Math.random() * files.length);
          const randomFile = files[randomIndex];
          const sqlForSearchImage = "SELECT signatureImageName FROM tbl_invoicedata WHERE orderNo = ?"
          const resultForImage = await mysqlcon(sqlForSearchImage,[resultForAll[i].orderNo])
         if(!resultForImage[0].signatureImageName) {
           insertImage = "UPDATE tbl_invoicedata SET signatureImageName = ? WHERE orderNo = ?";
           const resultForImage = await mysqlcon(insertImage,[randomFile,resultForAll[i].orderNo])
         } 
        }
      } else {
        res.status(404).send('Folder not found');
      }
    }

    const countInvoiceSql =
      "SELECT COUNT(*) AS Total FROM tbl_invoicedata WHERE challanStatus = 0";
    const countSearchItemSql =
      "SELECT COUNT(*) AS Total FROM tbl_invoicedata WHERE challanStatus = 0 AND orderNo LIKE ?";
    const result = await mysqlcon(
      searchItem ? countSearchItemSql : countInvoiceSql,
      searchItem ? [`%${searchItem}%`] : ""
    );
    const fetchDefaultInvoiceSql =
      "SELECT  *FROM tbl_invoicedata WHERE challanStatus = 0 LIMIT ?,?";
    const fetchSearchItemInvoiceSql =
      "SELECT  *FROM tbl_invoicedata WHERE challanStatus = 0 AND orderNo LIKE ? LIMIT ?,?";
    const fetchResult = await mysqlcon(
      searchItem ? fetchSearchItemInvoiceSql : fetchDefaultInvoiceSql,
      searchItem ? [`%${searchItem}%`, start, limit] : [start, limit]
    );
    let total = result[0].Total;
    let numOfPages = Math.ceil(total / limit);
    let startRange = start + 1;
    let endRange = start + fetchResult.length;
    return res.status(200).send({
      message:
        total > 0
          ? `Showing ${startRange} to ${endRange} data from ${total}`
          : "NO DATA",
      Status: "success",
      currentPage: page,
      totalPage: numOfPages,
      result: fetchResult,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      message: "Internal Server Error",
    });
  }
};
module.exports.changeStatusDeliveryChallan = async (req, res) => {
  try {
    const { orderNo } = req.body;
    const sqlForInsert = "UPDATE tbl_invoicedata SET challanStatus = 1 WHERE orderNo = ?";
    const result = await mysqlcon(sqlForInsert, [orderNo]);
    return res.status(200).json({
      message: "status Update Successfully",
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      message: "Internal Server Error",
    });
  }
};