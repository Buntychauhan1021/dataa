const moment = require("moment");
const mysqlcon = require("../config/db_connection");
// module.exports.DashboardByDay = async (req, res) => {
//   try {
//     const startOfWeek = moment().startOf("week").format("YYYY-MM-DD");
//     const endOfWeek = moment().endOf("week").format("YYYY-MM-DD");
//     const sql = `SELECT * FROM tbl_invoicedata WHERE created_on BETWEEN '${startOfWeek}' AND '${endOfWeek}'`;
//     const result = await mysqlcon(sql);
//     let weekData = {
//       Sunday: { pinlabs: 0, billdesk: 0 },
//       Monday: { pinlabs: 0, billdesk: 0 },
//       Tuesday: { pinlabs: 0, billdesk: 0 },
//       Wednesday: { pinlabs: 0, billdesk: 0 },
//       Thursday: { pinlabs: 0, billdesk: 0 },
//       Friday: { pinlabs: 0, billdesk: 0 },
//       Saturday: { pinlabs: 0, billdesk: 0 },
//     };
//     result.forEach((row) => {
//       const dayOfWeek = moment(row.created_on).format("dddd");
//       if (row.orderNo && row.orderNo.length === 9) {
//         weekData[dayOfWeek].pinlabs++;
//       } else if (row.orderNo) {
//         weekData[dayOfWeek].billdesk++;
//       }
//     });
//     return res.status(200).json(weekData);
//   } catch (err) {
//     console.error(err);
//     return res
//       .status(500)
//       .json({ error: "An error occurred while processing the data." });
//   }
// };
module.exports.DashboardByDay = async (req, res) => {
  try {
    const startOfWeek = moment().startOf("week").format("YYYY-MM-DD");
    const endOfWeek = moment().endOf("week").format("YYYY-MM-DD");
    const sql = `SELECT * FROM tbl_invoicedata WHERE created_on BETWEEN '${startOfWeek}' AND '${endOfWeek}'`;
    const result = await mysqlcon(sql);
    let weekData = {
      Sunday: { dotone: 0, yeppe: 0 },
      Monday: { dotone: 0, yeppe: 0 },
      Tuesday: { dotone: 0, yeppe: 0 },
      Wednesday: { dotone: 0, yeppe: 0 },
      Thursday: { dotone: 0, yeppe: 0 },
      Friday: { dotone: 0, yeppe: 0 },
      Saturday: { dotone: 0, yeppe: 0 },
    };
    result.forEach((row) => {
      const dayOfWeek = moment(row.created_on).format("dddd");
      if (row.InvoiceType && row.InvoiceType =="dotone") {
        weekData[dayOfWeek].dotone++;
      } else if (row.orderNo) {
        weekData[dayOfWeek].yeppe++;
      }
    });
    return res.status(200).json(weekData);
  } catch (err) {
    console.error(err);
    return res
      .status(500)
      .json({ error: "An error occurred while processing the data." });
  }
};
module.exports.countInvoice = async (req, res) => {
  try {
    let sqlForAllInvoice = await mysqlcon(
      `SELECT COUNT (*) AS count FROM tbl_invoicedata`
    );
    const countSqlForAllInvoice = sqlForAllInvoice[0]?.count || 0;
    let sqlForDownloadedInvoice = await mysqlcon(
      `SELECT COUNT (*) AS count FROM tbl_invoicedata WHERE status = 1`
    );
    const countSqlForDownloadedInvoice = sqlForDownloadedInvoice[0]?.count || 0;
    let sqlForDeliveryChallan = await mysqlcon(
      `SELECT COUNT (*) AS count FROM tbl_invoicedata where challanStatus = 0`
    );
    const countSqlForDeliveryChallan = sqlForDeliveryChallan[0]?.count || 0;
    let sqlForDownloadedDeliveryChallan = await mysqlcon(
      `SELECT COUNT (*) AS count FROM tbl_invoicedata where challanStatus = 1`
    );
    const countSqlForDownloadedDeliveryChallan =
      sqlForDownloadedDeliveryChallan[0]?.count || 0;
    return res.status(200).json({
      allInvoices: countSqlForAllInvoice,
      downloadedInvoice: countSqlForDownloadedInvoice,
      allDeliveryChallan: countSqlForDeliveryChallan,
      downloadedDeliveryChallan: countSqlForDownloadedDeliveryChallan,
    });
  } catch (error) {
    return res.status(500).json({
      result: error.message,
    });
  }
};

