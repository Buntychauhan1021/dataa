

const express = require('express');
const app = express();
const port = 9241;
const config = require('./config/config.js');
const cors = require("cors");

app.use(express.urlencoded())
app.use(express.json())
app.use(cors())
// routing
app.use(express.static('Public/E-signature'))
app.use(require('./routeInvoice/route.js'));
// run website
app.listen(port, (req, res) =>{
    console.log('http://' + config.DB_HOST + ':' + port);
});





// const express = require('express');
// const https = require('https'); // HTTPS Server
// const http = require('http'); // HTTP for fallback
// const fs = require('fs'); // Read SSL Files
// const path = require('path'); // For safe file paths
// const app = express();

// const PORT = process.env.PORT || 8082; // Default HTTPS Port
// const HTTP_PORT = 8081; // Fallback HTTP Port

// // Load SSL credentials
// let credentials;
// try {
//     const privateKey = fs.readFileSync(path.join(__dirname, './Certificates/b86f0_3c1f1_0a81ae56dc2ee24761761cc73edc639b.key'), 'utf8');
//     const certificate = fs.readFileSync(path.join(__dirname, './Certificates/_wildcard__xpresslogi_com_b86f0_3c1f1_1747737674_ae7a0df46bbc20b1dc205cef9428dabc.CRT'), 'utf8');
//     credentials = { key: privateKey, cert: certificate };
// } catch (err) {
//     console.error("⚠️ SSL Certificate files not found. HTTPS will not be enabled.");
//     credentials = null;
// }

// // CORS Middleware
// const customCorsHeaders = (req, res, next) => {
//     const allowedOrigins = ['http://localhost:3000', 'http://127.0.0.1:3000'];
//     const origin = req.headers.origin;
    
//     if (allowedOrigins.includes(origin)) {
//         res.setHeader('Access-Control-Allow-Origin', origin);
//     }
    
//     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
//     res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
//     res.setHeader('Access-Control-Allow-Credentials', 'true');
    
//     next();
// };

// // Apply Middleware
// app.use(customCorsHeaders);
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname, 'Public/E-signature')));
// app.use(require('./routeInvoice/route.js'));

// // Start HTTPS Server if SSL is available
// if (credentials) {
//     https.createServer(credentials, app).listen(PORT, () => {
//         console.log(`✅ HTTPS Server running at https://localhost:${PORT}`);
//     });
// } else {
//     // Fallback to HTTP Server
//     http.createServer(app).listen(HTTP_PORT, () => {
//         console.log(`⚠️ Running on HTTP: http://localhost:${HTTP_PORT}`);
//     });
// }
