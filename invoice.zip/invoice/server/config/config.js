const config = {
  DB_HOST: "localhost",
  DB_PORT: "3306",
  DB_USERNAME: "root",
  DB_PASSWORD: "",
  DB_NAME: "hris",

  // JWT DATA
  JWT_EXPIRY_TIME: "1h",
  JWT_ALGO: "sha512",
  JWT_SECRET_KEY: "UBankConnect.15.05.22",
  PWD_SALT: 10,
};

module.exports = config;